<!-- tools: registry and integration notes -->
<!-- Bundled files in this playbook (open by line number or search for '## File: <path>'):
  - tools/REGISTRY.md -> line 118
  - tools/SETUP.md -> line 844
  - tools/PARTNERS.md -> line 979
  - tools/integrations/activecampaign.md -> line 1090
  - tools/integrations/adobe-analytics.md -> line 1462
  - tools/integrations/ahrefs.md -> line 1630
  - tools/integrations/airops.md -> line 1798
  - tools/integrations/aisa.md -> line 1944
  - tools/integrations/amplitude.md -> line 2046
  - tools/integrations/apify.md -> line 2228
  - tools/integrations/apollo.md -> line 2299
  - tools/integrations/attentive.md -> line 2452
  - tools/integrations/attio.md -> line 2607
  - tools/integrations/audiencetap.md -> line 2716
  - tools/integrations/beehiiv.md -> line 2844
  - tools/integrations/brevo.md -> line 3006
  - tools/integrations/browserbase.md -> line 3305
  - tools/integrations/buffer.md -> line 3419
  - tools/integrations/calendly.md -> line 3560
  - tools/integrations/clay.md -> line 3730
  - tools/integrations/clearbit.md -> line 3882
  - tools/integrations/close.md -> line 4028
  - tools/integrations/cogny.md -> line 4241
  - tools/integrations/composio.md -> line 4397
  - tools/integrations/contentful.md -> line 4590
  - tools/integrations/converly.md -> line 4753
  - tools/integrations/coupler.md -> line 4874
  - tools/integrations/crossbeam.md -> line 5019
  - tools/integrations/customer-io.md -> line 5172
  - tools/integrations/dataforseo.md -> line 5408
  - tools/integrations/demio.md -> line 5588
  - tools/integrations/dub-co.md -> line 5777
  - tools/integrations/exa.md -> line 5949
  - tools/integrations/firecrawl.md -> line 6122
  - tools/integrations/firehose.md -> line 6327
  - tools/integrations/fullenrich.md -> line 6489
  - tools/integrations/g2.md -> line 6594
  - tools/integrations/ga4.md -> line 6776
  - tools/integrations/github.md -> line 6952
  - tools/integrations/glasser.md -> line 7153
  - tools/integrations/gong.md -> line 7374
  - tools/integrations/google-ads.md -> line 7521
  - tools/integrations/google-search-console.md -> line 7816
  - tools/integrations/heygen.md -> line 8009
  - tools/integrations/heyreach.md -> line 8138
  - tools/integrations/hotjar.md -> line 8242
  - tools/integrations/hubspot.md -> line 8360
  - tools/integrations/hunter.md -> line 8541
  - tools/integrations/hyperframes.md -> line 8659
  - tools/integrations/instantly.md -> line 8778
  - tools/integrations/intercom.md -> line 8903
  - tools/integrations/introw.md -> line 9231
  - tools/integrations/keywords-everywhere.md -> line 9416
  - tools/integrations/kit.md -> line 9634
  - tools/integrations/klaviyo.md -> line 9804
  - tools/integrations/leadmagic.md -> line 10053
  - tools/integrations/lemlist.md -> line 10151
  - tools/integrations/linkedin-ads.md -> line 10276
  - tools/integrations/livestorm.md -> line 10394
  - tools/integrations/mailchimp.md -> line 10715
  - tools/integrations/mention-me.md -> line 10874
  - tools/integrations/meta-ads.md -> line 11037
  - tools/integrations/mixpanel.md -> line 11201
  - tools/integrations/nitrosend.md -> line 11378
  - tools/integrations/omnia.md -> line 11494
  - tools/integrations/onesignal.md -> line 11639
  - tools/integrations/optimizely.md -> line 11884
  - tools/integrations/outreach.md -> line 12058
  - tools/integrations/paddle.md -> line 12259
  - tools/integrations/partnerstack.md -> line 12492
  - tools/integrations/pendo.md -> line 12724
  - tools/integrations/plausible.md -> line 12946
  - tools/integrations/plivo.md -> line 13176
  - tools/integrations/ploy.md -> line 13319
  - tools/integrations/posthog.md -> line 13454
  - tools/integrations/postmark.md -> line 13608
  - tools/integrations/postscript.md -> line 13855
  - tools/integrations/rankparse.md -> line 13984
  - tools/integrations/rb2b.md -> line 14244
  - tools/integrations/resend.md -> line 14357
  - tools/integrations/rewardful.md -> line 14592
  - tools/integrations/rowbound.md -> line 14758
  - tools/integrations/salesforce.md -> line 14825
  - tools/integrations/sanity.md -> line 14978
  - tools/integrations/savvycal.md -> line 15129
  - tools/integrations/segment.md -> line 15331
  - tools/integrations/semrush.md -> line 15548
  - tools/integrations/sendgrid.md -> line 15678
  - tools/integrations/sequenzy.md -> line 15853
  - tools/integrations/shopify.md -> line 16162
  - tools/integrations/similarweb.md -> line 16341
  - tools/integrations/snov.md -> line 16508
  - tools/integrations/sparktoro.md -> line 16627
  - tools/integrations/strapi.md -> line 16757
  - tools/integrations/stripe.md -> line 16927
  - tools/integrations/supermetrics.md -> line 17078
  - tools/integrations/theirstack.md -> line 17236
  - tools/integrations/tiktok-ads.md -> line 17331
  - tools/integrations/tolt.md -> line 17492
  - tools/integrations/truelist.md -> line 17631
  - tools/integrations/trustpilot.md -> line 17767
  - tools/integrations/twilio.md -> line 17982
  - tools/integrations/typeform.md -> line 18137
  - tools/integrations/webflow.md -> line 18332
  - tools/integrations/wistia.md -> line 18533
  - tools/integrations/wordpress.md -> line 18700
  - tools/integrations/zapier.md -> line 18878
  - tools/integrations/zoominfo.md -> line 19133
-->

# Tools

---
# Bundled files

## File: tools/REGISTRY.md

# Marketing Tools Registry

Quick reference for AI agents to discover tool capabilities and integration methods.

## How to Use This Registry

1. **Find tools by category** - Browse sections below for tools in each domain
2. **Check integration methods** - See what APIs, MCPs, CLIs, or SDKs are available
3. **Read integration guides** - Detailed setup and common operations in `integrations/`
4. **Connect selected accounts** - Use [guided setup](SETUP.md) for local credentials, approval gates, and a first read-only check

---

## Verified Partners

> **Full rules & boundaries:** [PARTNERS.md](PARTNERS.md) — the canonical governance doc (tool taxonomy, what sponsorship buys and never buys, disclosure, the partner lifecycle, and the `integrations/` spec).

◆ **Verified Partners** are tools whose makers fund Marketing Skills through the [partner program](https://marketing-skills.com/sponsorship). What the marker means — and doesn't:

- **Disclosed + vetted for fit.** Each carries a disclosure header in its integration guide and is marked ◆ in the index below.
- **Additive, never biasing.** A partner is listed *alongside* the neutral options for the same job, never instead of them. Partner status never removes or demotes another tool and **never changes what any skill recommends** — if a non-partner is the right answer, that's the answer. The badge means "paid, disclosed, vetted for fit," not "best in category."

Anyone — including tool makers and partners — may contribute content that names a tool, as long as it makes an agent *aware* of the right option without manufacturing a recommendation. The bar is the [integrity rubric in CONTRIBUTING.md](../CONTRIBUTING.md#mentioning-tools-the-integrity-rubric) (options not one answer, disclosed, passes the swap test).

<!-- PARTNERS:START -->
| Partner | Category | Guide |
|---------|----------|-------|
| ◆ Converly | Conversion tracking / attribution | [converly.md](integrations/converly.md) |
| ◆ Ploy | AI website & growth platform | [ploy.md](integrations/ploy.md) |
| ◆ AIsa | SEO, search & social data | [aisa.md](integrations/aisa.md) |
| ◆ Omnia | AI search visibility (AEO) | [omnia.md](integrations/omnia.md) |
<!-- PARTNERS:END -->

<!-- The table above is generated from partners.json — run `node scripts/sync-partners.mjs`. -->

---

## Tool Index

| Tool | Category | API | MCP | CLI | SDK | Guide |
|------|----------|:---:|:---:|:---:|:---:|-------|
| ◆ converly | Conversion Tracking | ✓ | ✓ | ✓ | ✓ | [converly.md](integrations/converly.md) |
| ◆ ploy | Website | ✓ | - | ✓ | - | [ploy.md](integrations/ploy.md) |
| ◆ aisa | SEO / Data APIs | ✓ | ✓ | ✓ | - | [aisa.md](integrations/aisa.md) |
| ga4 | Analytics | ✓ | ✓ | [✓](clis/ga4.js) | ✓ | [ga4.md](integrations/ga4.md) |
| mixpanel | Analytics | ✓ | - | [✓](clis/mixpanel.js) | ✓ | [mixpanel.md](integrations/mixpanel.md) |
| amplitude | Analytics | ✓ | - | [✓](clis/amplitude.js) | ✓ | [amplitude.md](integrations/amplitude.md) |
| posthog | Analytics | ✓ | - | ✓ | ✓ | [posthog.md](integrations/posthog.md) |
| segment | Analytics | ✓ | - | [✓](clis/segment.js) | ✓ | [segment.md](integrations/segment.md) |
| adobe-analytics | Analytics | ✓ | - | [✓](clis/adobe-analytics.js) | ✓ | [adobe-analytics.md](integrations/adobe-analytics.md) |
| plausible | Analytics | ✓ | - | [✓](clis/plausible.js) | - | [plausible.md](integrations/plausible.md) |
| google-search-console | SEO | ✓ | - | [✓](clis/google-search-console.js) | ✓ | [google-search-console.md](integrations/google-search-console.md) |
| semrush | SEO | ✓ | - | [✓](clis/semrush.js) | - | [semrush.md](integrations/semrush.md) |
| ahrefs | SEO | ✓ | - | [✓](clis/ahrefs.js) | - | [ahrefs.md](integrations/ahrefs.md) |
| dataforseo | SEO | ✓ | - | [✓](clis/dataforseo.js) | ✓ | [dataforseo.md](integrations/dataforseo.md) |
| keywords-everywhere | SEO | ✓ | - | [✓](clis/keywords-everywhere.js) | - | [keywords-everywhere.md](integrations/keywords-everywhere.md) |
| rankparse | SEO | ✓ | ✓ | [✓](clis/rankparse.js) | - | [rankparse.md](integrations/rankparse.md) |
| omnia | AEO | ✓ | ✓ | - | - | [omnia.md](integrations/omnia.md) |
| clearbit | Data Enrichment (legacy) | ✓ | - | [✓](clis/clearbit.js) | ✓ | [clearbit.md](integrations/clearbit.md) |
| apollo | Data Enrichment | ✓ | ✓ | [✓](clis/apollo.js) | - | [apollo.md](integrations/apollo.md) |
| zoominfo | Data Enrichment | ✓ | ✓ | [✓](clis/zoominfo.js) | - | [zoominfo.md](integrations/zoominfo.md) |
| clay | Data Enrichment | ✓ | ✓ | [✓](clis/clay.js) | - | [clay.md](integrations/clay.md) |
| fullenrich | Data Enrichment | ✓ | ✓ | - | - | [fullenrich.md](integrations/fullenrich.md) |
| leadmagic | Data Enrichment | ✓ | ✓ | ✓ | - | [leadmagic.md](integrations/leadmagic.md) |
| rowbound | Data Enrichment | - | ✓ | ✓ | - | [rowbound.md](integrations/rowbound.md) |
| supermetrics | Data Aggregation | ✓ | ✓ | [✓](clis/supermetrics.js) | - | [supermetrics.md](integrations/supermetrics.md) |
| coupler | Data Aggregation | ✓ | ✓ | [✓](clis/coupler.js) | - | [coupler.md](integrations/coupler.md) |
| hubspot | CRM | ✓ | ✓ | ✓ | ✓ | [hubspot.md](integrations/hubspot.md) |
| salesforce | CRM | ✓ | - | ✓ | ✓ | [salesforce.md](integrations/salesforce.md) |
| close | CRM | ✓ | ✓ | [✓](clis/close.js) | - | [close.md](integrations/close.md) |
| attio | CRM | ✓ | ✓ | - | ✓ | [attio.md](integrations/attio.md) |
| stripe | Payments | ✓ | ✓ | ✓ | ✓ | [stripe.md](integrations/stripe.md) |
| paddle | Payments | ✓ | - | [✓](clis/paddle.js) | ✓ | [paddle.md](integrations/paddle.md) |
| rewardful | Referral | ✓ | - | [✓](clis/rewardful.js) | - | [rewardful.md](integrations/rewardful.md) |
| tolt | Referral | ✓ | - | [✓](clis/tolt.js) | - | [tolt.md](integrations/tolt.md) |
| dub-co | Links | ✓ | - | [✓](clis/dub.js) | ✓ | [dub-co.md](integrations/dub-co.md) |
| mention-me | Referral | ✓ | - | [✓](clis/mention-me.js) | - | [mention-me.md](integrations/mention-me.md) |
| partnerstack | Affiliate | ✓ | - | [✓](clis/partnerstack.js) | - | [partnerstack.md](integrations/partnerstack.md) |
| mailchimp | Email | ✓ | ✓ | [✓](clis/mailchimp.js) | ✓ | [mailchimp.md](integrations/mailchimp.md) |
| customer-io | Email | ✓ | - | [✓](clis/customer-io.js) | ✓ | [customer-io.md](integrations/customer-io.md) |
| sendgrid | Email | ✓ | - | [✓](clis/sendgrid.js) | ✓ | [sendgrid.md](integrations/sendgrid.md) |
| resend | Email | ✓ | ✓ | [✓](clis/resend.js) | ✓ | [resend.md](integrations/resend.md) |
| sequenzy | Email | ✓ | ✓ | ✓ | - | [sequenzy.md](integrations/sequenzy.md) |
| nitrosend | Email | ✓ | ✓ | - | - | [nitrosend.md](integrations/nitrosend.md) |
| kit | Email | ✓ | - | [✓](clis/kit.js) | ✓ | [kit.md](integrations/kit.md) |
| beehiiv | Newsletter | ✓ | - | [✓](clis/beehiiv.js) | - | [beehiiv.md](integrations/beehiiv.md) |
| klaviyo | Email/SMS | ✓ | - | [✓](clis/klaviyo.js) | ✓ | [klaviyo.md](integrations/klaviyo.md) |
| postmark | Email | ✓ | - | [✓](clis/postmark.js) | ✓ | [postmark.md](integrations/postmark.md) |
| brevo | Email/SMS | ✓ | - | [✓](clis/brevo.js) | ✓ | [brevo.md](integrations/brevo.md) |
| activecampaign | Email/CRM | ✓ | - | [✓](clis/activecampaign.js) | ✓ | [activecampaign.md](integrations/activecampaign.md) |
| twilio | SMS/Voice | ✓ | - | ✓ | ✓ | [twilio.md](integrations/twilio.md) |
| plivo | SMS/Voice | ✓ | - | - | ✓ | [plivo.md](integrations/plivo.md) |
| postscript | SMS | ✓ | - | - | - | [postscript.md](integrations/postscript.md) |
| attentive | SMS | ✓ | - | - | - | [attentive.md](integrations/attentive.md) |
| audiencetap | SMS/Email | ✓ | - | - | - | [audiencetap.md](integrations/audiencetap.md) |
| hunter | Email Outreach | ✓ | ✓ | [✓](clis/hunter.js) | - | [hunter.md](integrations/hunter.md) |
| snov | Email Outreach | ✓ | - | [✓](clis/snov.js) | - | [snov.md](integrations/snov.md) |
| truelist | Email Verification | ✓ | ✓ | [✓](clis/truelist.js) | ✓ | [truelist.md](integrations/truelist.md) |
| github | Developer Intent | ✓ | - | [✓](clis/github-prospects.js) | ✓ | [github.md](integrations/github.md) |
| firecrawl | Site Scraping & AI Search | ✓ | ✓ | [✓](clis/firecrawl.js) | ✓ | [firecrawl.md](integrations/firecrawl.md) |
| browserbase | Site Scraping | ✓ | ✓ | - | ✓ | [browserbase.md](integrations/browserbase.md) |
| apify | Site Scraping | ✓ | ✓ | ✓ | ✓ | [apify.md](integrations/apify.md) |
| lemlist | Email Outreach | ✓ | ✓ | [✓](clis/lemlist.js) | - | [lemlist.md](integrations/lemlist.md) |
| instantly | Email Outreach | ✓ | ✓ | [✓](clis/instantly.js) | - | [instantly.md](integrations/instantly.md) |
| google-ads | Ads | ✓ | ✓ | [✓](clis/google-ads.js) | ✓ | [google-ads.md](integrations/google-ads.md) |
| meta-ads | Ads | ✓ | ✓ | [✓](clis/meta-ads.js) | ✓ | [meta-ads.md](integrations/meta-ads.md) |
| linkedin-ads | Ads | ✓ | - | [✓](clis/linkedin-ads.js) | - | [linkedin-ads.md](integrations/linkedin-ads.md) |
| tiktok-ads | Ads | ✓ | - | [✓](clis/tiktok-ads.js) | ✓ | [tiktok-ads.md](integrations/tiktok-ads.md) |
| zapier | Automation | ✓ | ✓ | [✓](clis/zapier.js) | ✓ | [zapier.md](integrations/zapier.md) |
| hotjar | CRO | ✓ | - | [✓](clis/hotjar.js) | - | [hotjar.md](integrations/hotjar.md) |
| optimizely | A/B Testing | ✓ | - | [✓](clis/optimizely.js) | ✓ | [optimizely.md](integrations/optimizely.md) |
| calendly | Scheduling | ✓ | ✓ | [✓](clis/calendly.js) | - | [calendly.md](integrations/calendly.md) |
| savvycal | Scheduling | ✓ | - | [✓](clis/savvycal.js) | - | [savvycal.md](integrations/savvycal.md) |
| typeform | Forms | ✓ | - | [✓](clis/typeform.js) | ✓ | [typeform.md](integrations/typeform.md) |
| intercom | Messaging | ✓ | - | [✓](clis/intercom.js) | ✓ | [intercom.md](integrations/intercom.md) |
| outreach | Sales Engagement | ✓ | ✓ | [✓](clis/outreach.js) | - | [outreach.md](integrations/outreach.md) |
| heyreach | LinkedIn Outreach | ✓ | ✓ | ✓ | - | [heyreach.md](integrations/heyreach.md) |
| crossbeam | Partner Ecosystem | ✓ | ✓ | [✓](clis/crossbeam.js) | - | [crossbeam.md](integrations/crossbeam.md) |
| introw | Partner Ecosystem | - | ✓ | - | - | [introw.md](integrations/introw.md) |
| pendo | Product Analytics | ✓ | - | [✓](clis/pendo.js) | - | [pendo.md](integrations/pendo.md) |
| similarweb | Competitive Intelligence | ✓ | - | [✓](clis/similarweb.js) | - | [similarweb.md](integrations/similarweb.md) |
| exa | AI Search | ✓ | ✓ | [✓](clis/exa.js) | ✓ | [exa.md](integrations/exa.md) |
| firehose | Competitive Intelligence | ✓ | - | - | - | [firehose.md](integrations/firehose.md) |
| sparktoro | Audience Research | - | - | - | - | [sparktoro.md](integrations/sparktoro.md) |
| rb2b | Visitor Identification | ✓ | - | - | - | [rb2b.md](integrations/rb2b.md) |
| theirstack | Hiring & Tech Signals | ✓ | ✓ | - | - | [theirstack.md](integrations/theirstack.md) |
| gong | Revenue Intelligence | ✓ | - | - | - | [gong.md](integrations/gong.md) |
| airops | AI Content | ✓ | - | [✓](clis/airops.js) | - | [airops.md](integrations/airops.md) |
| buffer | Social | ✓ | - | [✓](clis/buffer.js) | - | [buffer.md](integrations/buffer.md) |
| wistia | Video | ✓ | - | [✓](clis/wistia.js) | - | [wistia.md](integrations/wistia.md) |
| heygen | Video | ✓ | ✓ | - | ✓ | [heygen.md](integrations/heygen.md) |
| hyperframes | Video | - | - | ✓ | ✓ | [hyperframes.md](integrations/hyperframes.md) |
| trustpilot | Reviews | ✓ | - | [✓](clis/trustpilot.js) | - | [trustpilot.md](integrations/trustpilot.md) |
| g2 | Reviews | ✓ | - | [✓](clis/g2.js) | - | [g2.md](integrations/g2.md) |
| onesignal | Push | ✓ | - | [✓](clis/onesignal.js) | ✓ | [onesignal.md](integrations/onesignal.md) |
| demio | Webinar | ✓ | - | [✓](clis/demio.js) | - | [demio.md](integrations/demio.md) |
| livestorm | Webinar | ✓ | - | [✓](clis/livestorm.js) | - | [livestorm.md](integrations/livestorm.md) |
| shopify | Commerce | ✓ | - | ✓ | ✓ | [shopify.md](integrations/shopify.md) |
| wordpress | CMS | ✓ | - | ✓ | ✓ | [wordpress.md](integrations/wordpress.md) |
| webflow | CMS | ✓ | - | ✓ | ✓ | [webflow.md](integrations/webflow.md) |
| sanity | Headless CMS | ✓ | - | ✓ | ✓ | [sanity.md](integrations/sanity.md) |
| contentful | Headless CMS | ✓ | - | ✓ | ✓ | [contentful.md](integrations/contentful.md) |
| strapi | Headless CMS | ✓ | - | ✓ | ✓ | [strapi.md](integrations/strapi.md) |
| composio | Integration Layer | ✓ | ✓ | ✓ | ✓ | [composio.md](integrations/composio.md) |
| cogny | Integration Layer | - | ✓ | - | - | [cogny.md](integrations/cogny.md) |
| glasser | Integration Layer | ✓ | ✓ | ✓ | - | [glasser.md](integrations/glasser.md) |

---

## By Category

### Analytics

Track user behavior, measure conversions, and analyze marketing performance.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **ga4** | Web analytics, Google ecosystem | ✓ |
| **mixpanel** | Product analytics, event tracking | - |
| **amplitude** | Product analytics, cohort analysis | - |
| **posthog** | Open-source analytics, session replay | - |
| **segment** | Customer data platform, routing | - |
| **adobe-analytics** | Enterprise analytics | - |
| **plausible** | Privacy-focused analytics | - |

**Agent recommendation**: Start with GA4 if using Google ecosystem. Use Mixpanel or Amplitude for deeper product analytics. Plausible for privacy-focused sites.

### SEO

Search engine optimization tools for keyword research, rank tracking, and site audits.

| Tool | Best For | Notes |
|------|----------|-------|
| **google-search-console** | Free, authoritative search data | Direct from Google |
| **semrush** | Competitive analysis, keyword research | Comprehensive |
| **ahrefs** | Backlink analysis, content research | Best for links |
| **dataforseo** | SERP tracking, backlinks, on-page audits | Comprehensive API |
| **keywords-everywhere** | Quick keyword research, traffic estimates | Credit-based |
| **rankparse** | Cheap, agent-friendly backlinks + domain data | Credit-based, MCP available |

**Agent recommendation**: Google Search Console is essential (free). Add Semrush or Ahrefs for competitive research. DataForSEO for programmatic SERP data. Keywords Everywhere for quick keyword lookups. RankParse for agent workflows where per-call cost matters — backlinks, domain authority, and tech stack at a fraction of enterprise pricing.

### CRM

Customer relationship management and sales tools.

| Tool | Best For | CLI Available |
|------|----------|:-------------:|
| **hubspot** | SMB, marketing + sales alignment | ✓ |
| **salesforce** | Enterprise, complex sales processes | ✓ |
| **close** | SMB, high-velocity sales | [✓](clis/close.js) |
| **attio** | Startups and agencies, flexible objects and lists | API + hosted MCP |

**Agent recommendation**: HubSpot for startups/SMBs. Attio for startups and agencies that want a flexible CRM an agent can read and write. Close for high-velocity inside sales. Salesforce for enterprise.

### Payments

Payment processing and subscription management.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **stripe** | SaaS subscriptions, developer-friendly | ✓ |
| **paddle** | SaaS billing with tax handling | - |

**Agent recommendation**: Stripe is the default for SaaS. Paddle for built-in tax compliance.

### Referral & Affiliate

Tools for referral programs, affiliate tracking, and partner management.

| Tool | Best For | Stripe Integration |
|------|----------|:------------------:|
| **rewardful** | Stripe-native affiliate programs | ✓ |
| **tolt** | SaaS affiliate programs | ✓ |
| **mention-me** | Enterprise referral programs | ✓ |
| **dub-co** | Link tracking, attribution | - |
| **partnerstack** | Enterprise partner programs | ✓ |

**Agent recommendation**: Rewardful or Tolt for Stripe-based SaaS. PartnerStack for enterprise partner programs. Dub.co for link attribution.

### Email

Email marketing, transactional email, and automation platforms.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **mailchimp** | SMB email marketing | ✓ |
| **customer-io** | Behavior-based messaging | - |
| **sendgrid** | Transactional email at scale | - |
| **resend** | Developer-friendly transactional | ✓ |
| **sequenzy** | Lifecycle email, sequences, transactional email | ✓ |
| **kit** | Creator/newsletter focused | - |
| **beehiiv** | Newsletter platform | - |
| **klaviyo** | E-commerce email + SMS | - |
| **postmark** | Deliverability-focused transactional | - |
| **brevo** | Email + SMS, popular in EU | - |
| **activecampaign** | Email automation + CRM | - |

**Agent recommendation**: Resend for transactional (dev-friendly). Sequenzy for lifecycle email, sequences, and agent-driven email marketing. Postmark for deliverability. Customer.io for advanced automation. Kit for creators. Beehiiv for newsletters. Klaviyo for e-commerce email/SMS. ActiveCampaign for email + CRM combo.

### SMS / Messaging

SMS and MMS marketing platforms and programmable messaging APIs.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **klaviyo** | DTC ecom already on Klaviyo email | - |
| **postscript** | Shopify DTC, SMS-first depth | - |
| **attentive** | Mid-market+ DTC, full-service | - |
| **twilio** | Custom API builds, transactional, dev-first | - |
| **plivo** | Twilio alternative, lower per-send cost | - |
| **audiencetap** | DTC with AI-forward creative + on-pack QR opt-in | - |
| **brevo** | EU SMB email + SMS combo | - |
| **customer-io** | Behavior-based SMS automation | - |

**Agent recommendation**: Klaviyo SMS for ecom already on Klaviyo email. Postscript for Shopify-first depth. Attentive for mid-market+ wanting concierge support. Twilio (or Plivo for lower cost) for custom builds and transactional/auth. AudienceTap when AI creative or on-pack QR opt-in matters.

### Advertising

Paid advertising platforms and campaign management.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **google-ads** | Search intent, high-intent traffic | ✓ |
| **meta-ads** | Demand gen, visual products, B2C | ✓ |
| **linkedin-ads** | B2B, job title targeting | - |
| **tiktok-ads** | Younger demographics, video | - |

**Agent recommendation**: Google Ads for search intent. Meta for demand generation. LinkedIn for B2B.

### Automation

Workflow automation and integration platforms.

| Tool | Best For | MCP Available |
|------|----------|:-------------:|
| **zapier** | No-code integrations + SDK for 8,000+ apps | ✓ |

**Agent recommendation**: Zapier SDK for agents that need to interact with any app directly. Zaps for always-on automations.

### CRO & A/B Testing

Conversion rate optimization, heatmaps, and experimentation.

| Tool | Best For | Notes |
|------|----------|-------|
| **hotjar** | Heatmaps, recordings, surveys | Visual behavior data |
| **optimizely** | A/B testing, feature flags | Enterprise experimentation |

**Agent recommendation**: Hotjar for understanding user behavior. Optimizely for running experiments.

### Scheduling

Booking and appointment scheduling tools.

| Tool | Best For | Notes |
|------|----------|-------|
| **calendly** | Meeting scheduling, lead gen | Most popular |
| **savvycal** | Personalized scheduling | Developer-friendly |

**Agent recommendation**: Calendly for general use. SavvyCal for personalized booking experiences.

### Forms & Surveys

Form builders and survey platforms.

| Tool | Best For | Notes |
|------|----------|-------|
| **typeform** | Interactive forms, surveys | Conversational UX |

**Agent recommendation**: Typeform for engaging forms and surveys.

### Messaging

In-app messaging, chat, and customer communication.

| Tool | Best For | Notes |
|------|----------|-------|
| **intercom** | In-app messaging, support, product tours | Full customer platform |

**Agent recommendation**: Intercom for in-app messaging and customer support.

### Social Media

Social media scheduling, management, and analytics.

| Tool | Best For | Notes |
|------|----------|-------|
| **buffer** | Social scheduling, analytics | Multi-platform |

**Agent recommendation**: Buffer for scheduling and analytics across social platforms.

### Video

Video hosting, creation, and AI generation.

| Tool | Best For | Notes |
|------|----------|-------|
| **wistia** | Video hosting, marketing analytics | Best for marketing video hosting |
| **heygen** | AI avatars, talking-head videos | MCP server available |
| **hyperframes** | Programmatic video from HTML/CSS | Open source, agent-native |

**Agent recommendation**: HeyGen for AI avatar videos (MCP-enabled). Hyperframes for templated, data-driven video from code. Wistia for hosting and analytics.

### Data Enrichment

Company and person data enrichment for sales and marketing.

| Tool | Best For | Notes |
|------|----------|-------|
| **clearbit** | Company/person enrichment (existing API keys only) | Now HubSpot Breeze Intelligence; no new standalone API keys; Logo API ended 2025-12-08 |
| **apollo** | B2B prospecting, email finding | Large database |
| **zoominfo** | B2B contacts, intent data | Enterprise-grade |
| **clay** | Waterfall enrichment, outbound | 75+ data providers |
| **fullenrich** | Waterfall email + mobile finding | Many providers per lookup; charges only on a hit; verify its catch-all results |
| **leadmagic** | Email finding, job changes, technographics, lookalikes | Credit-based API; charges only on a hit |
| **rowbound** | Open-source Sheets enrichment, waterfalls | MIT · CLI + MCP · self-hosted/BYOK Clay alternative |

**Agent recommendation**: Apollo for prospecting and outbound. Clearbit only if you already hold a legacy API key (otherwise Breeze Intelligence inside HubSpot). ZoomInfo for enterprise B2B data with intent signals. Clay for waterfall enrichment across multiple providers. Rowbound is the open-source, self-hosted alternative to Clay: native waterfalls from a Google Sheet, driven by CLI or MCP with your own provider keys.

### Email Verification

Pre-outreach email deliverability validation.

| Tool | Best For | Notes |
|------|----------|-------|
| **truelist** | Bulk + single email verification, catch-all resolution | Returns `email_state` (ok / email_invalid / accept_all / risky / unknown) + `email_sub_state`. Batches with webhook + CSV results, `enhanced` strategy for catch-alls. Hosted OAuth MCP, CLI, 7-language SDKs. |

**Agent recommendation**: Truelist for any prospect list before outreach — Apollo/ZoomInfo/Hunter data accuracy is typically 60–80%, validation is non-negotiable to keep sender reputation healthy.

### Developer Intent / GitHub

Discovery channel for dev-tool SaaS prospecting via GitHub stargazers, forkers, and watchers.

| Tool | Best For | Notes |
|------|----------|-------|
| **github** | Stargazers / forks / watchers of competitor or adjacent repos | Public API; pair with Apollo/Clay/Hunter for email enrichment |

**Agent recommendation**: Use `github-prospects.js` CLI to pull stargazers/forks of 3–5 anchor repos (competitors, category leaders, complementary tools). Filter to users with `company` field set, then enrich missing emails via Apollo or Hunter, then validate via Truelist before outreach.

### Site Scraping (single-target only)

Programmatic page extraction for **individual public business sites** — not for the platforms hosting prospects (Google Maps, LinkedIn, Yelp, Apollo, etc.).

| Tool | Best For | Notes |
|------|----------|-------|
| **firecrawl** | Page → clean markdown / structured extraction | API + MCP; lower overhead for "just give me the content" |
| **browserbase** | Real Chromium when rendering, interaction, or session state is required | API + MCP (Stagehand); use when Firecrawl can't handle the page |
| **apify** | Ready-made scrapers for public directories, marketplaces, job boards, and site crawls | API + hosted MCP; per-Actor pricing; never LinkedIn or Google Maps scrapers |

**Agent recommendation**: Default to Firecrawl for static-ish pages and structured extraction. Use Browserbase when the site requires JS rendering, form interaction, cookie consent, or auth — and when you want session recordings for debugging. **For both: discovery happens on platforms (manual browser); extraction happens on the prospect's own website URL.** Don't point either tool at LinkedIn, Google Maps, Yelp, or similar.

### Reviews

Review management and social proof platforms. For honest invitation programs, response triage, and permissioned testimonial reuse, use the referrals skill's [review programs reference](https://github.com/coreyhaines31/marketingskills/blob/main/skills/referrals/references/review-programs.md). Platform incentive and collection rules differ; consult its conditional policy reference before a campaign.

| Tool | Best For | Notes |
|------|----------|-------|
| **trustpilot** | Consumer business reviews | Most recognized |
| **g2** | Software/B2B reviews | Best for SaaS |

**Agent recommendation**: Trustpilot for consumer products. G2 for B2B software.

### Push Notifications

Push notification delivery platforms.

| Tool | Best For | Notes |
|------|----------|-------|
| **onesignal** | Multi-channel push notifications | Web + mobile |

**Agent recommendation**: OneSignal for web and mobile push notifications.

### Webinar

Webinar and virtual event platforms.

| Tool | Best For | Notes |
|------|----------|-------|
| **demio** | Marketing webinars | Simple, focused |
| **livestorm** | Video engagement, webinars | Full event platform |

**Agent recommendation**: Demio for marketing-focused webinars. Livestorm for full event engagement.

### Sales Engagement

Sales engagement and outreach automation platforms.

| Tool | Best For | Notes |
|------|----------|-------|
| **outreach** | Enterprise sales engagement | Sequences, tasks, analytics |

**Agent recommendation**: Outreach for enterprise sales teams managing multi-touch sequences at scale.

### LinkedIn Outreach

LinkedIn connection requests, messages, and inbox across sender accounts. All third-party LinkedIn automation breaks LinkedIn's User Agreement and risks account restrictions.

| Tool | Best For | Notes |
|------|----------|-------|
| **heyreach** | Multi-sender LinkedIn campaigns, email + LinkedIn with Instantly/Smartlead | API + official per-workspace MCP; LinkedIn removed its company page in March 2026 |

**Agent recommendation**: Use real, owned profiles only, keep each sender well under weekly connection limits, and stop LinkedIn steps when a prospect replies on any channel. Alternatives: lemlist and La Growth Machine (email + LinkedIn in one sequence), Expandi, Waalaxy, Unipile (API for builders).

### Product Analytics

Product analytics, feature adoption tracking, and in-app guidance.

| Tool | Best For | Notes |
|------|----------|-------|
| **pendo** | Feature adoption, in-app guides | Product-led growth |

**Agent recommendation**: Pendo for tracking feature adoption and delivering targeted in-app guidance.

### Competitive Intelligence

Traffic analytics, competitor benchmarking, and market research.

| Tool | Best For | Notes |
|------|----------|-------|
| **similarweb** | Website traffic, competitor analysis | Traffic sources, keywords |

**Agent recommendation**: Similarweb for competitor traffic analysis and market benchmarking.

### Audience Research

Audience intelligence and behavioral research tools.

| Tool | Best For | Notes |
|------|----------|-------|
| **sparktoro** | Audience affinities, behavioral data | Clickstream + social data |

**Agent recommendation**: SparkToro for discovering where your ICP spends time — what they read, watch, listen to, follow, and search for. Essential for customer research, content strategy, and media buying decisions.

### Visitor Identification

Website visitor de-anonymization for B2B sales and marketing.

| Tool | Best For | Notes |
|------|----------|-------|
| **rb2b** | Person-level visitor ID, intent signals | LinkedIn profiles, emails, page-level data |

**Agent recommendation**: RB2B for identifying anonymous B2B website visitors and routing high-intent visitors to outreach tools. Pairs well with Clay for enrichment and Instantly/Lemlist for cold email.

### Hiring & Tech Signals

Buying signals from job postings and technology adoption: who is hiring for a role you serve, and who uses (or just adopted) a relevant tool.

| Tool | Best For | Notes |
|------|----------|-------|
| **theirstack** | Companies hiring for a role; tech stack inferred from job postings | API + hosted MCP (OAuth or API key); webhooks for new postings |
| **leadmagic** | Job-change checks for past champions; per-company technographics and funding | Credit-based API + MCP |

**Agent recommendation**: Use hiring and tech signals to time and justify outreach, not as the whole list. Combine 2–3 signals with ICP fit, and act within days of a fresh signal.

### Revenue Intelligence

Sales conversation analytics, call recording, and deal intelligence.

| Tool | Best For | Notes |
|------|----------|-------|
| **gong** | Call recording, transcript analysis, deal insights | REST API, 10k API calls/day |

**Agent recommendation**: Gong for mining sales call transcripts for customer research, competitive intelligence, and coaching insights. Essential for revenue attribution and win/loss analysis.

### AEO (Answer Engine Optimization)

Answer engine optimization tools for AI visibility monitoring, competitor benchmarking, citation analysis, and content optimization.

| Tool | Best For | Notes |
|------|----------|-------|
| **[omnia](integrations/omnia.md)** | AI visibility monitoring, prompt discovery, competitor benchmarking, citation analysis, and agent-assisted content optimization and outreach | REST API + OAuth MCP for data access; built-in agent for execution |

**Agent note**: Omnia is the only AEO tool with an integration guide here. The ai-seo skill's monitoring tools table lists the alternatives (Otterly AI, Peec AI, ZipTie, LLMrefs, Profound, Ahrefs Brand Radar, Semrush) and a DIY method; choose on coverage and fit. With Omnia, use MCP for interactive analysis or the API for recurring reports; the built-in Omnia Agent handles content updates, publishing, and outreach with user approval.

### AI Content

AI-powered content generation and optimization platforms.

| Tool | Best For | Notes |
|------|----------|-------|
| **airops** | AI content workflows, SEO content | Flow-based automation |

**Agent recommendation**: AirOps for building AI content workflows that generate SEO-optimized content at scale.

### AI Search

AI-powered web search APIs built for LLMs and agents. Return structured results with on-demand text, highlights, and summaries.

| Tool | Best For | Notes |
|------|----------|-------|
| **exa** | Neural/semantic web search, content research, competitor discovery | Search + findSimilar + Contents; MCP and SDKs available |

**Agent recommendation**: Exa for neural search over the open web — content research, competitor/similar-page discovery, link prospecting, news monitoring, and audience research. Pairs well with seo-audit, content-strategy, and competitor-profiling skills.

### Partner Ecosystem

Partner data sharing, co-sell, and ecosystem management.

| Tool | Best For | Notes |
|------|----------|-------|
| **crossbeam** | Account overlaps, co-sell | Now part of Reveal |
| **introw** | Partner management, deal registration, QBRs | MCP-enabled PRM |

**Agent recommendation**: Crossbeam for identifying partner account overlaps and co-sell opportunities. Introw for full partner relationship management — partner pipeline, commissions, tasks, and automated business review prep.

### Email Outreach

Cold email outreach and email finding tools for link building and sales prospecting.

| Tool | Best For | Notes |
|------|----------|-------|
| **hunter** | Email finding, domain search | Largest email database |
| **snov** | Email finding, drip campaigns | Built-in sequences |
| **lemlist** | Cold email campaigns | Personalization features |
| **instantly** | Cold email at scale | Email warmup built-in |

**Agent recommendation**: Hunter for finding emails. Instantly for email-only cold campaigns at volume; lemlist when the sequence mixes email and LinkedIn. Snov for combined finding + outreach. Verify every list (Truelist) before upload, and send from secondary domains.

### Data Aggregation

Marketing data pipeline tools that connect multiple platforms for unified reporting.

| Tool | Best For | Notes |
|------|----------|-------|
| **supermetrics** | Cross-platform data pulling | 200+ connectors |
| **coupler** | Automated data flows to sheets/BI | Scheduled pipelines |

**Agent recommendation**: Supermetrics for pulling data from multiple marketing platforms into unified reports. Coupler.io for automated data flows to spreadsheets and BI tools.

### Commerce & CMS

E-commerce platforms and content management systems.

| Tool | Best For | CLI Available |
|------|----------|:-------------:|
| **shopify** | E-commerce, product sales | ✓ |
| **wordpress** | Blogs, content sites | ✓ |
| **webflow** | Design-focused marketing sites | ✓ |
| **sanity** | Headless CMS, structured content | ✓ |
| **contentful** | Enterprise headless CMS, multi-locale | ✓ |
| **strapi** | Open-source headless CMS, self-hosted | ✓ |

**Agent recommendation**: Shopify for e-commerce. Webflow for marketing sites. WordPress for blogs. For headless CMS: Sanity for developer-flexible content, Contentful for enterprise multi-locale, Strapi for self-hosted/budget-conscious. See [headless CMS guide](../skills/content-strategy/references/headless-cms.md) for selection criteria.

---

## CLI Tools

Zero-dependency, single-file Node.js CLIs for tools that don't ship their own. See [`clis/README.md`](clis/README.md) for install instructions and usage.

All CLIs follow a consistent pattern:
- **No dependencies** — Node 18+ only, uses native `fetch`
- **JSON output** — pipe to `jq`, save to file, or use in scripts
- **Env var auth** — set `{TOOL}_API_KEY` and go
- **Consistent commands** — `{tool} <resource> <action> [options]`

---

## MCP-Enabled Tools

These tools have Model Context Protocol servers available, enabling direct agent interaction:

- **ga4** - Google Analytics 4 data access
- **stripe** - Payment and subscription management
- **mailchimp** - Email campaign management
- **google-ads** - Ad campaign management
- **resend** - Transactional email sending
- **zapier** - Workflow automation + SDK for 8,000+ app integrations
- **zoominfo** - B2B contacts and intent data
- **clay** - Data enrichment and outbound automation
- **supermetrics** - Cross-platform marketing data
- **coupler** - Marketing data pipelines
- **outreach** - Sales engagement sequences
- **crossbeam** - Partner ecosystem data
- **introw** - Partner relationship management
- **omnia** - AI visibility, competitor mentions, and citation data (OAuth)
- **exa** - AI-powered web search for LLMs and agents
- **apollo** - B2B prospecting, enrichment, and sequences
- **hubspot** - CRM read and write
- **attio** - CRM read and write (writes need confirmation)
- **close** - CRM and inside sales
- **instantly** - Cold email campaigns, leads, replies, and warmup
- **lemlist** - Email + LinkedIn sequences
- **heyreach** - LinkedIn outreach (per-workspace MCP key)
- **hunter** - Email finding and verification
- **truelist** - Email verification and batches
- **fullenrich** - Waterfall email and mobile enrichment
- **leadmagic** - Enrichment, job changes, technographics
- **rowbound** - Open-source Sheets enrichment with waterfalls (stdio MCP)
- **theirstack** - Hiring and technographic signals
- **apify** - Ready-made scrapers (Actors)
- **firecrawl** - Page scraping and crawling
- **browserbase** - Cloud browser automation
- **calendly** - Availability and booking links

To use MCP tools, ensure the appropriate MCP server is configured in your environment. Most hosted servers sign in with per-user OAuth, which suits interactive sessions; for scheduled or unattended agent runs, use the tool's API key (with the CLI or API, or an MCP that accepts a key header). MCP status checked 2026-10-07.

### Composio Integration

[Composio](integrations/composio.md) provides managed OAuth and pre-built connectors for 500+ tools via a single MCP server. It adds MCP access to tools that don't have native MCP servers, including Salesforce, LinkedIn Ads, Google Sheets, Slack, Notion, and more. (HubSpot and Meta Ads now have their own official MCP servers.)

- **Setup**: `npx @composio/mcp@latest setup`
- **Quick start**: See [tools/composio/README.md](composio/README.md)
- **Marketing tool mapping**: See [tools/composio/marketing-tools.md](composio/marketing-tools.md)

Use Composio when you need MCP access to OAuth-heavy tools. Prefer native MCP servers (GA4, Stripe, Mailchimp, etc.) when available — they have deeper coverage.

### AIsa Data Access

[◆ AIsa](integrations/aisa.md) offers access to supported SEO, search, social, and company-data providers through one account. Check operation coverage, account access, and pricing before choosing it alongside direct provider connections or manual exports. Its data access serves a different need from connecting existing SaaS accounts through Composio.

- **Quick start**: [tools/aisa/README.md](aisa/README.md)
- **Coverage and alternatives**: [tools/aisa/coverage-map.md](aisa/coverage-map.md)
- **Evaluation scenarios**: [tools/aisa/evals/README.md](aisa/evals/README.md)

### Cogny Integration

[Cogny](integrations/cogny.md) is a hosted MCP gateway focused on marketing channels — one federated MCP URL with managed OAuth across every channel you've connected. Narrower than Composio (marketing-only) and useful when you want SEO, paid social, and privacy-friendly analytics behind a single MCP login.

- **Setup**: connect channels at [cogny.com](https://cogny.com), then in Claude.ai go to Settings → Connectors → Add custom connector and paste `https://app.cogny.com/mcp`
- **Channels**: Search Console, Bing Webmaster, Semrush, LinkedIn Ads, Reddit Ads, TikTok Ads, Plausible, Fathom
- **Pricing**: Solo plan starts at $9/mo (7-day trial)

Use Cogny when you only need marketing channels and want to avoid running your own OAuth proxy. Prefer native APIs when you need deep, custom control of a single tool.

### Glasser Integration

[Glasser](integrations/glasser.md) is a pay-per-call broker for paid data APIs — SEO metrics, SERP, web/news search, company and person enrichment, email finding, social scraping — under one key. Data APIs only; OAuth tools (GA4, ad platforms, CRMs) are not covered.

- **Setup**: `npm install -g @glasser-ai/cli && glasser login`, or MCP at `https://api.glasser.ai/mcp` with a Bearer key
- **Providers**: 20+ across SEO, search, enrichment, email finding, and scraping — DataForSEO, Ahrefs, Semrush, Serper, SerpApi, Exa, People Data Labs, Apollo, ZoomInfo, Hunter, ScrapeCreators, TikHub, Apify, Bright Data, and others (full list in the guide)
- **Pricing**: per call at the price each endpoint publishes; no subscription

Use Glasser for occasional lookups across several paid vendors when no accounts are set up. Prefer a vendor's own API when you already hold its key, and Google Search Console for your own site's search data.

---

## Quick Start by Use Case

### Setting up analytics tracking
1. Read [ga4.md](integrations/ga4.md) for web analytics
2. Read [segment.md](integrations/segment.md) if routing to multiple tools

### Launching a referral program
1. Read [rewardful.md](integrations/rewardful.md) or [tolt.md](integrations/tolt.md) for Stripe-based programs
2. Read [dub-co.md](integrations/dub-co.md) for link tracking

### Setting up email automation
1. Read [customer-io.md](integrations/customer-io.md) for behavior-based automation
2. Read [resend.md](integrations/resend.md) for transactional email

### Running sales outbound (list → signals → enrich → verify → send → LinkedIn → CRM)

Strategy, copy, cadence, and compliance live in the `prospecting` and `cold-email` skills; this is the tool chain. Pick one tool per job; alternatives are listed so no single vendor is required.

| Step | Job | Tools (alternatives) | Claude Code (CLI/API) | Hosted agent (MCP) |
|------|-----|----------------------|:---------------------:|:------------------:|
| 1 | Build the account list | [apollo](integrations/apollo.md), [zoominfo](integrations/zoominfo.md), [clay](integrations/clay.md), [exa](integrations/exa.md) (lookalikes), [leadmagic](integrations/leadmagic.md) (lookalikes), [apify](integrations/apify.md) (public directories) | ✓ | ✓ |
| 2 | Add buying signals | [theirstack](integrations/theirstack.md) (hiring, tech), [leadmagic](integrations/leadmagic.md) (job changes), [rb2b](integrations/rb2b.md) (site visitors), [github](integrations/github.md) (dev intent) | ✓ | ✓ (rb2b via Zapier) |
| 3 | Find contacts and emails | [apollo](integrations/apollo.md), [fullenrich](integrations/fullenrich.md) (waterfall), [leadmagic](integrations/leadmagic.md), [hunter](integrations/hunter.md), [clay](integrations/clay.md) | ✓ | ✓ |
| 4 | Verify before sending | [truelist](integrations/truelist.md) (catch-all resolution) | ✓ | ✓ |
| 5 | Send email sequences | [instantly](integrations/instantly.md), [lemlist](integrations/lemlist.md), [outreach](integrations/outreach.md) (enterprise) | ✓ | ✓ |
| 6 | LinkedIn steps | [heyreach](integrations/heyreach.md), [lemlist](integrations/lemlist.md) (email + LinkedIn) | API | ✓ |
| 7 | Book meetings | [calendly](integrations/calendly.md), [savvycal](integrations/savvycal.md) | ✓ | ✓ (calendly) |
| 8 | Log in the CRM | [hubspot](integrations/hubspot.md), [attio](integrations/attio.md), [close](integrations/close.md), [salesforce](integrations/salesforce.md) | ✓ | ✓ (salesforce via [composio](integrations/composio.md)) |
| 9 | Retarget target accounts | [linkedin-ads](integrations/linkedin-ads.md) (Matched Audiences) | ✓ | via composio |

**Rules that apply to every run:**
- **Verify every list before it reaches a sender** (step 4), and re-verify anything older than 30–60 days. Keep hard bounces under 2%.
- **One suppression list across tools**: customers, open deals, opt-outs from any channel, and past bounces, synced to every sender's blocklist.
- **A reply on any channel stops every channel** (email, LinkedIn, calls) for that person.
- **No LinkedIn scraping** with logged-in accounts, cookies, or fake profiles, and no Google Maps scrapers.
- **Hosted MCPs mostly sign in with per-user OAuth**, which suits interactive sessions with a human approving writes. Scheduled or unattended runs (a nightly signal sweep, reply triage) should use API keys through the CLIs or APIs, or MCPs that accept a key header (Instantly, Apollo, lemlist, Hunter, TheirStack, Firecrawl).
- **Stage outward-facing actions for approval** until the workflow has a track record: new campaigns, first sends to a segment, and CRM writes.

### Running email outreach for backlinks
1. Read [hunter.md](integrations/hunter.md) for finding emails
2. Read [lemlist.md](integrations/lemlist.md) or [instantly.md](integrations/instantly.md) for sending campaigns

### Running paid ads
1. Read [google-ads.md](integrations/google-ads.md) for search campaigns
2. Read [meta-ads.md](integrations/meta-ads.md) for social campaigns

## File: tools/SETUP.md

# Guided Marketing Tool Connections

Use this workflow when a user wants to connect marketing accounts to their local coding agent. It bridges the [tool registry](REGISTRY.md), provider integration guides, and [repository CLIs](clis/README.md). It is separate from the `onboarding` skill, which improves a product's customer activation.

## 1. Check the Environment Before Collecting Credentials

For local CLI setup, confirm that the agent can run commands and edit private files in the user's chosen workspace. For hosted MCP, check whether the client can add the selected connector and complete its authentication flow. If neither setup method is available, explain the limitation and offer these instructions for a compatible client; do not ask the user to paste credentials into chat.

For a repository CLI, confirm the checkout path, then run `node --version` and check that the selected CLI exists. The repository CLIs require Node 18+ and no dependency installation. A hosted MCP connection instead needs the selected client's connector support; it does not require a repository CLI or Node installation. The optional `--env-file` examples below require Node 20.6+; check `node --help` for support. On older Node versions, use the agent client's environment/secret configuration instead, or ask before installing a supported runtime. Do not silently change the user's runtime or system configuration.

## 2. Select Only the Needed Tools

Ask which tools the user wants to connect and which account/property and environment (sandbox or production) to use. Work on one chosen tool at a time. Do not create applications, request unrelated scopes, or configure all tools by default.

For SEO, search, social, or company data, options include direct providers in the [registry](REGISTRY.md), [AIsa](aisa/README.md), and manual exports. [Composio](composio/README.md) is another option for connecting supported SaaS accounts. Choose based on the required operation, existing access, and cost; partner status does not select the provider.

Keep each setup message to 3–5 lines: one action, why it is needed, the official link, and what nonsensitive confirmation to return. Wait for the user after app creation, permission approval, token generation, redirect setup, or account selection. Reuse completed steps and existing authorization. Never ask them to return a token, client secret, refresh token, or private key.

Example:

> We'll connect only GA4, using a read-only report first.
> Open your Google Analytics property and confirm the numeric property ID.
> Keep your access token in the local private file; don't paste it here.
> Tell me when it's saved and which property to read.

## 3. Store Selected Credentials Locally

For client-managed OAuth, complete sign-in in the client; no local credential file is needed. For key or token variables, use the user's existing secret manager or environment setup when available. Otherwise, with their permission create `.env.marketing` in the chosen workspace. Do not overwrite an existing file. In a POSIX shell, this creates an empty owner-private file and fails if it already exists:

```bash
(umask 077; set -C; : > .env.marketing)
```

Build a template with only the chosen tool's variables from the table below. Use empty quoted values such as `GA4_ACCESS_TOKEN=""`; the user fills secrets in a local editor. Do not print the completed file or log values. The repository ignores `.env` and `.env.*`; in a different workspace verify or add that ignore rule **before** saving secrets. Check `git check-ignore .env.marketing` and `git ls-files --error-unmatch .env.marketing`: the file must be ignored and untracked. Gitignore does not untrack a previously committed file; if secrets were committed, stop and arrange removal and rotation with the user.

| Tool | Local variables | Boundary |
|------|-----------------|----------|
| Google Ads | `GOOGLE_ADS_TOKEN`, `GOOGLE_ADS_CUSTOMER_ID`; optional `GOOGLE_ADS_LOGIN_CUSTOMER_ID` | OAuth access token, target ID without hyphens; manager ID only when acting through a manager |
| Meta Ads | `META_ACCESS_TOKEN`; optional `META_AD_ACCOUNT_ID` | Account access and token permissions must match the intended read |
| LinkedIn Ads | `LINKEDIN_ACCESS_TOKEN` | Advertising API-approved app and member's ad-account access |
| GA4 | `GA4_ACCESS_TOKEN` | OAuth access token; numeric property ID is passed separately |
| Stripe | `STRIPE_API_KEY` for the HTTP example below | Restricted server-side key with permission to read customers; use a sandbox first |
| ◆ AIsa | `AISA_API_KEY` for a Bearer-key connection; none for MCP browser OAuth | Keep client-managed OAuth tokens in the client; account access and billing belong to the selected credential |

Refresh tokens and app secrets belong in the user's secret manager for the selected OAuth flow. The repository CLIs consume access tokens and do not refresh them automatically. Do not put refresh tokens into an access-token variable. The `.env.marketing` file is data: use Node's environment loader or client configuration, not shell `source`/`eval`.

## 4. Complete the Selected Provider's Flow

### Google Ads

1. Select/create the intended Google Cloud project and enable Google Ads API. Apply for the appropriate API access level in Cloud Console; access now belongs to the project that owns OAuth credentials. Developer tokens were sunset September 9, 2026. Do not apply for one through the retired manager-account API Center. See the [current migration guide](https://developers.google.com/google-ads/api/docs/api-policy/developer-token).
2. Follow Google's [single-user OAuth flow](https://developers.google.com/google-ads/api/docs/oauth/single-user-authentication): consent screen, `https://www.googleapis.com/auth/adwords` scope, and Desktop App client for that flow. For a Web App, follow its documented redirect/authorization flow instead; registered redirect URIs must match. Keep client secrets and refresh tokens local.
3. Obtain an access token through that flow and save it as `GOOGLE_ADS_TOKEN`. Confirm the target customer and optional manager IDs. OAuth authorization does not replace project API access or account permissions.
4. Inspect the installed CLI's requirements. Older checkouts still require `GOOGLE_ADS_DEVELOPER_TOKEN`; new Cloud-project setups should update to a CLI that supports token-free project access. Do not invent a developer token to satisfy a local check. Existing legacy setups may still supply their token while updating.

### Meta Ads

1. Use an app associated with the intended business and user/account access. Follow [Marketing API authentication](https://developers.facebook.com/docs/marketing-api/get-started/authentication/). For a first reporting read, request the applicable `ads_read` permission rather than campaign-edit permissions by default.
2. Generate a user token through the documented flow. For longer use, follow the provider's token-extension flow (including Access Token Debugger's extension option when available), then inspect the resulting app, scopes, and expiration. Do not assume a fixed lifetime or indefinite validity.
3. Save the resulting token locally as `META_ACCESS_TOKEN`. A system-user token is an alternative for an authorized business setup; it still needs assigned account assets and permissions. Do not exchange or change credentials without existing authorization or user approval.

### LinkedIn Ads

1. Create or select the user's app and request the Advertising API product in its Products tab. Approval is an external gate; check the application's current status and pause this tool while pending. Continue other selected tools. Do not promise a 1–2 day turnaround or bypass approval. [Official application process](https://www.linkedin.com/help/linkedin/answer/a524477).
2. Follow the app's OAuth flow with its registered redirect URI and only the permissions needed for the intended operation (for account/reporting reads, consult `r_ads` and `r_ads_reporting`). Save the resulting access token as `LINKEDIN_ACCESS_TOKEN`.
3. Verify member access to the intended ad account and the app's [access tier](https://learn.microsoft.com/en-us/linkedin/marketing/integrations/marketing-tiers). Development calls can access production data; tier labels do not make arbitrary writes safe. Use a current versioned CLI/API as described in the [integration guide](integrations/linkedin-ads.md).

### GA4

1. Follow the [Analytics Data API quickstart](https://developers.google.com/analytics/devguides/reporting/data/v1/quickstart): enable the Data API and authorize a user or service account with property access. Use the `analytics.readonly` scope for reporting.
2. Obtain an OAuth access token through the chosen flow; save it as `GA4_ACCESS_TOKEN`. The repository CLI does not read a service-account JSON file or Application Default Credentials itself. Convert those credentials to an access token through the documented tooling, without displaying it in chat.
3. Select the numeric GA4 property ID, not a `G-...` measurement ID. Measurement Protocol secrets are for event writes and are not needed for this reporting check.

### Stripe

1. Select the intended account and a sandbox for initial setup. In the Dashboard, create a restricted key with only the customer-read permission needed below. A publishable `pk_...` key cannot read account data; a webhook signing secret is not an API key. See [Stripe's key guide](https://docs.stripe.com/keys).
2. Save the restricted key locally as `STRIPE_API_KEY`. This repository has no `tools/clis/stripe.js`; use the provider's CLI/MCP or the read-only HTTP check below. Configure only the selected connection.

### AIsa

1. Review the [coverage map](aisa/coverage-map.md) for the requested data and alternatives. AIsa is a [◆ Verified Partner](REGISTRY.md#verified-partners); that status does not change provider selection.
2. Follow the [quick start](aisa/README.md#mcp-connection) to connect to `https://mcp.aisa.one/mcp` using browser OAuth or a Bearer key. Reuse a working connection and inspect the selected operation's actual contract.
3. Complete client-managed OAuth, or supply `AISA_API_KEY` through the client's secret/environment configuration for a key-based connection. There is no `tools/clis/aisa.js`; a remote MCP connection does not require installing a CLI.
4. Verify with the free protected check below. Before any paid data lookup, confirm its scope, pricing, and sufficient budget authorization using the [integration guide](integrations/aisa.md#run-a-lookup-with-a-budget).

## 5. Test a Small Read and Inspect the Response

Run from the repository root after the user authorizes the selected account read. These Node `--env-file` examples require Node 20.6+. With client-managed environment variables, omit `--env-file=.env.marketing`. Substitute the confirmed GA4 property ID.

```bash
node --env-file=.env.marketing tools/clis/google-ads.js account info
node --env-file=.env.marketing tools/clis/meta-ads.js accounts list
node --env-file=.env.marketing tools/clis/linkedin-ads.js accounts list
node --env-file=.env.marketing tools/clis/ga4.js reports run --property 123456789 --metrics activeUsers --start-date yesterday --end-date yesterday
```

Run only the chosen line. These checks read data; no campaign mutation, conversion creation, Measurement Protocol event, or payment is needed. Where supported, preview the selected request with `--dry-run` first. A preview proves local request shape, not connectivity or provider acceptance.

For Stripe with Node 20.6+, read at most one customer and print a count rather than customer details:

```bash
node --env-file=.env.marketing -e '
(async () => {
  if (!process.env.STRIPE_API_KEY) throw new Error("STRIPE_API_KEY required");
  const response = await fetch("https://api.stripe.com/v1/customers?limit=1", {
    headers: {Authorization: `Bearer ${process.env.STRIPE_API_KEY}`}
  });
  const data = await response.json();
  if (!response.ok || !Array.isArray(data.data)) throw new Error(`Stripe read failed (HTTP ${response.status})`);
  console.log(JSON.stringify({connected: true, returned: data.data.length}));
})().catch(error => { console.error(error.message); process.exitCode = 1; });
'
```

For AIsa MCP, inspect the client's `use` tool schema and invoke its documented free account read with `operation_id: "account"`, supplying other required fields according to that schema. An already configured AIsa CLI can use `aisa balance` instead. Report connection status without copying account details or identifiers into chat. Tool listings alone do not prove authenticated access, and setup must not trigger a paid lookup.

Check both process status **and** provider response. Some older CLIs can exit zero with an error payload. Record account/property, environment, operation, and outcome without secrets or customer data. Empty results can be a valid connection; they do not prove a broken account or permission to write.

| Failure | Next step |
|---------|-----------|
| Missing local variable | Verify variable names and how the client loads the private file; never print values |
| Expired/invalid token | Check expiry and the authorized refresh/login flow locally; do not repeatedly retry |
| Permission or project-access rejection | Check scopes, app approval, project access level, and account membership |
| Wrong account/property | Confirm the nonsensitive ID and sandbox/production context with the user |
| Rate limit or outage | Honor provider guidance; record blocked/pending rather than calling the connection ready |
| CLI route/version mismatch | Update or repair the checkout; do not request wider permissions to mask a client defect |

## 6. Finish with First Value

Report each selected tool as connected, waiting for user, waiting for provider approval, or failed with a specific next step. A completed setup for one tool does not imply the others are ready.

Offer a small read-only result: account inventory for Ads, yesterday's active users for GA4, an authorized sandbox billing check for Stripe, or a free AIsa connection check and a scoped proposal for data retrieval. Reuse permission already granted for that result; otherwise ask before accessing another account or a broader dataset. Route a full audit to the appropriate marketing skill. Campaign edits, sends, payments, and budget changes remain separate actions requiring the user's authorization.

## File: tools/PARTNERS.md

# Partner Program & Tools Registry — Rules & Boundaries

The single source of truth for how tools and partners work in this repository. If anything elsewhere is ambiguous, this document governs.

- **Public pitch & pricing:** [marketing-skills.com/sponsorship](https://marketing-skills.com/sponsorship)
- **Content rules for mentioning any tool:** [CONTRIBUTING.md → Mentioning Tools](../CONTRIBUTING.md#mentioning-tools-the-integrity-rubric)
- **The tool index itself:** [REGISTRY.md](REGISTRY.md)
- **The legal terms:** the Partner Agreement, provided to each partner (accepted at checkout)

## The one principle

**Sponsorship funds the work, never the recommendations.** Money buys a *disclosed presence*, never a bias. Every rule below follows from this. The library is free and MIT-licensed; sponsors and partners fund maintenance and new skills so the core stays free, open, and editorially independent — whoever is paying.

## Three kinds of tool entries

Every tool in [REGISTRY.md](REGISTRY.md) is exactly one of these:

| Kind | What it is | Who | Marker | Disclosure | Placement |
|---|---|---|---|---|---|
| **Tool integration** | A neutral integration guide for a real marketing tool with a programmatic surface | Anyone (incl. non-partners) can contribute one via PR | none | none required | Listed in the Tool Index / By Category |
| **◆ Verified Partner** | A tool whose maker funds the library (Skill or Category Partner) | Vetted, application-only, paid | ◆ | Disclosure header in its integration guide + ◆ in the registry + entry in `partners.json` | Verified Partners section + README + site + launch announcement |
| **House tool** | A tool built by the maintainer (e.g. Truelist) | The repo author | (noted) | **Stricter** than a partner — its guide states the repo author owns the tool | Held as a category House Tool; that slot is not for sale |

A partner integration is the *same* neutral integration guide as any other tool, plus disclosure and placement. It is not a different kind of content — it earns no softer editorial treatment.

## What sponsorship buys — and never buys

**Buys:**
- A dedicated, disclosed integration guide for the tool (◆).
- Featured placement — logo, link, blurb — on the README and the site.
- A launch announcement (tweet + LinkedIn + Swipe Files newsletter mention).
- For Category Partners: a category *slot* exclusivity + an "Official [Category] Partner" title/badge.

**Never buys:**
- A recommendation. No skill is edited to prefer a partner.
- Bias in any existing skill. Skills recommend the right tool for the job, partner or not.
- Exclusivity over what agents recommend. Category exclusivity is a *sponsorship-slot* exclusivity, never a recommendation exclusivity — a skill may still name a competitor when it's the right answer.
- Removal or demotion of any other tool. Partner entries are additive.
- A claim of "best in category." The badge means "paid, disclosed, vetted for fit."

## Tiers (summary)

Full pricing and perks live on the [sponsorship page](https://marketing-skills.com/sponsorship). In brief:

| Tier | Price | Billing | Gets |
|---|---|---|---|
| Supporter | $1–199/mo | GitHub Sponsors | README + site listing |
| Sponsor | $200/mo | GitHub Sponsors | Featured logo + link + blurb on README and site |
| **Skill Partner** | $500/mo | Stripe · 6-mo min | A disclosed ◆ integration + launch announcement + everything in Sponsor. **Non-exclusive.** |
| **Category Partner** | $1,500/mo | Stripe · 6-mo min | Category-slot exclusivity + official-partner title/badge + top category placement + quarterly Swipe Files feature + YouTube description slot + dual launch. Everything in Skill Partner. |

Partner tiers are **application-only** (vetted, then paid) and carry a **6-month minimum**. Annual prepay = two months free.

## Disclosure travels with the file

Disclosure is on the artifact, not just the site — skills and guides get forked and re-indexed across the ecosystem, so the disclosure must survive that.

A Verified Partner integration guide opens with this header:

```markdown
> **◆ Verified Partner integration.** [Tool] sponsors Marketing Skills. This integration
> is disclosed and vetted for fit; it does **not** change what any skill recommends. It's
> listed alongside the neutral options for the same job — use it when it's the right fit,
> not because it's a partner. See [Verified Partners](../REGISTRY.md#verified-partners).
```

Plus a ◆ marker in [REGISTRY.md](REGISTRY.md) and an entry in [`../partners.json`](../partners.json). A **House tool** additionally states in its guide that the repo author owns the tool.

## Editorial control & the integrity rubric

- **The maintainer holds final editorial control** and may edit or cut anything for neutrality and accuracy, at any time.
- **Any content that names a tool — partner or not — must pass the [integrity rubric](../CONTRIBUTING.md#mentioning-tools-the-integrity-rubric):** options not one answer, at the point of relevance, no forced endorsement, facts over framing, disclosed, and the *swap test* (swap the tool for a competitor and it should still read fair).
- **Partner integrations surface only at the point of relevance** — when a user is implementing or working with that tool. They never hijack generic queries and never insert themselves into a skill's recommendation as the answer.

## Category exclusivity (precise definition)

- **Skill Partner is non-exclusive.** Competitors may hold Skill Partner placements in the same category.
- **Category Partner buys a slot, not the answer.** No competing tool receives a Verified Partner integration or partner slot in that category while the agreement is active. It does **not** mean core skills only recommend that partner, and it does not restrict what any skill says. Categories are defined in writing in the agreement; a multi-category tool claims one category.
- **House-tool categories are not for sale** (e.g. email verification is held by Truelist).

## The partner lifecycle

1. **Apply** — application via the sponsorship page (vetted for fit).
2. **Agreement** — the Partner Agreement (6-month minimum), accepted at checkout.
3. **Pay** — Stripe; acceptance (version + timestamp) recorded with the subscription. Nothing publishes until the first payment clears.
4. **Onboard** — the partner submits logo, blurb, docs, and setup specifics via the onboarding form.
5. **Author** — the integration guide is drafted collaboratively; **the maintainer holds the pen** and final editorial control.
6. **Publish** — add the partner to [`../partners.json`](../partners.json), run [`../scripts/sync-partners.mjs`](../scripts/sync-partners.mjs) to regenerate the README + registry blocks, commit. The site reads `partners.json` directly.
7. **Renewal / lapse** — renewal is an explicit conversation, never an automatic charge. On lapse there's a **30-day notice period** where the integration is flagged as unmaintained before removal — installs are never silently broken. Deactivate with `"active": false` (keeps history, removes it from every surface).

## `tools/integrations/` spec (any tool, partner or not)

**What qualifies:** a real marketing tool with a programmatic surface an agent can use — an API, MCP server, and/or CLI. Neutral integrations are welcome from anyone via PR.

**Format** (match the existing guides, e.g. [`integrations/resend.md`](integrations/resend.md)):
- `# Tool Name` + a one-line description
- `## Capabilities` table — API / MCP / CLI / SDK availability with notes
- `## Authentication` — auth type; secrets go in env vars / a secret manager, never in the repo
- Setup + common operations (with real command/code examples)
- Links to official docs

**CLIs** (`../clis/*.js`) are zero-dependency Node 18+ scripts: show usage with no args, support `--dry-run`, and never require credentials just to print help. See [AGENTS.md](../CLAUDE.md) build/verify rules.

**A partner integration** is all of the above **plus** the disclosure header, the ◆ marker, and the `partners.json` entry.

## Single source of truth

The partner data lives once in [`../partners.json`](../partners.json). `sync-partners.mjs` generates the README Partners section and the Verified Partners table from it; the site fetches the same file. Edit one place, run the script, commit — every surface updates together. Run `node scripts/sync-partners.mjs --check` to verify nothing has drifted.

## File: tools/integrations/activecampaign.md

# ActiveCampaign

Email marketing automation platform with CRM, contacts, deals pipeline, tags, automations, and campaign management.

## Custom contact fields from the CLI

Discover the account's existing contact field IDs before assigning values:

```bash
node tools/clis/activecampaign.js fields list --search 'Plan' --limit 20 --offset 0
node tools/clis/activecampaign.js contacts sync --email owned@example.com \
  --field-values '[{"field":"12","value":"Enterprise"}]' --dry-run
```

Use the field definition's `id`, rather than its title, personalization tag,
or a field option ID. `fields list` returns one page of provider definitions,
including side-loaded options and relationships; use its `meta.total` and
`--offset` to continue. Search is a partial title match.

`--field-values` is available for contact `create`, `update`, and `sync`.
It preserves the supplied array under `contact.fieldValues`. Format each
value for the selected field type; the provider validates IDs, types,
and permissions. Omitting the option preserves the existing request.

Choose `sync` to create or update by email, `update --id` for an existing ID,
and `create` when an existing email should be rejected. Custom fields do not
subscribe a contact to a list or record marketing consent. Use the existing
list operations only when the user has authorized the subscription.
Preview with `--dry-run` before a user-authorized write; the preview masks
the API token and makes no request.

See the official [contact creation contract](https://developers.activecampaign.com/reference/create-a-new-contact),
[contact update contract](https://developers.activecampaign.com/reference/update-a-contact-new),
[email upsert contract](https://developers.activecampaign.com/reference/sync-a-contacts-data),
and [field discovery contract](https://developers.activecampaign.com/reference/retrieve-fields).

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v3 for contacts, deals, automations, campaigns, tags |
| MCP | - | Not available |
| CLI | ✓ | [activecampaign.js](../clis/activecampaign.js) |
| SDK | ✓ | Python, PHP, Node.js, Ruby |

## Authentication

- **Type**: API Token
- **Header**: `Api-Token: {api_token}`
- **Base URL**: `https://{yourAccountName}.api-us1.com/api/3`
- **Get key**: Settings > Developer tab in your ActiveCampaign account
- **Note**: Each user has a unique API key. Base URL is account-specific (found in Settings > Developer).

## Common Agent Operations

### Get current user

```bash
GET https://{account}.api-us1.com/api/3/users/me
```

### List contacts

```bash
GET https://{account}.api-us1.com/api/3/contacts?limit=20&offset=0

# Search by email
GET https://{account}.api-us1.com/api/3/contacts?email=user@example.com

# Search by name
GET https://{account}.api-us1.com/api/3/contacts?search=Jane
```

### Create contact

```bash
POST https://{account}.api-us1.com/api/3/contacts

{
  "contact": {
    "email": "user@example.com",
    "firstName": "Jane",
    "lastName": "Doe",
    "phone": "+15551234567"
  }
}
```

### Update contact

```bash
PUT https://{account}.api-us1.com/api/3/contacts/{contactId}

{
  "contact": {
    "firstName": "Updated",
    "lastName": "Name"
  }
}
```

### Sync contact (create or update)

```bash
POST https://{account}.api-us1.com/api/3/contact/sync

{
  "contact": {
    "email": "user@example.com",
    "firstName": "Jane",
    "lastName": "Doe"
  }
}
```

### Delete contact

```bash
DELETE https://{account}.api-us1.com/api/3/contacts/{contactId}
```

### List all lists

```bash
GET https://{account}.api-us1.com/api/3/lists?limit=20&offset=0
```

### Create list

```bash
POST https://{account}.api-us1.com/api/3/lists

{
  "list": {
    "name": "Newsletter",
    "stringid": "newsletter",
    "sender_url": "https://example.com",
    "sender_reminder": "You signed up for our newsletter."
  }
}
```

### Subscribe contact to list

```bash
POST https://{account}.api-us1.com/api/3/contactLists

{
  "contactList": {
    "list": "1",
    "contact": "1",
    "status": 1
  }
}
```

### Unsubscribe contact from list

```bash
POST https://{account}.api-us1.com/api/3/contactLists

{
  "contactList": {
    "list": "1",
    "contact": "1",
    "status": 2
  }
}
```

### List campaigns

```bash
GET https://{account}.api-us1.com/api/3/campaigns?limit=20&offset=0
```

### List deals

```bash
GET https://{account}.api-us1.com/api/3/deals?limit=20&offset=0

# Filter by pipeline stage
GET https://{account}.api-us1.com/api/3/deals?filters[stage]=1
```

### Create deal

```bash
POST https://{account}.api-us1.com/api/3/deals

{
  "deal": {
    "title": "New Enterprise Deal",
    "value": 50000,
    "currency": "usd",
    "group": "1",
    "stage": "1",
    "owner": "1",
    "contact": "1"
  }
}
```

### Update deal

```bash
PUT https://{account}.api-us1.com/api/3/deals/{dealId}

{
  "deal": {
    "stage": "2",
    "value": 75000
  }
}
```

### List automations

```bash
GET https://{account}.api-us1.com/api/3/automations?limit=20&offset=0
```

### Add contact to automation

```bash
POST https://{account}.api-us1.com/api/3/contactAutomations

{
  "contactAutomation": {
    "contact": "1",
    "automation": "1"
  }
}
```

### List tags

```bash
GET https://{account}.api-us1.com/api/3/tags?limit=20&offset=0
```

### Create tag

```bash
POST https://{account}.api-us1.com/api/3/tags

{
  "tag": {
    "tag": "VIP Customer",
    "tagType": "contact"
  }
}
```

### Add tag to contact

```bash
POST https://{account}.api-us1.com/api/3/contactTags

{
  "contactTag": {
    "contact": "1",
    "tag": "1"
  }
}
```

### List pipelines (deal groups)

```bash
GET https://{account}.api-us1.com/api/3/dealGroups?limit=20&offset=0
```

### List webhooks

```bash
GET https://{account}.api-us1.com/api/3/webhooks?limit=20&offset=0
```

### Create webhook

```bash
POST https://{account}.api-us1.com/api/3/webhooks

{
  "webhook": {
    "name": "Contact Updated",
    "url": "https://example.com/webhook",
    "events": ["subscribe", "unsubscribe"],
    "sources": ["public", "admin", "api", "system"]
  }
}
```

## API Pattern

ActiveCampaign uses REST with resource wrapping (e.g., `{ "contact": {...} }`). Responses include the resource object plus metadata. Related resources are managed via junction endpoints (e.g., `/contactLists`, `/contactTags`, `/contactAutomations`). The base URL is account-specific. Pagination uses `limit` and `offset` parameters.

## Key Metrics

### Contact Fields
- `email` - Email address
- `firstName`, `lastName` - Name fields
- `phone` - Phone number
- `cdate` - Creation date
- `udate` - Last updated date
- `deals` - Related deals count

### Deal Fields
- `title` - Deal name
- `value` - Deal value in cents
- `currency` - Currency code
- `stage` - Pipeline stage ID
- `group` - Pipeline (deal group) ID
- `owner` - Assigned user ID
- `status` - 0 (open), 1 (won), 2 (lost)

### Campaign Metrics
- `sends` - Total sends
- `opens` - Opens count
- `clicks` - Clicks count
- `uniqueopens` - Unique opens
- `uniquelinks` - Unique clicks

## Parameters

### Contact List Status
- `1` - Subscribed (active)
- `2` - Unsubscribed

### Deal Status
- `0` - Open
- `1` - Won
- `2` - Lost

### Tag Types
- `contact` - Contact tags
- `deal` - Deal tags

### Common Query Parameters
- `limit` - Results per page (default 20)
- `offset` - Skip N results
- `search` - Text search
- `email` - Filter contacts by email
- `filters[stage]` - Filter deals by stage
- `filters[owner]` - Filter deals by owner

## When to Use

- Marketing automation with complex conditional workflows
- CRM with deal pipeline management
- Contact management with tagging and segmentation
- Email campaign creation and tracking
- Triggering automations based on external events
- B2B sales pipeline tracking integrated with marketing

## Rate Limits

- 5 requests per second per account
- Rate limit applies across all API users on the same account
- 429 responses include `Retry-After` header

## Relevant Skills

- emails
- lifecycle-marketing
- crm-integration
- sales-pipeline
- marketing-automation

## File: tools/integrations/adobe-analytics.md

# Adobe Analytics

Enterprise analytics platform for cross-channel measurement and attribution.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Reporting API 2.0, Data Insertion API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | AppMeasurement.js, Mobile SDKs, Launch |

## Authentication

- **Type**: OAuth 2.0 (Service Account JWT)
- **Setup**: Create integration in Adobe Developer Console
- **Header**: `Authorization: Bearer {access_token}`

## Common Agent Operations

### Get report suite info

```bash
GET https://analytics.adobe.io/api/{company_id}/reportsuites/collections/suites

Authorization: Bearer {access_token}
x-api-key: {client_id}
```

The CLI's `reportsuites list` uses this collection endpoint and returns the
provider's suite array unchanged. Read each suite's `rsid` before using the
existing dimension, metric, or report commands. `--dry-run` previews the same
resource with credentials masked. Availability depends on the account's
permissions; an empty collection does not prove that no suites exist in the
organization.

Reference: [official Report Suites API](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/report-suites).

### Get dimensions

```bash
GET https://analytics.adobe.io/api/{company_id}/dimensions?rsid={report_suite_id}

Authorization: Bearer {access_token}
x-api-key: {client_id}
```

### Get metrics

```bash
GET https://analytics.adobe.io/api/{company_id}/metrics?rsid={report_suite_id}

Authorization: Bearer {access_token}
x-api-key: {client_id}
```

### Run report

```bash
POST https://analytics.adobe.io/api/{company_id}/reports

{
  "rsid": "{report_suite_id}",
  "globalFilters": [{
    "type": "dateRange",
    "dateRange": "2024-01-01T00:00:00/2024-01-31T23:59:59"
  }],
  "metricContainer": {
    "metrics": [
      {"id": "metrics/visits"},
      {"id": "metrics/pageviews"},
      {"id": "metrics/orders"}
    ]
  },
  "dimension": "variables/evar1"
}
```

### Get segments

```bash
GET https://analytics.adobe.io/api/{company_id}/segments?rsid={report_suite_id}

Authorization: Bearer {access_token}
x-api-key: {client_id}
```

### Data Insertion (server-side)

```bash
POST https://{tracking_server}/b/ss/{report_suite_id}/0

<?xml version="1.0" encoding="UTF-8"?>
<request>
  <visitorID>user_123</visitorID>
  <events>event1</events>
  <eVar1>campaign_name</eVar1>
  <prop1>page_type</prop1>
</request>
```

## AppMeasurement.js

```javascript
// Initialize
var s = s_gi('report_suite_id');
s.trackingServer = 'metrics.example.com';

// Set variables
s.pageName = 'Home Page';
s.channel = 'Marketing';
s.eVar1 = 'campaign_name';
s.events = 'event1';

// Track page view
s.t();

// Track link
s.tl(this, 'o', 'Button Click');
```

## Key Concepts

- **Report Suite** - Data container
- **eVars** - Conversion variables (persistent)
- **props** - Traffic variables (hit-level)
- **Events** - Success metrics
- **Segments** - User/visit filters
- **Calculated Metrics** - Derived metrics

## Common Dimensions

- `variables/page` - Page name
- `variables/evar1` - Custom conversion variable
- `variables/prop1` - Custom traffic variable
- `variables/marketingchannel` - Marketing channel
- `variables/referringdomain` - Referring domain

## Common Metrics

- `metrics/visits` - Visits
- `metrics/pageviews` - Page views
- `metrics/uniquevisitors` - Unique visitors
- `metrics/orders` - Orders
- `metrics/revenue` - Revenue

## When to Use

- Enterprise-scale analytics
- Cross-channel attribution
- Integration with Adobe Experience Cloud
- Advanced segmentation
- Data warehouse exports

## Rate Limits

- 12 requests/second per company
- 120 requests/minute

## Relevant Skills

- analytics
- ab-testing
- ads

## File: tools/integrations/ahrefs.md

# Ahrefs

SEO toolset for backlink analysis, keyword research, and competitive research.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for Site Explorer, Keywords Explorer |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | API-only |

## Authentication

- **Type**: API Token
- **Header**: `Authorization: Bearer {api_token}`
- **Get token**: Account Settings > API in Ahrefs dashboard

## Common Agent Operations

### Domain rating

```bash
GET https://api.ahrefs.com/v3/site-explorer/domain-rating?target=example.com&date=2026-09-30

Authorization: Bearer {api_token}
```

### Backlinks overview

```bash
GET https://api.ahrefs.com/v3/site-explorer/backlinks-stats?target=example.com&mode=domain

Authorization: Bearer {api_token}
```

### Referring domains

```bash
GET https://api.ahrefs.com/v3/site-explorer/refdomains?target=example.com&mode=domain&limit=100&select=domain,domain_rating,links_to_target

Authorization: Bearer {api_token}
```

### Backlinks list

```bash
GET https://api.ahrefs.com/v3/site-explorer/all-backlinks?target=example.com&mode=domain&limit=100&select=url_from,url_to,anchor,is_dofollow

Authorization: Bearer {api_token}
```

### Organic keywords

```bash
GET https://api.ahrefs.com/v3/site-explorer/organic-keywords?target=example.com&mode=domain&country=us&limit=100&date=2026-09-30&select=keyword

Authorization: Bearer {api_token}
```

### Top pages

```bash
GET https://api.ahrefs.com/v3/site-explorer/top-pages?target=example.com&mode=domain&country=us&limit=50&date=2026-09-30&select=url

Authorization: Bearer {api_token}
```

### Keyword overview

```bash
GET https://api.ahrefs.com/v3/keywords-explorer/overview?keywords=keyword1,keyword2&country=us

Authorization: Bearer {api_token}
```

### Keyword suggestions

```bash
GET https://api.ahrefs.com/v3/keywords-explorer/matching-terms?keyword=seed+keyword&country=us&limit=100

Authorization: Bearer {api_token}
```

### SERP overview

```bash
GET https://api.ahrefs.com/v3/keywords-explorer/serp-overview?keyword=target+keyword&country=us

Authorization: Bearer {api_token}
```

## Key Metrics

### Domain Metrics
- `domain_rating` - Domain Rating (DR)
- `ahrefs_rank` - Ahrefs Rank
- `referring_domains` - Referring domains count
- `backlinks` - Total backlinks
- `organic_traffic` - Estimated organic traffic

### Keyword Metrics
- `volume` - Monthly search volume
- `keyword_difficulty` - KD score (0-100)
- `cpc` - Cost per click
- `clicks` - Estimated monthly clicks
- `global_volume` - Global search volume

### Backlink Fields
- `url_from` - Source URL
- `url_to` - Target URL
- `anchor` - Anchor text
- `domain_rating_source` - Source DR
- `first_seen` - First discovery date

## Modes

- `domain` - Entire domain
- `subdomains` - Domain + subdomains
- `prefix` - URL prefix
- `exact` - Exact URL

## When to Use

- Backlink analysis
- Link building research
- Keyword research
- Competitive analysis
- Content gap analysis
- Site audits

## Rate Limits

- Varies by plan
- 500-5000 rows per request

## Relevant Skills

- seo-audit
- content-strategy
- competitors

## Dated reports in the CLI

`domain-rating get`, `keywords organic`, and `top-pages list` accept an explicit
`--date YYYY-MM-DD`, defaulting to today's UTC date when omitted. Organic
keywords and top pages supply default columns; `--select` overrides them.
The CLI validates calendar dates and rejects empty column lists before a request.
Choose fields from the provider response schema:

- [Domain rating](https://docs.ahrefs.com/en/api/reference/site-explorer/get-domain-rating)
- [Organic keywords](https://docs.ahrefs.com/en/api/reference/site-explorer/get-organic-keywords)
- [Top pages](https://docs.ahrefs.com/en/api/reference/site-explorer/get-top-pages)

## Backlink report columns

`backlinks list` calls `all-backlinks` and defaults to
`url_from,url_to,anchor,is_dofollow`. `refdomains list` defaults to
`domain,domain_rating,links_to_target`. Both APIs require `select`; use
`--select` to choose other columns. These defaults omit columns marked with
additional unit costs in the schemas. Requests still consume API units.

- [Backlinks](https://docs.ahrefs.com/en/api/reference/site-explorer/get-all-backlinks)
- [Refdomains](https://docs.ahrefs.com/en/api/reference/site-explorer/get-refdomains)

## File: tools/integrations/airops.md

# AirOps

AI content platform for crafting content that wins AI search. Build and execute AI workflows (flows) for SEO content generation, data enrichment, and automation.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Flows, Workflows, Runs |
| MCP | - | Not available |
| CLI | ✓ | [airops.js](../clis/airops.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: Workspace API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Env vars**: `AIROPS_API_KEY` (no separate workspace ID is required by these public routes)
- **Get key**: Settings > API Keys at https://app.airops.com

## Common Agent Operations

### List Flows

```bash
GET https://api.airops.com/public_api/airops_apps
```

### Get Flow Details

```bash
GET https://api.airops.com/public_api/airops_apps/{app_uuid}
```

### Execute a Flow

```bash
POST https://api.airops.com/public_api/airops_apps/{app_uuid}/execute

{
  "inputs": {
    "keyword": "best project management tools",
    "target_audience": "startup founders"
  }
}
```

### List Runs for a Flow

```bash
GET https://api.airops.com/public_api/airops_apps/{numeric_app_id}/executions?airops_app_id={numeric_app_id}
```

### Get Run Status

```bash
GET https://api.airops.com/public_api/airops_apps/executions/{execution_uuid}
```

### List Workflows

```bash
GET https://api.airops.com/public_api/airops_apps
```

### Execute a Workflow

```bash
POST https://api.airops.com/public_api/airops_apps/{app_uuid}/execute

{
  "inputs": {
    "topic": "email marketing best practices",
    "content_type": "blog_post"
  }
}
```

## Key Metrics

### Flow Data
- `id` - Flow identifier
- `name` - Flow name
- `description` - Flow description
- `status` - Active/inactive status
- `created_at` - Creation timestamp
- `updated_at` - Last modified timestamp

### Run Data
- `id` - Run identifier
- `flow_id` - Parent flow ID
- `status` - pending, running, error, success, cancelled, review_needed
- `inputs` - Input parameters used
- `outputs` - Generated results
- `started_at` - Run start time
- `completed_at` - Run completion time

## Parameters

### Flow Execution
- `inputs` - JSON object of key-value pairs matching the flow's expected inputs
- Input keys vary per flow (e.g., `keyword`, `topic`, `url`, `target_audience`)

### Workflow Execution
- `inputs` - JSON object of key-value pairs matching the workflow's expected inputs

## When to Use

- Bulk content generation for SEO at scale
- SEO-optimized article creation with AI workflows
- Data enrichment pipelines for marketing lists
- Keyword research automation
- Content optimization and rewriting
- Programmatic SEO page generation
- AI-powered content briefs and outlines

## Rate Limits

- Rate limits vary by plan
- Concurrent execution limits depend on workspace tier
- Check AirOps dashboard for current usage and limits

## Relevant Skills

- ai-seo
- content-strategy
- programmatic-seo
- copywriting

## CLI identifiers and execution limits

`flows` and `workflows` refer to the same public app catalog. Use the app UUID
from Integrate for detail and execution operations, and the returned execution
UUID for `run-status`. Run history uses the numeric app ID and accepts `--cursor`
and `--items` (1–100). The list operation returns both app ID and UUID.

Apps must be published before execution. The synchronous execution endpoint can
fail when workspace capacity is exhausted or a run takes more than ten minutes;
this CLI does not automatically retry or enqueue work. `--inputs` must contain a
JSON object. The provider also documents async execution for longer workflows.

Contracts: [Apps](https://docs.airops.com/api-reference/api-reference/apps) and
[Executions](https://docs.airops.com/api-reference/api-reference/executions).

## File: tools/integrations/aisa.md

# AIsa

> **◆ Verified Partner integration.** AIsa sponsors Marketing Skills. This integration is disclosed and vetted for fit; it does **not** change what any skill recommends. It's listed here alongside the neutral options for the same job — use it when it's the right fit, not because it's a partner. See [Verified Partners](../REGISTRY.md#verified-partners).

One account and one key for third-party data APIs, billed per call. For marketing work, the relevant parts are SEO data (DataForSEO, Semrush, and Ahrefs endpoints), Similarweb market data, social data (X/Twitter, Instagram, Reddit, Pinterest, YouTube), web search and research (Tavily, Firecrawl, Exa, Perplexity), and people and company search. AIsa also offers model inference and finance data, which this guide doesn't cover.

The MCP workflows, authentication, pricing guidance, and coverage below were reviewed against the [MCP guide](https://mcp.aisa.one/llms.txt), the [agent quickstart](https://aisa.one/docs/agent-quickstart), the [public catalogue](https://mcp.aisa.one/servers), and the linked authentication and billing docs on 2026-10-15. This review did not execute authenticated provider calls. Coverage and prices change; inspect the selected operation before use.

See the [quick start](../aisa/README.md), [coverage map](../aisa/coverage-map.md), and [evaluation scenarios](../aisa/evals/README.md) for task-specific setup and validation.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST, Bearer auth. [API reference](https://aisa.one/docs/api-reference), [OpenAPI spec](https://aisa.one/openapi.yaml) |
| MCP | ✓ | Remote, Streamable HTTP: `https://mcp.aisa.one/mcp`. OAuth or Bearer key |
| CLI | ✓ | `@aisa-one/cli` on npm (`aisa login`, `aisa balance`) |
| Agent skill | ✓ | `npx skills add AIsa-team/agent-skills --skill aisa` |

## How the MCP Server Works

Connect to `https://mcp.aisa.one/mcp`. The endpoint lists five tools:

| Tool | What it does | Billed |
|------|--------------|--------|
| `search` | Describe the task in plain words; returns candidate operations with `operation_id`, input schema, and price | No |
| `list_categories` | Categories to narrow a search | No |
| `get_details` | Full contract for an operation: schemas, read-only flag, price for your account, `suggested_max_price_usd`, known pitfalls | No |
| `use` | Runs one operation; `max_price_usd` rejects an execution estimate above the supplied limit | Per call; the documented `account` read is free |
| `batch_use` | Up to 20 operations; inspect its current budget semantics and every item result | Per call |

Use `list_categories` to browse capabilities and `search` to find relevant operations through the same connection.

A `402` can report insufficient balance, an exhausted key limit, missing subscription access, or a price admission rejection. Read the specific error; do not automatically top up, upgrade, or retry.

## Pricing

- Data operations use fixed or metered pricing; rates and access can depend on the account or plan. Check [current plans](https://aisa.one/pricing), the [API catalogue](https://aisa.one/api), and an authenticated quote for the exact request.
- Per the [billing guide](https://aisa.one/docs/guides/pricing), `max_price_usd` is an **estimate-based admission check, not a ceiling on the final metered charge**. Under a fixed budget, also establish a documented maximum or a provable bound from request limits before executing.

## Authentication

- **Interactive MCP:** OAuth. Add the MCP server and approve in the browser; no key has to exist first. The token is scoped to that client and revocable on its own.
- **Headless and CI:** an API key from [console.aisa.one](https://console.aisa.one) exported as `AISA_API_KEY` and sent as `Authorization: Bearer $AISA_API_KEY`. Keep it in a secret manager or the CI's secret store, never in the repo, client-side code, or screenshots.
- The current CLI stores its OAuth session in `~/.aisa/tokens.json`; `AISA_API_KEY` overrides the stored session. Confirm the intended account with `aisa balance` without printing credentials. See [authentication](https://aisa.one/docs/guides/authentication).

## Common agent workflows

**Connect (Claude Code)**

```bash
claude mcp add --transport http aisa https://mcp.aisa.one/mcp
# Then open /mcp in Claude Code, select aisa, and authenticate.
```

Codex: `codex mcp add aisa --url https://mcp.aisa.one/mcp`. Cursor, Windsurf, and other clients take the same URL in their MCP settings. Without a browser, pass the key instead: `--header "Authorization: Bearer $AISA_API_KEY"` (Claude Code) or `--bearer-token-env-var AISA_API_KEY` (Codex).

**Connect (CLI, for scripts and CI)**

```bash
npm install -g @aisa-one/cli      # Node 18+
aisa login                         # or export AISA_API_KEY in CI
aisa balance                       # confirms auth; the free way to check
```

If a CLI is needed, check its [current prerequisites](https://aisa.one/docs/get-started/cli) before installing. Remote MCP does not require the CLI or a bundled installer that changes other agent settings.

### Run a Lookup with a Budget

1. `search` for the task ("referring domains for example.com").
2. Inspect the candidate's schema and obtain a quote for the exact arguments using `get_details` and its quote options. A suggested limit is not spending authorization.
3. Establish the scope, maximum possible cost, and sufficient user authorization. Reuse approval already given for that exact scope; if a metered maximum cannot be bounded within the budget, stop before execution.
4. Call `use` with `max_price_usd` set to the approved admission limit. Account for pagination and additional requests, and reconcile observed charges before retries. Re-quote if arguments change.

For a free connection check, inspect the client's `use` tool schema and invoke the documented `account` read. Discovery metadata alone does not confirm authenticated access.

**Cross-check a number across providers.** Domain authority and backlink counts come from more than one index (DataForSEO, Semrush, Ahrefs). When a decision depends on the figure, pull it from two and report both, labeled by source. They won't match, because each provider crawls differently.

## Tradeoffs

- **One more dependency.** Requests route and bill through AIsa, so an AIsa outage or balance problem stops every provider behind it. Billing goes through AIsa rather than each provider.
- **Not every endpoint of every provider.** The SEO module is a curated set. If you need a report AIsa doesn't expose, go to the provider directly.
- **Direct accounts can still win.** If you already pay for Semrush or Ahrefs and use one provider heavily, a direct account (see the semrush, ahrefs, and dataforseo guides) may cost less and expose more. AIsa fits when you need several providers occasionally and don't want an account and key for each.
- **Costs vary by call.** Metered pricing and batches need bounds on the whole request. Use the interface's supported admission controls and reconcile account usage; a price estimate alone does not bound final spend.

## How it fits the skills

- AIsa is one way to get **data**; what to do with it still comes from the skills. Use `seo-audit` and `ai-seo` for SEO and AI-visibility work, `competitors` and `competitor-profiling` for market research, `content-strategy` and `programmatic-seo` for keyword data, `social` for social listening, and `prospecting` for people and company search.
- Alternatives for the same job: direct provider accounts ([dataforseo](dataforseo.md), [semrush](semrush.md), [ahrefs](ahrefs.md), [similarweb](similarweb.md)), [RankParse](rankparse.md) for cheap backlink and domain data, and [Composio](composio.md) when the need is connecting your own SaaS accounts rather than buying third-party data.
- Apply the approval rule: paid calls need authorization for their scope and bounded cost; an estimate alone does not establish that bound.

## Links

- Site: https://aisa.one
- Docs: https://aisa.one/docs (index at https://aisa.one/docs/llms.txt)
- MCP server guide: https://mcp.aisa.one/llms.txt
- Live MCP catalogue: https://mcp.aisa.one/servers
- Pricing: https://aisa.one/pricing
- Console: https://console.aisa.one

## File: tools/integrations/amplitude.md

# Amplitude

Product analytics platform for user behavior, retention, and experimentation.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | HTTP API for events, User Profile API, Export API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | JavaScript, iOS, Android, Python, etc. |

## Authentication

- **HTTP API**: API Key (public for events)
- **Export/Dashboard API**: API Key + Secret Key

## Common Agent Operations

### Track event

```bash
POST https://api2.amplitude.com/2/httpapi

{
  "api_key": "{api_key}",
  "events": [{
    "user_id": "user_123",
    "event_type": "signup_completed",
    "event_properties": {
      "plan": "pro"
    },
    "user_properties": {
      "email": "user@example.com"
    }
  }]
}
```

### Batch events

```bash
POST https://api2.amplitude.com/batch

{
  "api_key": "{api_key}",
  "events": [
    {"user_id": "user_1", "event_type": "pageview"},
    {"user_id": "user_2", "event_type": "signup"}
  ]
}
```

### Get user activity

The activity endpoint requires an internal Amplitude ID, distinct from the
external `user_id` used to track events. The CLI resolves `users activity
--user-id <external-user-id>` through User Search and selects an exact user ID
match before requesting activity. Use `--amplitude-id <internal-id>` for a
direct lookup. A dry run with `--user-id` previews the initial search request;
it cannot determine an internal ID without contacting the API.

```bash
GET https://amplitude.com/api/2/useractivity?user={amplitude_id}

Authorization: Basic {base64(api_key:secret_key)}
```

### Export events

```bash
GET https://amplitude.com/api/2/export?start=20240101T00&end=20240131T23

Authorization: Basic {base64(api_key:secret_key)}
```

The Export API returns a ZIP archive. To keep stdout valid JSON without decoding
binary bytes as text, `node tools/clis/amplitude.js export events` returns
`{ "status": 200, "contentType": "application/zip", "encoding": "base64", "body": "..." }`.
After saving that JSON as `export.json`, restore the archive with:

```javascript
const fs = require('node:fs')
const result = JSON.parse(fs.readFileSync('export.json', 'utf8'))
fs.writeFileSync('events.zip', Buffer.from(result.body, 'base64'))
```

### Get retention data

```bash
GET https://amplitude.com/api/2/retention?se={"event_type":"signup_completed"}&re={"event_type":"purchase"}&start=20240101&end=20240131

Authorization: Basic {base64(api_key:secret_key)}
```

The [Dashboard REST API](https://amplitude.com/docs/apis/analytics/dashboard-rest#retention-analysis)
requires two event objects: `se` for the starting action and `re` for the returning action.
The CLI defaults to new users (`_new`) returning with an active event (`_active`).
`--event` is a compatibility alias for `--return-event`; an explicit `--return-event` wins.

```bash
node tools/clis/amplitude.js retention get --start 20240101 --end 20240131 \
  --start-event signup_completed --return-event purchase --dry-run
```

### Query with SQL (Snowflake)

For Amplitude customers with SQL access:
```sql
SELECT event_type, COUNT(*) as count
FROM events
WHERE event_time > '2024-01-01'
GROUP BY event_type
```

## JavaScript SDK

```javascript
// Initialize
amplitude.init('API_KEY');

// Identify user
amplitude.setUserId('user_123');

// Set user properties
const identify = new amplitude.Identify();
identify.set('plan', 'pro');
amplitude.identify(identify);

// Track event
amplitude.track('Feature Used', {
  feature_name: 'export'
});
```

## Key Concepts

- **Events** - User actions with properties
- **User Properties** - Persistent user attributes
- **Cohorts** - Behavioral segments
- **Funnels** - Multi-step conversion analysis
- **Retention** - User return patterns
- **Journeys** - User path analysis

## When to Use

- Tracking product analytics
- Analyzing user funnels
- Cohort analysis and retention
- Experimentation and A/B testing
- User journey mapping

## Rate Limits

- HTTP API: 1000 events/second
- Export API: 360 requests/hour

## Relevant Skills

- analytics
- ab-testing
- onboarding

## Tracking before signup

`track event` accepts `--device-id` without `--user-id` for events before an
account exists. At least one identity is required; when both are known, include
both to send them together. Device IDs are identifiers, not a privacy guarantee.

```bash
node tools/clis/amplitude.js track event --device-id visitor-device-123 \
  --event-type "Viewed Pricing" --properties '{"experiment":"pricing-b"}' --dry-run
```

The CLI leaves existing user-only payloads intact and masks the API key in
previews. Amplitude's default minimum identifier length is five characters;
provider-side identity and project ingestion rules still apply. See the
[HTTP V2 API](https://amplitude.com/docs/apis/analytics/http-v2).

## File: tools/integrations/apify.md

# Apify

Web scraping and automation platform with a marketplace of ready-made scrapers ("Actors"): website crawlers, directories and marketplaces, app stores, review sites, job boards, and many site-specific scrapers. Actors run in Apify's cloud and write results to datasets you can download as JSON or CSV.

Facts below were checked against [docs.apify.com](https://docs.apify.com/api/v2) and the [MCP docs](https://docs.apify.com/platform/integrations/mcp) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2: run Actors, read datasets, schedules, webhooks |
| MCP | ✓ | Official hosted server at `https://mcp.apify.com` (OAuth, or Bearer API token); also runs locally over stdio. Searches and runs Actors as tools |
| CLI | ✓ | Official [Apify CLI](https://docs.apify.com/cli/docs) (mainly for building and running Actors) |
| SDK | ✓ | Official JavaScript and Python API clients |

## Authentication

- **Type**: Bearer token, `Authorization: Bearer <token>` (preferred over the `?token=` URL parameter, which ends up in logs)
- **Env var** (convention): `APIFY_TOKEN`
- **Get token**: Apify Console > Settings > [Integrations](https://console.apify.com/settings/integrations)
- **MCP**: OAuth browser sign-in by default; use the API token as a Bearer header for unattended runs. The MCP server excludes full-permission and rental Actors.

## Common Agent Operations

### Run an Actor and get its results in one call

```bash
# Crawl a directory or partner page and return clean page content
POST https://api.apify.com/v2/actors/apify~website-content-crawler/run-sync-get-dataset-items
Authorization: Bearer $APIFY_TOKEN
Content-Type: application/json

{ "startUrls": [{ "url": "https://www.example-directory.com/agencies" }], "maxCrawlPages": 50, "respectRobotsTxtFile": true }
```

- The Actor ID is either its ID or `owner~actor-name`.
- Synchronous runs time out after 300 seconds (HTTP 408). For bigger jobs, start the run asynchronously (`POST /v2/actors/{actorId}/runs`), then read the dataset when it finishes, or attach a webhook.
- Each Actor defines its own input; read its input schema on the Actor's Apify Store page before calling it.

### Read a dataset

```bash
GET https://api.apify.com/v2/datasets/{datasetId}/items?format=json&clean=true
```

## Rate Limits

- 250,000 requests per minute globally per user, and 60 requests per second per resource (one Actor, run, or dataset) by default; `429` when exceeded
- Source: [API docs](https://docs.apify.com/api/v2)

## Pricing

Usage-based: platform compute plus each Actor's own pricing (per result, per run, or rental). Check an Actor's price on its Store page before running it at volume. Plans: [apify.com/pricing](https://apify.com/pricing).

## Sourcing Rules for Outbound

- **Good sources**: public directories and marketplaces (app stores, agency directories, partner and integration pages), job boards, review sites, and companies' own websites.
- **Google Maps**: Maps scrapers are among the most popular Actors, but automated scraping of Google Maps breaks Google's terms. For local business data, use the official Google Places API instead (see the `prospecting` skill's local prospecting guidance).
- **Don't** run Actors that log in to LinkedIn or use session cookies or fake accounts. LinkedIn sues data vendors that do this, and the data can carry GDPR risk. Use Sales Navigator to define the audience and licensed databases for contacts (see the `prospecting` skill).
- Directories and listings give companies, not people. Enrich decision makers and verify emails before any outreach.
- Respect each site's terms and robots rules, and keep a record of where every contact came from.

## Relevant Skills

- prospecting
- competitor-profiling
- customer-research
- programmatic-seo (collecting structured data for page sets)

## File: tools/integrations/apollo.md

# Apollo.io

B2B prospecting and data enrichment platform with 210M+ contacts and 35M+ companies for sales intelligence.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | People Search, Company Search, Enrichment, Sequences |
| MCP | ✓ | Official hosted server at `https://mcp.apollo.io/mcp`: OAuth 2.0, or an `X-Api-Key` master key for headless use ([docs](https://docs.apollo.io/docs/apollo-mcp)); tool availability varies by plan |
| CLI | ✓ | [apollo.js](../clis/apollo.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key
- **Header**: `x-api-key: {api_key}` or `Authorization: Bearer {token}`
- **Get key**: Settings > Integrations > API at https://app.apollo.io

## Common Agent Operations

### People Search

```bash
POST https://api.apollo.io/api/v1/mixed_people/api_search

{
  "person_titles": ["Sales Manager"],
  "person_locations": ["United States"],
  "organization_num_employees_ranges": ["1,100"],
  "page": 1
}
```

### Person Enrichment

```bash
POST https://api.apollo.io/api/v1/people/match

{
  "first_name": "Tim",
  "last_name": "Zheng",
  "domain": "apollo.io"
}
```

### Bulk People Enrichment

```bash
POST https://api.apollo.io/api/v1/people/bulk_match

{
  "details": [
    { "email": "tim@apollo.io" },
    { "first_name": "Jane", "last_name": "Doe", "domain": "example.com" }
  ]
}
```

### Organization Search

```bash
POST https://api.apollo.io/api/v1/mixed_companies/search

{
  "organization_locations": ["United States"],
  "organization_num_employees_ranges": ["1,100"],
  "page": 1
}
```

### Organization Enrichment

```bash
GET https://api.apollo.io/api/v1/organizations/enrich?domain=apollo.io

x-api-key: {api_key}
```

Organization enrichment uses a query parameter and has no request body.
API keys belong in the `x-api-key` header for every request. See the official
[authentication](https://docs.apollo.io/reference/authentication) and
[organization enrichment](https://docs.apollo.io/reference/organization-enrichment) references.

## Key Metrics

### Person Data
- `first_name`, `last_name` - Name
- `title` - Job title
- `email` - Verified email
- `linkedin_url` - LinkedIn profile
- `organization` - Company details
- `seniority` - Seniority level
- `departments` - Department list

### Organization Data
- `name` - Company name
- `website_url` - Website
- `estimated_num_employees` - Employee count
- `industry` - Industry
- `annual_revenue` - Revenue
- `technologies` - Tech stack
- `funding_total` - Total funding

## Parameters

### People Search
- `person_titles` - Array of job titles
- `person_locations` - Array of locations
- `person_seniorities` - Array: owner, founder, c_suite, partner, vp, head, director, manager, senior, entry
- `organization_num_employees_ranges` - Array of ranges (e.g., "1,100")
- `organization_ids` - Filter by Apollo org IDs
- `page` - Page number (default: 1)
- `per_page` - Results per page (default: 25, max: 100)

### Person Enrichment
- `email` - Email address
- `first_name` + `last_name` + `domain` - Alternative lookup
- `linkedin_url` - LinkedIn URL
- `reveal_personal_emails` - Include personal emails
- `reveal_phone_number` - Include phone numbers

### Organization Search
- `organization_locations` - Array of locations
- `organization_num_employees_ranges` - Employee count ranges
- `organization_ids` - Specific org IDs
- `page` - Page number

## When to Use

- Building targeted prospect lists by role, seniority, and company size
- Enriching leads with verified contact info
- Finding decision-makers at target accounts
- Company research and firmographic analysis
- ABM campaign targeting
- Sales intelligence and outbound prospecting

## Rate Limits

- Rate limits vary by plan
- Standard: 100 requests/minute for most endpoints
- Bulk enrichment: up to 10 people per request
- Search: max 50,000 records (100 per page, 500 pages)

## Relevant Skills

- prospecting
- cold-email
- revops (lead scoring and routing)
- ads (ABM targeting)

## File: tools/integrations/attentive.md

# Attentive

Full-service SMS marketing platform for mid-market and enterprise direct-to-consumer brands. Combines tooling with dedicated success teams.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API |
| MCP | - | Not available |
| CLI | - | None |
| SDK | - | Use API directly |

## Authentication

- **Type**: OAuth 2.0 or API Key (depending on integration type)
- **Header**: `Authorization: Bearer {access_token}`
- **Get credentials**: Account-level provisioning through Attentive integrations team
- **Note**: API access requires partnership or eligible plan

## Common Agent Operations

### Subscribe a user

```bash
POST https://api.attentivemobile.com/v1/subscriptions

{
  "user": {
    "phone": "+15551234567",
    "email": "user@example.com"
  },
  "signUpSourceId": "...",
  "subscriptionType": "MARKETING"
}
```

Sign-up source ID determines opt-in attribution and compliance disclosure shown.

### Unsubscribe

```bash
POST https://api.attentivemobile.com/v1/subscriptions/unsubscribe

{
  "user": { "phone": "+15551234567" },
  "subscriptionType": "MARKETING"
}
```

### Custom event tracking

```bash
POST https://api.attentivemobile.com/v1/events/custom

{
  "user": { "phone": "+15551234567" },
  "type": "abandoned_cart",
  "properties": {
    "cart_value": 89.99,
    "items": ["Product A"]
  }
}
```

### E-commerce events (purchase, add-to-cart, product view)

```bash
POST https://api.attentivemobile.com/v1/events/ecommerce/purchase

{
  "user": { "phone": "+15551234567" },
  "items": [{
    "productId": "SKU-123",
    "name": "Product A",
    "price": { "value": 4999, "currency": "USD" },
    "quantity": 1
  }],
  "occurredAt": "2026-05-15T10:00:00Z"
}
```

Similar endpoints for `/add_to_cart`, `/product_view`, `/checkout`.

### Send transactional message

```bash
POST https://api.attentivemobile.com/v1/messages/transactional

{
  "user": { "phone": "+15551234567" },
  "messageBody": "Your order #1234 shipped. Track: https://...",
  "type": "ORDER_SHIPPING"
}
```

### List campaigns

```bash
GET https://api.attentivemobile.com/v1/campaigns
```

### Webhooks

Subscribe to: `subscriber.created`, `subscriber.unsubscribed`, `message.sent`, `message.delivered`, `message.failed`, `conversion.attributed`.

## API Pattern

REST + JSON. Bearer auth. Webhook signature verification via HMAC-SHA256.

## Key Features

- Concierge sales (live agents responding via SMS)
- Identity resolution (matching anonymous site visitors to phone numbers for retargeting)
- Strong analytics + attribution (multi-touch, conversion path)
- AI Journey AI / Pro AI (AI-generated send timing and copy)
- Custom Audience Manager (advanced segmentation)
- A/B testing built into campaign builder
- Two-way SMS at scale
- A2P 10DLC fully managed
- Short code provisioning included on most plans
- Dedicated CSM, copy support, strategy consults

## Pricing

- Custom contracts; typically $1K–$10K+/mo platform fee + per-send fees
- Annual contracts standard
- Pricing rarely makes sense for <50K active SMS subscribers
- Negotiable based on volume and tier

## When to Use

- Mid-market+ DTC brand (50K+ active SMS subscribers, $5M+/yr revenue)
- Want dedicated CSM and copy support, not just tooling
- Need concierge two-way SMS at scale
- Multi-channel ecom team that wants single-pane SMS-first platform
- Want short code included rather than separately leased
- Identity resolution / cross-device matching matters

## When NOT to Use

- Smaller brands — too expensive, overkill
- Already on Klaviyo and SMS is secondary — Klaviyo SMS is simpler
- Shopify-only and want depth — Postscript is more Shopify-native
- Custom platform / B2B SaaS — Twilio

## Relevant Skills

- sms
- emails (run alongside)
- churn-prevention
- customer-research (identity resolution data)

## File: tools/integrations/attio.md

# Attio

CRM built around flexible objects and lists: people, companies, deals, and custom objects, with lists for pipelines, notes, tasks, and call recordings. Common with startups and agencies that want a CRM an agent can read and write.

Facts below were checked against [docs.attio.com](https://docs.attio.com/rest-api/guides/authentication) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2 (records, lists and entries, notes, tasks, webhooks); SQL query endpoint on Enterprise |
| MCP | ✓ | Official hosted server at `https://mcp.attio.com/mcp`, OAuth as your Attio user ([docs](https://docs.attio.com/mcp/overview)) |
| CLI | - | Use the API |
| SDK | ✓ | App SDK for building Attio apps (GraphQL inside apps) |

## Authentication

- **API**: Bearer token in `Authorization: Bearer <token>`. For a single workspace, generate an API key in developer settings and grant only the scopes you need (records, lists, notes). Use OAuth 2.0 only when building an app for many workspaces.
- **Env var** (convention): `ATTIO_API_KEY`
- **MCP**: OAuth sign-in, no key. Reads are auto-approved and writes ask for confirmation in the client, which suits human-in-the-loop CRM updates. For unattended agent runs, use an API key with the REST API.

## Common Agent Operations

Base URL: `https://api.attio.com`

### Upsert a person (create or update by email)

```bash
PUT https://api.attio.com/v2/objects/people/records?matching_attribute=email_addresses
Authorization: Bearer $ATTIO_API_KEY

{
  "data": {
    "values": {
      "email_addresses": ["jane@acme.com"],
      "name": [{ "first_name": "Jane", "last_name": "Doe", "full_name": "Jane Doe" }],
      "job_title": "VP Marketing"
    }
  }
}
```

Use upsert rather than create for anything an agent writes repeatedly; create throws on duplicate unique values. Companies upsert on `domains`.

### Query records

```bash
POST https://api.attio.com/v2/objects/companies/records/query

{ "filter": { "domains": "acme.com" }, "limit": 25 }
```

Fuzzy search across objects: `POST /v2/objects/records/search`.

### Add a record to a list (pipeline stage)

```bash
POST https://api.attio.com/v2/lists/{list}/entries
```

Lists are how Attio models pipelines (for example an "Outbound" list with a status attribute for contacted, replied, meeting booked). Read the list's attributes first with `GET /v2/lists/{list}/attributes`.

### Log a note

```bash
POST https://api.attio.com/v2/notes

{
  "data": {
    "parent_object": "people",
    "parent_record_id": "<record-id>",
    "title": "Positive reply: wants a teardown call",
    "format": "plaintext",
    "content": "Replied to email 2 (pricing page angle). Proposed Tue/Wed."
  }
}
```

Tasks: `POST /v2/tasks` for follow-ups with a deadline and assignee.

### Webhooks

Subscribe to record, list-entry, note, and task events to trigger agent work when a deal moves stage ([guide](https://docs.attio.com/rest-api/guides/webhooks)).

## Rate Limits

- 100 read requests per second and 25 write requests per second across the API; some data-heavy endpoints are lower. Over the limit returns `429` with a retry time.
- Source: [rate limiting guide](https://docs.attio.com/rest-api/guides/rate-limiting)

## Pricing

Per-seat plans with a free tier; API and webhooks on all plans, SQL query on Enterprise. Current pricing: [attio.com/pricing](https://attio.com/pricing).

## Outbound Use

- Upsert every contacted prospect with its source, signal, sequence, and channel, so meetings can be attributed (see `revops`)
- Model the outbound pipeline as a list with stages: contacted → replied → positive → meeting booked → meeting held
- Log positive replies as notes and create follow-up tasks with deadlines
- Before adding a prospect to a sequence, query Attio to exclude customers and open deals

## Relevant Skills

- revops
- prospecting
- cold-email
- sales-enablement

## File: tools/integrations/audiencetap.md

# AudienceTap

SMS and email marketing platform built for direct-to-consumer brands. Newer entrant positioning as a more flexible, AI-forward alternative to Klaviyo / Postscript / Attentive with emphasis on creative automation and on-pack QR opt-in.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API (confirm with vendor; access tied to plan tier) |
| MCP | - | Not available |
| CLI | - | None |
| SDK | - | Use API directly |

> Verify current API surface and capabilities at https://audiencetap.com before building against this guide — newer platform, surface evolves quickly.

## Authentication

- **Type**: API Key (Bearer)
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: AudienceTap dashboard → Settings → API
- **Note**: API access generally requires Growth or Pro tier

## Common Agent Operations

### Subscribe a user

```bash
POST https://api.audiencetap.com/v1/subscribers

{
  "phone_number": "+15551234567",
  "email": "user@example.com",
  "first_name": "Jane",
  "opt_in_source": "checkout",
  "list_id": "..."
}
```

### Unsubscribe

```bash
POST https://api.audiencetap.com/v1/subscribers/unsubscribe

{
  "phone_number": "+15551234567",
  "channel": "sms"
}
```

### Track event

```bash
POST https://api.audiencetap.com/v1/events

{
  "subscriber": { "phone_number": "+15551234567" },
  "event_name": "abandoned_cart",
  "properties": {
    "cart_value": 89.99,
    "items": ["Product A"]
  }
}
```

### Send transactional message

```bash
POST https://api.audiencetap.com/v1/messages/transactional

{
  "phone_number": "+15551234567",
  "body": "Your order #1234 shipped. Track: https://...",
  "category": "shipping"
}
```

### List flows / automations

```bash
GET https://api.audiencetap.com/v1/flows
```

### Webhooks

Subscribe to: subscriber events, message delivery events, conversion attribution. Configured in dashboard.

## API Pattern

REST + JSON. Bearer auth. Pagination conventions vary by endpoint — confirm in current docs.

## Key Features

- SMS + email on one platform (positioned similarly to Klaviyo's combined product)
- AI creative generation (subject lines, SMS copy, image variants)
- On-pack QR code opt-in (insert-card based opt-in for ecom shipments)
- Shopify, BigCommerce, and headless commerce integrations
- A2P 10DLC handled in-platform
- Automation builder for cart, post-purchase, win-back, etc.
- Identity resolution (matching anonymous visitors to known subscribers)

## Pricing

- Plans typically tiered by subscriber count + send volume
- Per-send pricing comparable to other DTC SMS platforms (~$0.015 SMS, ~$0.04 MMS)
- Confirm current pricing at https://audiencetap.com — newer platform with evolving plans

## When to Use

- Mid-market DTC brand willing to try a newer platform for better AI tooling or pricing leverage
- Brand wanting on-pack QR opt-in as a primary acquisition channel (printed insert cards driving SMS opt-in)
- Want SMS + email under one roof with stronger AI features than incumbents currently offer
- Evaluating alternatives during a contract negotiation with Klaviyo / Postscript / Attentive

## When NOT to Use

- Need a fully battle-tested platform with deep ecosystem — incumbents have more integrations and case studies
- Compliance tooling at enterprise scale — verify A2P / TCPA depth before committing for large lists
- B2B SaaS, transactional, or developer-first use — Twilio or Plivo

## Relevant Skills

- sms
- emails
- referrals (on-pack QR opt-in is a referral-adjacent acquisition channel)
- directory-submissions (on-pack insert cards as an offline channel)

## File: tools/integrations/beehiiv.md

# Beehiiv

Newsletter platform with subscriber management, post publishing, automations, and referral programs.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2 for publications, subscriptions, posts, segments |
| MCP | - | Not available |
| CLI | ✓ | [beehiiv.js](../clis/beehiiv.js) |
| SDK | - | No official SDK; OpenAPI spec available for codegen |

## Authentication

- **Type**: Bearer Token
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API under Workspace Settings at https://app.beehiiv.com
- **Note**: API key is only shown once on creation; copy and store it immediately

## Common Agent Operations

### List publications

```bash
GET https://api.beehiiv.com/v2/publications
```

### Get publication details

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}
```

### List subscriptions

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}/subscriptions?limit=10&status=active

# Filter by email
GET https://api.beehiiv.com/v2/publications/{publicationId}/subscriptions?email=user@example.com
```

### Create subscription

```bash
POST https://api.beehiiv.com/v2/publications/{publicationId}/subscriptions

{
  "email": "user@example.com",
  "reactivate_existing": false,
  "send_welcome_email": true,
  "utm_source": "api",
  "tier": "free"
}
```

### Update subscription

```bash
PATCH https://api.beehiiv.com/v2/publications/{publicationId}/subscriptions/{subscriptionId}

{
  "tier": "premium"
}
```

### Delete subscription

```bash
DELETE https://api.beehiiv.com/v2/publications/{publicationId}/subscriptions/{subscriptionId}
```

### List posts

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}/posts?limit=10&status=confirmed
```

### Create post (Pro and Enterprise plans)

```bash
POST https://api.beehiiv.com/v2/publications/{publicationId}/posts

{
  "title": "Weekly Update",
  "subtitle": "What happened this week",
  "body_content": "<p>Hello subscribers...</p>",
  "status": "draft"
}
```

The API requires `body_content` or structured `blocks`. The CLI accepts raw HTML through `--content` and sends it as `body_content`.

### List segments

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}/segments
```

### List automations

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}/automations
```

### Get referral program

```bash
GET https://api.beehiiv.com/v2/publications/{publicationId}/referral_program
```

## API Pattern

All endpoints are scoped to a publication. The publication ID is a required path parameter for most operations. Responses use cursor-based pagination with a `cursor` parameter for fetching subsequent pages.

## Key Metrics

### Subscription Fields
- `status` - validating, invalid, pending, active, inactive
- `tier` - free or premium
- `created` - Subscription creation timestamp
- `utm_source`, `utm_medium`, `utm_campaign` - Acquisition tracking
- `referral_code` - Unique referral code for subscriber

### Post Fields
- `status` - draft, confirmed (scheduled), archived
- `publish_date` - When the post was/will be published
- `stats` - Open rate, click rate, subscriber count (with expand)

## Parameters

### Common Query Parameters
- `limit` - Results per page (1-100, default 10)
- `cursor` - Cursor for next page of results
- `expand[]` - Include additional data: stats, custom_fields, referrals
- `status` - Filter by subscription/post status
- `tier` - Filter by subscription tier (free, premium)

## When to Use

- Managing newsletter subscribers programmatically
- Syncing subscribers from external signup forms or landing pages
- Building referral program integrations
- Automating post creation and publishing workflows
- Tracking subscriber growth and engagement metrics

## Rate Limits

- API rate limits apply per API key
- Use cursor-based pagination for efficient data retrieval
- Batch operations not available; iterate with individual requests

## Relevant Skills

- emails
- newsletter-growth
- referrals
- content-strategy

## File: tools/integrations/brevo.md

# Brevo

All-in-one marketing platform (formerly Sendinblue) for email, SMS, and WhatsApp with contacts, campaigns, and transactional messaging.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v3 for contacts, campaigns, transactional email/SMS |
| MCP | - | Not available |
| CLI | ✓ | [brevo.js](../clis/brevo.js) |
| SDK | ✓ | Node.js, Python, PHP, Ruby, Java, C#, Go |

## Authentication

- **Type**: API Key
- **Header**: `api-key: {api_key}`
- **Get key**: SMTP & API settings at https://app.brevo.com/settings/keys/api
- **Note**: API key is only shown once on creation; store securely. Formerly used `api.sendinblue.com` base URL.

## Common Agent Operations

### Get account info

```bash
GET https://api.brevo.com/v3/account
```

### List contacts

```bash
GET https://api.brevo.com/v3/contacts?limit=50&offset=0
```

### Get contact by email

```bash
GET https://api.brevo.com/v3/contacts/user@example.com
```

### Create contact

```bash
POST https://api.brevo.com/v3/contacts

{
  "email": "user@example.com",
  "attributes": {
    "FIRSTNAME": "Jane",
    "LASTNAME": "Doe"
  },
  "listIds": [1, 2]
}
```

### Update contact

```bash
PUT https://api.brevo.com/v3/contacts/user@example.com

{
  "attributes": {
    "FIRSTNAME": "Updated"
  },
  "listIds": [3]
}
```

### Delete contact

```bash
DELETE https://api.brevo.com/v3/contacts/user@example.com
```

### Import contacts

```bash
POST https://api.brevo.com/v3/contacts/import

{
  "jsonBody": [
    { "email": "user1@example.com" },
    { "email": "user2@example.com" }
  ],
  "listIds": [1]
}
```

### List contact lists

```bash
GET https://api.brevo.com/v3/contacts/lists?limit=50&offset=0
```

### Create list

```bash
POST https://api.brevo.com/v3/contacts/lists

{
  "name": "Newsletter Subscribers",
  "folderId": 1
}
```

### Add contacts to list

```bash
POST https://api.brevo.com/v3/contacts/lists/{listId}/contacts/add

{
  "emails": ["user1@example.com", "user2@example.com"]
}
```

### Remove contacts from list

```bash
POST https://api.brevo.com/v3/contacts/lists/{listId}/contacts/remove

{
  "emails": ["user1@example.com"]
}
```

### Send transactional email

```bash
POST https://api.brevo.com/v3/smtp/email

{
  "sender": {
    "name": "My App",
    "email": "noreply@example.com"
  },
  "to": [
    { "email": "user@example.com", "name": "Jane Doe" }
  ],
  "subject": "Order Confirmation",
  "htmlContent": "<html><body><p>Your order is confirmed.</p></body></html>"
}
```

### List email campaigns

```bash
GET https://api.brevo.com/v3/emailCampaigns?limit=50&offset=0&type=classic&status=sent
```

### Create email campaign

```bash
POST https://api.brevo.com/v3/emailCampaigns

{
  "name": "January Newsletter",
  "subject": "Monthly Update",
  "sender": { "name": "My Brand", "email": "news@example.com" },
  "htmlContent": "<html><body><p>Newsletter content</p></body></html>",
  "recipients": { "listIds": [1, 2] }
}
```

### Send campaign immediately

```bash
POST https://api.brevo.com/v3/emailCampaigns/{campaignId}/sendNow
```

### Send test email for campaign

```bash
POST https://api.brevo.com/v3/emailCampaigns/{campaignId}/sendTest

{
  "emailTo": ["test@example.com"]
}
```

### Send transactional SMS

```bash
POST https://api.brevo.com/v3/transactionalSMS/sms

{
  "sender": "MyApp",
  "recipient": "+15551234567",
  "content": "Your verification code is 123456",
  "type": "transactional"
}
```

### List SMS campaigns

```bash
GET https://api.brevo.com/v3/smsCampaigns?limit=50&offset=0
```

### List senders

```bash
GET https://api.brevo.com/v3/senders
```

## API Pattern

Brevo uses standard REST with offset-based pagination (`limit` and `offset` parameters). Contact attributes use uppercase field names (FIRSTNAME, LASTNAME). Lists are nested under the contacts resource path. Transactional email uses the `/smtp/email` endpoint despite being REST-based.

## Key Metrics

### Contact Fields
- `email` - Email address
- `attributes` - Custom attributes (FIRSTNAME, LASTNAME, SMS, etc.)
- `listIds` - Associated list IDs
- `emailBlacklisted` - Email opt-out status
- `smsBlacklisted` - SMS opt-out status
- `statistics` - Engagement stats (with expand)

### Campaign Metrics
- `sent` - Total sends
- `delivered` - Successful deliveries
- `openRate` - Open percentage
- `clickRate` - Click percentage
- `unsubscribed` - Unsubscribe count
- `hardBounces`, `softBounces` - Bounce counts

### Transactional Email Response
- `messageId` - Unique message identifier for tracking

## Parameters

### Contact Parameters
- `email` - Contact email address
- `attributes` - Key-value object of custom attributes
- `listIds` - Array of list IDs to subscribe to
- `unlinkListIds` - Array of list IDs to unsubscribe from

### Campaign Parameters
- `name` - Campaign name
- `subject` - Email subject line
- `sender` - Object with `name` and `email`
- `htmlContent` / `textContent` - Email body
- `recipients` - Object with `listIds` array
- `type` - classic or trigger

## When to Use

- Multi-channel marketing (email + SMS + WhatsApp)
- Transactional email sending with tracking
- Managing contacts and segmented lists
- Creating and scheduling email campaigns
- SMS notifications and marketing
- Affordable all-in-one marketing automation

## Rate Limits

- API rate limits depend on plan (free tier: limited sends/day)
- Transactional email: varies by plan
- Contact imports: batch processing with async status
- Rate limit headers returned with responses

## Relevant Skills

- emails
- sms-marketing
- transactional-email
- lifecycle-marketing
- contact-management

## Contact channel suppression with the CLI

Contact creation and updates accept `--email-blacklisted true|false` and
`--sms-blacklisted true|false`. The literal values become JSON booleans; omitted
flags leave the existing request unchanged. Bare flags and other values are
rejected before transport. These options change contact channel suppression;
they do not send messages, delete the contact, or change list membership.

```bash
node tools/clis/brevo.js contacts get --email owned@example.com
node tools/clis/brevo.js contacts update --email owned@example.com --email-blacklisted true --dry-run
node tools/clis/brevo.js contacts create --email owned@example.com --email-blacklisted true --sms-blacklisted true --dry-run
```

Read the current contact and the user's requested channel preference before
changing an existing record. Use `true` to carry an opt-out into the documented
channel flag. Setting a flag to `false` allows that channel again: only restore
it when the user has authorized that change and there is appropriate permission
to contact the person. List membership alone is not evidence of consent.
Unrelated name or list updates should omit these flags rather than defaulting
them to `false`. The CLI does not establish consent or guarantee compliance with
communication rules. Brevo's separate transactional-email sender blocklist is
not managed by these options.

See the current [create-contact](https://developers.brevo.com/reference/create-contact)
and [update-contact](https://developers.brevo.com/reference/update-contact)
request schemas for `emailBlacklisted` and `smsBlacklisted`.

## File: tools/integrations/browserbase.md

# Browserbase

Headless browser as a service. Spin up real Chromium browsers via API, drive them with Playwright/Puppeteer, get full session recordings. Useful when a target site requires JS rendering, user interaction, or session state that simple HTTP fetches can't handle.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for session management |
| MCP | ✓ | Official hosted server at `https://mcp.browserbase.com/mcp` (Stagehand); the self-hosted GitHub repo was archived 2026-07-20 ([docs](https://docs.browserbase.com/integrations/mcp/introduction)) |
| CLI | - | None official |
| SDK | ✓ | Node, Python; drives Playwright/Puppeteer |

## Authentication

- **Type**: API Key
- **Header**: `x-bb-api-key: YOUR_API_KEY`
- **Get key**: https://www.browserbase.com/settings
- **Env vars**: `BROWSERBASE_API_KEY`, `BROWSERBASE_PROJECT_ID`
- **Base URL**: `https://api.browserbase.com`

## Core Operations

### Create a browser session

```bash
POST https://api.browserbase.com/v1/sessions
x-bb-api-key: YOUR_API_KEY

{
  "projectId": "YOUR_PROJECT_ID"
}
```

Returns a session ID and a WebSocket URL (`connectUrl`) you connect to with Playwright or Puppeteer.

### Connect with Playwright (Node)

```js
import { chromium } from 'playwright-core';
import { Browserbase } from '@browserbasehq/sdk';

const bb = new Browserbase({ apiKey: process.env.BROWSERBASE_API_KEY });
const session = await bb.sessions.create({ projectId: process.env.BROWSERBASE_PROJECT_ID });

const browser = await chromium.connectOverCDP(session.connectUrl);
const page = await browser.newPage();
await page.goto('https://joescoffeeshop.com');
const html = await page.content();
const title = await page.title();
await browser.close();
```

### List session recordings

```bash
GET https://api.browserbase.com/v1/sessions/{sessionId}/logs
```

Useful for debugging when a scrape doesn't return what you expected — session recordings show exactly what the browser saw.

### Stagehand (high-level AI-friendly wrapper)

Browserbase ships [Stagehand](https://github.com/browserbase/stagehand), a Playwright wrapper with `act()`, `extract()`, and `observe()` methods that take natural-language instructions instead of CSS selectors. Stagehand also publishes an MCP server.

```js
import { Stagehand } from '@browserbasehq/stagehand';

const stagehand = new Stagehand({ env: 'BROWSERBASE' });
await stagehand.init();
await stagehand.page.goto('https://joescoffeeshop.com');

const contact = await stagehand.page.extract({
  instruction: "Extract the business phone number, email, and street address",
  schema: { phone: 'string', email: 'string', address: 'string' }
});
```

## When to Use (over Firecrawl)

- **Site requires user interaction** (cookie consent, age gate, click-through before content loads)
- **Form submission** to access a quote/contact page
- **Session state matters** (logged-in tools, multi-step flows)
- **Complex JS rendering** that even Firecrawl's headless option struggles with
- **Want full session recordings** for audit/debugging
- **AI-driven scraping** via Stagehand's natural-language extraction

For simple "scrape a page as markdown," **Firecrawl is lower-overhead**. Use Browserbase when you actually need the browser-as-a-service model.

## When NOT to Use

Same hard rules as Firecrawl. Browserbase gives you a more powerful browser, which means the temptation to bypass anti-scraping defenses is higher. Don't:

- ✗ Bulk-scrape Google Maps / search results, LinkedIn, Yelp, or any platform whose ToS forbids it
- ✗ Bypass CAPTCHAs, login walls, or bot protections
- ✗ Auto-fill forms on platforms you don't have an account or legitimate access to

**Use Browserbase for**: individual public business sites the user has a URL for, where rendering or interaction is required.

## Pricing

- Free tier: limited monthly minutes
- Paid tiers scale by browser minutes + concurrency
- Confirm at https://www.browserbase.com/pricing

## Relevant Skills

- prospecting (programmatic site visits for prospect enrichment)
- competitor-profiling (when competitor sites need rendering or interaction)
- cro (page audits that need real browser state)
- analytics (testing tracking implementations end-to-end)

## File: tools/integrations/buffer.md

# Buffer

Social media scheduling, publishing, and analytics platform for managing multiple social profiles.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v1 for profiles, updates, scheduling |
| MCP | - | Not available |
| CLI | ✓ | [buffer.js](../clis/buffer.js) |
| SDK | - | No official SDK; legacy API still supported |

## Authentication

- **Type**: OAuth 2.0 Bearer Token
- **Header**: `Authorization: Bearer {access_token}`
- **Get key**: Register app at https://buffer.com/developers/apps then complete OAuth flow
- **Note**: Buffer is no longer accepting new developer app registrations; existing apps continue to work. New public API is in development at https://buffer.com/developer-api

## Common Agent Operations

### Get user info

```bash
GET https://api.bufferapp.com/1/user.json

Authorization: Bearer {token}
```

### List connected profiles

```bash
GET https://api.bufferapp.com/1/profiles.json

Authorization: Bearer {token}
```

### Get profile posting schedules

```bash
GET https://api.bufferapp.com/1/profiles/{profile_id}/schedules.json
```

### Create a scheduled post

```bash
POST https://api.bufferapp.com/1/updates/create.json
Content-Type: application/x-www-form-urlencoded

profile_ids[]={profile_id}&text=Your+post+content&scheduled_at=2026-03-01T10:00:00Z
```

### Get pending updates for a profile

```bash
GET https://api.bufferapp.com/1/profiles/{profile_id}/updates/pending.json?count=25
```

### Get sent updates for a profile

```bash
GET https://api.bufferapp.com/1/profiles/{profile_id}/updates/sent.json?count=25
```

### Publish a pending update immediately

```bash
POST https://api.bufferapp.com/1/updates/{update_id}/share.json
```

### Delete an update

```bash
POST https://api.bufferapp.com/1/updates/{update_id}/destroy.json
```

### Reorder queue

```bash
POST https://api.bufferapp.com/1/profiles/{profile_id}/updates/reorder.json
Content-Type: application/x-www-form-urlencoded

order[]={update_id_1}&order[]={update_id_2}&order[]={update_id_3}
```

## API Pattern

Buffer API v1 uses `.json` extensions on all endpoints. POST requests use `application/x-www-form-urlencoded` content type. Array parameters use bracket notation (e.g., `profile_ids[]`).

Responses include a `success` boolean for mutation operations.

## Key Metrics

### Profile Metrics
- `followers` - Follower count for connected profile
- `service` - Platform name (twitter, facebook, instagram, linkedin, etc.)

### Update Metrics (sent updates)
- `statistics.reach` - Post reach
- `statistics.clicks` - Link clicks
- `statistics.retweets` - Retweets/shares
- `statistics.favorites` - Likes/favorites
- `statistics.mentions` - Mentions

## Parameters

### Update Create Parameters
- `profile_ids[]` - Required. Array of profile IDs to post to
- `text` - Required. Post content
- `scheduled_at` - ISO 8601 timestamp for scheduling
- `now` - Set to `true` to publish immediately
- `top` - Set to `true` to add to top of queue
- `shorten` - Set to `true` to auto-shorten links
- `media[photo]` - URL to photo attachment
- `media[thumbnail]` - URL to thumbnail
- `media[link]` - URL for link attachment

## When to Use

- Scheduling social media posts across multiple platforms
- Managing social media content queues
- Analyzing post performance across channels
- Automating social media publishing workflows
- Coordinating team social media activity

## Rate Limits

- 60 authenticated requests per user per minute
- Exceeding returns HTTP 429
- Higher limits available by contacting hello@buffer.com

## Relevant Skills

- social-media-calendar
- content-repurposing
- social-proof
- launch-sequence

## File: tools/integrations/calendly.md

# Calendly

Scheduling and booking platform API for managing event types, scheduled events, invitees, and availability.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2 - event types, scheduled events, invitees, availability |
| MCP | ✓ | Official remote server at `https://mcp.calendly.com` (OAuth with dynamic client registration) ([docs](https://developer.calendly.com/docs/mcp/calendly-mcp-server)) |
| CLI | ✓ | [calendly.js](../clis/calendly.js) |
| SDK | ✓ | No official SDK; community libraries available |

## Authentication

- **Type**: Bearer Token (Personal Access Token or OAuth 2.0)
- **Header**: `Authorization: Bearer {token}`
- **Get key**: https://calendly.com/integrations/api_webhooks (Personal Access Token)

## Common Agent Operations

### Get current user

```bash
GET https://api.calendly.com/users/me
```

### List event types

```bash
GET https://api.calendly.com/event_types?user={user_uri}
```

### List scheduled events

```bash
GET https://api.calendly.com/scheduled_events?user={user_uri}&min_start_time=2024-01-01T00:00:00Z&max_start_time=2024-12-31T23:59:59Z&status=active
```

### Get a scheduled event

```bash
GET https://api.calendly.com/scheduled_events/{event_uuid}
```

### List invitees for an event

```bash
GET https://api.calendly.com/scheduled_events/{event_uuid}/invitees
```

### Cancel a scheduled event

```bash
POST https://api.calendly.com/scheduled_events/{event_uuid}/cancellation

{
  "reason": "Cancellation reason"
}
```

### Get available times

```bash
GET https://api.calendly.com/event_type_available_times?event_type={event_type_uri}&start_time=2024-01-20T00:00:00Z&end_time=2024-01-27T00:00:00Z
```

### Get user busy times

```bash
GET https://api.calendly.com/user_busy_times?user={user_uri}&start_time=2024-01-20T00:00:00Z&end_time=2024-01-27T00:00:00Z
```

### List organization members

```bash
GET https://api.calendly.com/organization_memberships?organization={organization_uri}
```

### Create webhook subscription

```bash
POST https://api.calendly.com/webhook_subscriptions

{
  "url": "https://example.com/webhook",
  "events": ["invitee.created", "invitee.canceled"],
  "organization": "{organization_uri}",
  "scope": "organization"
}
```

### List webhook subscriptions

```bash
GET https://api.calendly.com/webhook_subscriptions?organization={organization_uri}&scope=organization
```

For `scope=user`, include the `user` URI in the list query or creation body.
For `scope=group`, include the `group` URI. The CLI forwards `--user` and
`--group` and rejects these scopes when their identifier is missing.
See [list subscriptions](https://developer.calendly.com/api-docs/calendly-api/webhooks/list-webhook-subscriptions)
and [create subscription](https://developer.calendly.com/api-docs/calendly-api/webhooks/create-webhook-subscription).

### Delete webhook subscription

```bash
DELETE https://api.calendly.com/webhook_subscriptions/{webhook_uuid}
```

## Key Metrics

### Scheduled Event Data
- `uri` - Unique event URI
- `name` - Event type name
- `status` - Event status (active, canceled)
- `start_time` / `end_time` - Event timing
- `event_type` - URI of the event type
- `location` - Meeting location details
- `invitees_counter` - Count of invitees (active, limit, total)

### Invitee Data
- `name` - Invitee full name
- `email` - Invitee email
- `status` - active or canceled
- `questions_and_answers` - Custom question responses
- `tracking` - UTM parameters
- `created_at` / `updated_at` - Timestamps

## Parameters

### List Scheduled Events
- `user` - User URI (required)
- `min_start_time` / `max_start_time` - Date range filter (ISO 8601)
- `status` - Filter by status (active, canceled)
- `count` - Number of results (default 20, max 100)
- `page_token` - Pagination token
- `sort` - Sort order (start_time:asc or start_time:desc)

### List Event Types
- `user` - User URI
- `organization` - Organization URI
- `active` - Filter active/inactive
- `count` - Results per page
- `sort` - Sort order

## When to Use

- Retrieving scheduled meeting data for CRM sync
- Monitoring booking activity and conversion rates
- Automating follow-up workflows after meetings
- Checking availability before suggesting meeting times
- Tracking meeting cancellations and no-shows
- Building custom booking interfaces

## Rate Limits

- Not officially documented; implement retry logic with exponential backoff
- Use conservative request rates (avoid bursting)
- Monitor for HTTP 429 responses

## Relevant Skills

- lead-generation
- sales-automation
- customer-onboarding
- appointment-scheduling

## File: tools/integrations/clay.md

# Clay

Data enrichment and outbound automation platform for building lead lists with waterfall enrichment across 75+ data providers.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Tables, People Enrichment, Company Enrichment |
| MCP | ✓ | Official hosted server at `https://api.clay.com/v3/mcp` (OAuth): find and enrich people and companies, run your Clay workflows ([guide](https://www.clay.com/guides/clay-mcp)) |
| CLI | ✓ | [clay.js](../clis/clay.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key (Bearer token)
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API at https://app.clay.com

## Common Agent Operations

### List Tables

```bash
GET https://api.clay.com/v3/tables

Authorization: Bearer {api_key}
```

### Get Table Details

```bash
GET https://api.clay.com/v3/tables/{table_id}

Authorization: Bearer {api_key}
```

### Get Table Rows

```bash
GET https://api.clay.com/v3/tables/{table_id}/rows?page=1&per_page=25

Authorization: Bearer {api_key}
```

### Add Row to Table

```bash
POST https://api.clay.com/v3/tables/{table_id}/rows

{
  "first_name": "Jane",
  "last_name": "Doe",
  "company": "Acme Inc",
  "email": "jane@acme.com"
}
```

### People Enrichment

```bash
POST https://api.clay.com/v3/people/enrich

{
  "email": "jane@acme.com"
}
```

### Company Enrichment

```bash
POST https://api.clay.com/v3/companies/enrich

{
  "domain": "acme.com"
}
```

## Key Metrics

### Person Data
- `first_name`, `last_name` - Name
- `email` - Email address
- `title` - Job title
- `linkedin_url` - LinkedIn profile
- `company` - Company name
- `location` - Location
- `seniority` - Seniority level

### Company Data
- `name` - Company name
- `domain` - Website domain
- `industry` - Industry
- `employee_count` - Number of employees
- `revenue` - Estimated revenue
- `location` - Headquarters location
- `technologies` - Tech stack
- `description` - Company description

### Table Data
- `id` - Table ID
- `name` - Table name
- `row_count` - Number of rows
- `columns` - Column definitions
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

## Parameters

### Tables
- `page` - Page number (default: 1)
- `per_page` - Results per page (default: 25)

### People Enrichment
- `email` - Email address
- `linkedin_url` - LinkedIn profile URL
- `first_name` + `last_name` - Name-based lookup

### Company Enrichment
- `domain` - Company domain (e.g., "acme.com")

### Add Row
- Fields are dynamic and match the table's column definitions
- Pass data as key-value pairs matching column names

## When to Use

- Building enriched prospect lists with waterfall enrichment across multiple providers
- Enriching leads with person and company data from 75+ sources
- Automating outbound workflows with enriched data
- Finding verified contact info (emails, phone numbers, social profiles)
- Company research and firmographic analysis
- Triggering enrichment workflows via webhooks
- Syncing enriched data back to CRM or outbound tools

## Rate Limits

- Rate limits vary by plan
- Standard: 100 requests/minute
- Enterprise plans have higher limits
- Enrichment credits consumed per lookup vary by data provider
- Webhook endpoints accept data continuously

## Relevant Skills

- cold-email
- revops
- sales-enablement
- competitors

## File: tools/integrations/clearbit.md

# Clearbit (HubSpot Breeze Intelligence)

Company and person data enrichment API for converting leads with 100+ firmographic and technographic attributes.

> **Status (checked 2026-10-07): legacy API, not for new projects.** HubSpot acquired Clearbit and now sells its data as Breeze Intelligence inside HubSpot. Per [Clearbit's changelog](https://www.clearbit.com/changelog), the free platform, weekly visitor report, Clearbit Connect, and TAM calculator were discontinued on 2025-04-30, and the public Logo API ended on 2025-12-08. The changelog has no sunset notice for the Enrichment, Reveal, or Prospector APIs, so existing API keys keep working, but third-party reports agree that new standalone API keys aren't issued to accounts created since 2024. If you don't already have a key, use Breeze Intelligence inside HubSpot, or an alternative: [apollo](apollo.md), [zoominfo](zoominfo.md), [leadmagic](leadmagic.md), or [fullenrich](fullenrich.md) for enrichment, and [rb2b](rb2b.md) or similar for visitor identification.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | Legacy | Person, Company, Combined Enrichment, Reveal, Name to Domain, Prospector; existing keys only (see status) |
| MCP | - | Not available |
| CLI | ✓ | [clearbit.js](../clis/clearbit.js) |
| SDK | ✓ | Node, Ruby, Python, PHP |

## Authentication

- **Type**: Bearer Token (or Basic Auth with API key as username)
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: https://dashboard.clearbit.com/api

## Common Agent Operations

### Person Enrichment (by email)

```bash
GET https://person.clearbit.com/v2/people/find?email=alex@clearbit.com
```

Returns 100+ attributes: name, title, company, location, social profiles, employment history.

### Company Enrichment (by domain)

```bash
GET https://company.clearbit.com/v2/companies/find?domain=clearbit.com
```

Returns firmographics: industry, size, revenue, tech stack, location, funding.

### Combined Enrichment (person + company)

```bash
GET https://person.clearbit.com/v2/combined/find?email=alex@clearbit.com
```

Returns both person and company data in a single request.

### Reveal (IP to company)

```bash
GET https://reveal.clearbit.com/v1/companies/find?ip=104.132.0.0
```

Identifies the company behind a website visitor by IP address.

### Name to Domain

```bash
GET https://company.clearbit.com/v1/domains/find?name=Clearbit
```

Converts a company name to its domain.

### Prospector (find employees)

```bash
GET https://prospector.clearbit.com/v1/people/search?domain=clearbit.com&role=sales&seniority=executive
```

Finds employees at a company filtered by role, seniority, title.

## API Pattern

Clearbit uses separate subdomains per API:
- `person.clearbit.com` - Person data
- `company.clearbit.com` - Company data, Name to Domain
- `person-stream.clearbit.com` - Streaming person lookup (blocking, up to 60s)
- `company-stream.clearbit.com` - Streaming company lookup (blocking, up to 60s)
- `reveal.clearbit.com` - IP to company
- `prospector.clearbit.com` - Employee search

Standard endpoints return `202 Accepted` if data is being processed (use webhooks). Stream endpoints block until data is ready.

## Key Metrics

### Person Attributes
- `name.fullName` - Full name
- `title` - Job title
- `role` - Job role (sales, engineering, etc.)
- `seniority` - Seniority level
- `employment.name` - Company name
- `linkedin.handle` - LinkedIn profile

### Company Attributes
- `name` - Company name
- `domain` - Website domain
- `category.industry` - Industry
- `metrics.employees` - Employee count
- `metrics.estimatedAnnualRevenue` - Revenue range
- `tech` - Technology stack array
- `metrics.raised` - Total funding raised

## Parameters

### Person Enrichment
- `email` (required) - Email address to look up
- `webhook_url` - URL for async results
- `subscribe` - Subscribe to future changes

### Company Enrichment
- `domain` (required) - Company domain to look up
- `webhook_url` - URL for async results

### Prospector
- `domain` (required) - Company domain
- `role` - Job role filter (sales, engineering, marketing, etc.)
- `seniority` - Seniority filter (executive, director, manager, etc.)
- `title` - Exact title filter
- `page` - Page number (default: 1)
- `page_size` - Results per page (default: 5, max: 20)

## When to Use

- Lead scoring and qualification based on firmographic data
- Enriching CRM contacts with company and person data
- De-anonymizing website visitors with Reveal
- Building prospect lists with Prospector
- Personalizing marketing based on company attributes
- Routing leads based on company size, industry, or tech stack

## Rate Limits

- Enrichment: 600 requests/minute
- Prospector: 100 requests/minute
- Reveal: 600 requests/minute
- Responses include `X-RateLimit-Limit` and `X-RateLimit-Remaining` headers

## Relevant Skills

- prospecting
- revops (lead scoring and routing)
- ads (ABM targeting)
- competitor-profiling

## File: tools/integrations/close.md

# Close

Sales CRM for SMBs with built-in calling, email, and pipeline management designed for high-velocity sales teams.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Leads, Contacts, Opportunities, Activities, Tasks |
| MCP | ✓ | Official remote server at `https://mcp.close.com/mcp` (OAuth) with read, safe-write, and destructive-write scopes ([docs](https://developer.close.com/mcp)) |
| CLI | ✓ | [close.js](../clis/close.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: Basic Auth
- **Header**: `Authorization: Basic {base64(api_key + ':')}`
- **Get key**: Settings > API Keys at https://app.close.com

## Common Agent Operations

### List Leads

```bash
GET https://api.close.com/api/v1/lead/

Authorization: Basic {base64(api_key + ':')}
```

### Search Leads

```bash
GET https://api.close.com/api/v1/lead/?query=company_name

Authorization: Basic {base64(api_key + ':')}
```

### Create Lead

```bash
POST https://api.close.com/api/v1/lead/

{
  "name": "Acme Corp",
  "url": "https://acme.com",
  "description": "Enterprise prospect"
}
```

### Get Contact

```bash
GET https://api.close.com/api/v1/contact/{contact_id}/

Authorization: Basic {base64(api_key + ':')}
```

### Create Contact

```bash
POST https://api.close.com/api/v1/contact/

{
  "lead_id": "lead_xxx",
  "name": "Jane Smith",
  "emails": [{ "email": "jane@acme.com", "type": "office" }],
  "phones": [{ "phone": "+15551234567", "type": "office" }]
}
```

### Create Opportunity

```bash
POST https://api.close.com/api/v1/opportunity/

{
  "lead_id": "lead_xxx",
  "value": 50000,
  "status_id": "stat_xxx"
}
```

To select a stage when creating an opportunity, retrieve an ID from
`GET https://api.close.com/api/v1/status/opportunity/` and pass
`--status-id stat_xxx` to the CLI. `--status` is accepted as an ID alias.
The `active`, `won`, and `lost` types describe statuses; they cannot select a
specific stage when creating an opportunity. Omitting both flags uses the
organization default status. See the official
[create opportunity](https://developer.close.com/api/resources/opportunities/create)
and [list opportunity statuses](https://developer.close.com/api/resources/opportunity-statuses/list) contracts.

### List Activities

```bash
GET https://api.close.com/api/v1/activity/?lead_id=lead_xxx

Authorization: Basic {base64(api_key + ':')}
```

### Create Task

```bash
POST https://api.close.com/api/v1/task/

{
  "lead_id": "lead_xxx",
  "text": "Follow up on demo request",
  "_type": "lead",
  "date": "2026-03-10"
}
```

## Key Metrics

### Lead Data
- `id` - Lead ID
- `display_name` - Lead name
- `url` - Website URL
- `description` - Lead description
- `status_id` - Pipeline status
- `contacts` - Associated contacts
- `opportunities` - Associated opportunities
- `tasks` - Associated tasks

### Contact Data
- `id` - Contact ID
- `lead_id` - Parent lead
- `name` - Full name
- `title` - Job title
- `emails` - Email addresses array
- `phones` - Phone numbers array

### Opportunity Data
- `id` - Opportunity ID
- `lead_id` - Parent lead
- `value` - Value in cents
- `status_type` - active, won, or lost
- `confidence` - Win probability (0-100)
- `date_won` - Close date

### Task Data
- `id` - Task ID
- `lead_id` - Parent lead
- `text` - Task description
- `assigned_to` - Assigned user ID
- `date` - Due date
- `is_complete` - Completion status

## Parameters

### Leads
- `query` - Search query string
- `_skip` - Number of results to skip (pagination)
- `_limit` - Max results to return (default: 100)
- `_fields` - Comma-separated fields to return

### Contacts
- `lead_id` - Filter by parent lead
- `_skip` - Pagination offset
- `_limit` - Max results

### Opportunities
- `lead_id` - Filter by parent lead
- `status` - Filter by status type (active, won, lost)
- `_skip` - Pagination offset
- `_limit` - Max results

### Activities
- `lead_id` - Filter by lead
- `_type__type` - Filter by type (Email, Call, Note, SMS, Meeting)
- `date_created__gt` - After date
- `date_created__lt` - Before date

### Tasks
- `assigned_to` - Filter by user ID
- `is_complete` - Filter by completion (true/false)
- `lead_id` - Filter by lead
- `_type` - Task type (lead)

## When to Use

- Managing SMB sales pipelines with high-touch outreach
- Tracking sales activities (calls, emails, meetings) per lead
- Creating and managing tasks for sales follow-ups
- Opportunity tracking and revenue forecasting
- Building automated outreach workflows
- Sales team performance reporting

## Rate Limits

- Rate limits based on organization plan
- Standard: ~100 requests/minute
- Responses include `ratelimit-limit` and `ratelimit-remaining` headers
- 429 responses include `Retry-After` header

## Relevant Skills

- revops
- sales-enablement
- cold-email

## Paging bundled CLI CRM collections

All five list commands (`leads`, `contacts`, `opportunities`, `activities`, `tasks`) accept `--page <positive_integer>` or `--skip <nonnegative_offset>` and optional `--limit <1-100>`. Page offsets use the selected limit, so page 2 at limit 25 starts at offset 25, not 100. Omitted flags preserve provider defaults; legacy `--page` without a limit uses 100 records per page.

```bash
node tools/clis/close.js contacts list --lead-id lead_example --page 2 --limit 25 --dry-run
```

Read `has_more` and request subsequent pages manually; the CLI preserves raw responses and never fetches extra pages silently. The CLI conservatively supports limits up to 100; provider resource-specific limits still apply. [Close pagination](https://developer.close.com/api/overview/pagination) documents `_skip` and `_limit`. Contract tests use fixtures, not real CRM records.

## File: tools/integrations/cogny.md

# Cogny

Hosted MCP gateway that bundles several marketing tools behind one URL with managed OAuth. Useful when you want AI agents to talk to multiple marketing channels without standing up your own OAuth proxy.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | - | Access is via MCP, not a public REST API |
| MCP | ✓ | One federated MCP URL, OAuth-managed per channel |
| CLI | - | Connect tools via the Cogny dashboard |
| SDK | - | Use any MCP-capable client (Claude.ai, Claude API, Claude CLI, ChatGPT, etc.) |

## How it works

```
┌──────────────────┐      ┌──────────────────────┐      ┌───────────────────┐
│  Claude.ai /     │──────│  app.cogny.com/mcp   │──────│  Channel API      │
│  Claude CLI /    │      │  (federated MCP      │      │  (LinkedIn, GSC,  │
│  ChatGPT, etc.   │      │   endpoint)          │      │   TikTok, …)      │
└──────────────────┘      └──────────────────────┘      └───────────────────┘
                                    │
                                    │  Federates per-channel
                                    │  mcp.cogny.com endpoints
                                    ▼  with managed OAuth
```

`https://app.cogny.com/mcp` is a single federated endpoint that fans out to the per-channel `mcp.cogny.com` MCP servers — you connect once and every channel you've authorized in the dashboard becomes available.

## When to Use Cogny vs. Native or Composio

Cogny is one of several integration paths. Pick based on what you need:

| Scenario | Suggested |
|----------|-----------|
| Tool has a native MCP server you can self-host | Native MCP |
| You want a single bill / single login across many channels | Cogny or Composio |
| You need 500+ tools (CRM, productivity, dev tools, etc.) | [Composio](composio.md) |
| You only need the marketing channels Cogny ships | Cogny |
| You need deep, custom control over a single tool | Native API + CLI |

Cogny is narrower than Composio — it focuses on marketing channels — but the trade-off is fewer moving parts when you only need those channels.

## Setup

### 1. Connect your channels

1. Sign up at [cogny.com](https://cogny.com) and create a workspace.
2. In the dashboard, connect the channels you want (OAuth flow per tool).

### 2. Add Cogny as a custom connector

In Claude.ai:

1. Go to **Settings → Connectors → Add custom connector**.
2. Enter name **Cogny** and paste your MCP URL:

   ```
   https://app.cogny.com/mcp
   ```

3. Complete the OAuth handshake when prompted.

The same `https://app.cogny.com/mcp` URL works in any MCP-capable client (Claude API, Claude CLI, ChatGPT custom connectors, etc.) — Cogny handles auth and routes each tool call to the right underlying channel.

## Channels Available via Cogny

Coverage changes over time — check the Cogny dashboard for the current list.

### SEO

| Channel | Typical use |
|---------|-------------|
| Search Console | Search analytics, URL inspection, sitemap submission |
| Bing Webmaster | Coverage, query stats, URL submission quota |
| Semrush | Keyword research, competitor checks (subject to Semrush plan) |

### Paid Social

| Channel | Typical use |
|---------|-------------|
| LinkedIn Ads | Campaign reporting, audience overlap, creative checks |
| Reddit Ads | Campaign reporting, audience and conversion lookups |
| TikTok Ads | Campaign reporting, ad group / creative health |

### Analytics

| Channel | Typical use |
|---------|-------------|
| Plausible | Privacy-friendly site analytics, goal reporting |
| Fathom | Privacy-friendly site analytics |

## Common Agent Operations

Once `https://app.cogny.com/mcp` is wired up, the agent picks tools by name across every channel you've connected.

### Search Console — pages losing clicks

```
> "Pull Search Console clicks for the last 28 days vs the previous 28 days,
   group by page, and list pages where clicks dropped more than 30%."
```

### LinkedIn Ads — campaign hygiene

```
> "List my active LinkedIn campaigns, their CTR and CPL for the last 14 days,
   and flag anything with CTR below 0.4%."
```

### Reddit Ads — audience overlap

```
> "For my Reddit Ads campaigns this month, summarize spend, conversions, and
   the subreddits driving the most clicks."
```

### TikTok Ads — creative fatigue

```
> "Find TikTok ad groups where CTR has dropped 25%+ over the last 7 days
   compared to the prior 7 days."
```

### Plausible — funnel sanity check

```
> "From Plausible, show top 10 pages by pageviews and the conversion rate
   for the 'Signup' goal over the last 30 days."
```

## Limitations

- **Marketing-only scope** — Cogny ships marketing channels; for CRM, productivity, or dev tools use [Composio](composio.md) or the relevant native integration.
- **Hosted dependency** — if `app.cogny.com` is down, the connected channels are unavailable through this path.
- **Coverage depth varies** — read-heavy and reporting tools generally have more depth than write/mutation tools.
- **OAuth tokens** — managed by Cogny; you don't control token refresh or storage directly.

## Pricing

Cogny's Solo plan starts at **$9/month** and includes a 7-day free trial. Higher tiers are available for teams. Check [cogny.com/pricing](https://cogny.com/pricing) for current plans and limits.

## See Also

- [Composio](composio.md) — broader integration layer (500+ tools, OAuth-heavy CRMs and productivity apps)
- [Google Search Console](google-search-console.md) — native API guide if you'd rather call GSC directly
- [LinkedIn Ads](linkedin-ads.md), [TikTok Ads](tiktok-ads.md) — native API guides

## Relevant Skills

- seo-audit (Search Console, Bing Webmaster, Semrush via Cogny)
- paid-ads (LinkedIn, Reddit, TikTok via Cogny)
- analytics-tracking (Plausible, Fathom via Cogny)

## File: tools/integrations/composio.md

# Composio

Managed OAuth and pre-built tool connectors for 500+ apps via a single MCP server. Provides agent-native access to marketing tools that lack native MCP support.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for managing connections and triggering actions |
| MCP | ✓ | Single MCP server exposes all connected tools |
| CLI | ✓ | `npx composio` for managing apps, connections, and actions |
| SDK | ✓ | TypeScript and Python SDKs |

## Authentication

- **Type**: OAuth 2.0 (per-tool, managed by Composio) or API Key
- **Setup**: `npx @composio/mcp@latest setup` to install, then authenticate each tool via Connect Link in browser
- **API Key** (optional): `COMPOSIO_API_KEY` env var for advanced/team usage

Composio handles OAuth token management, refresh, and storage for all connected tools. Individual tool auth types are listed in the Marketing Tools table below.

## When to Use Composio vs. Native Tools

Composio is an **alternative integration method**, not a replacement. Use this decision guide:

| Scenario | Use |
|----------|-----|
| Tool has native MCP server (GA4, Stripe, Mailchimp) | Native MCP server |
| Tool has CLI but no MCP (LinkedIn Ads, Salesforce) | Composio for MCP access |
| OAuth-heavy tool with no CLI (Google Sheets, Slack, Notion) | Composio |
| Need deep, customized integration | Native API + CLI |
| Need quick read/write access across many tools | Composio |
| Tool not covered by Composio | Native API guide |

## Setup

### 1. Install the MCP server

```bash
npx @composio/mcp@latest setup
```

This adds the Composio MCP server to your Claude Code configuration.

### 2. Verify installation

In Claude Code, run `/mcp` to confirm `composio` appears in your MCP server list.

### 3. Authenticate a tool

When you first use a Composio-backed tool, you'll receive a Connect Link. Open it in your browser to complete OAuth. The connection persists across sessions.

```
# Example: connect HubSpot
> "Pull my top 10 HubSpot contacts"
# Agent will prompt: "Please authenticate HubSpot: [Connect Link]"
# Click link → authorize → done
```

### 4. API key (optional)

For advanced usage or team setups, set your Composio API key:

```bash
export COMPOSIO_API_KEY=your_key_here
```

## Marketing Tools Available via Composio

### New MCP Coverage

These tools have API guides in this repo but **no native MCP server**. Composio adds MCP access:

| Tool | Composio Toolkit | Auth Type | Coverage Depth |
|------|-----------------|-----------|----------------|
| Salesforce | `SALESFORCE` | OAuth 2.0 | Deep (SOQL, objects, leads, opportunities) |
| Meta Ads | `FACEBOOKADS` | OAuth 2.0 | Medium (campaigns, ad sets, insights) |
| LinkedIn Ads | `LINKEDIN` | OAuth 2.0 | Medium (campaigns, analytics, company pages) |
| Google Sheets | `GOOGLESHEETS` | OAuth 2.0 | Deep (read, write, create, format) |
| Slack | `SLACK` | OAuth 2.0 | Deep (messages, channels, files) |
| Notion | `NOTION` | OAuth 2.0 | Deep (pages, databases, blocks) |
| Airtable | `AIRTABLE` | OAuth 2.0 | Deep (records, tables, views) |
| ActiveCampaign | `ACTIVECAMPAIGN` | API Key | Medium (contacts, lists, automations) |
| Klaviyo | `KLAVIYO` | API Key | Medium (profiles, lists, campaigns) |
| Shopify | `SHOPIFY` | OAuth 2.0 | Deep (products, orders, customers) |
| Gmail | `GMAIL` | OAuth 2.0 | Deep (read, send, labels, search) |

### Alternative to Existing Tools

These tools **already have native MCP or CLI** in this repo. Composio provides an alternative path:

| Tool | Native Integration | Composio Toolkit | When to Use Composio |
|------|-------------------|-----------------|---------------------|
| Mailchimp | MCP ✓, CLI ✓ | `MAILCHIMP` | If native MCP setup fails |
| Google Ads | MCP ✓, CLI ✓ | `GOOGLEADS` | If OAuth is simpler via Composio |
| Stripe | MCP ✓, CLI ✓ | `STRIPE` | Prefer native (deeper coverage) |
| GA4 | MCP ✓, CLI ✓ | `GOOGLEANALYTICS` | Prefer native (deeper coverage) |
| HubSpot | MCP ✓ (official remote server, GA April 2026) | `HUBSPOT` | When you want one connector across many apps; prefer native for CRM writes |

## Common Agent Operations

### List available tools

```bash
# Via Composio CLI
npx composio apps list
```

### Check connection status

```bash
npx composio connections list
```

### Trigger an action programmatically

```bash
POST https://backend.composio.dev/api/v1/actions/{action_id}/execute

{
  "connectedAccountId": "account_xxx",
  "input": {
    "query": "contact email = user@example.com"
  }
}
```

### Disconnect a tool

```bash
npx composio connections remove {connection_id}
```

## Example Workflows

### Pull CRM data into a spreadsheet

```
> "Get my top 20 HubSpot contacts by last activity and add them to a Google Sheet"
```
Agent uses Composio's `HUBSPOT` to fetch contacts and `GOOGLESHEETS` to write rows.

### Cross-platform ad reporting

```
> "Compare my Meta Ads and LinkedIn Ads spend this month"
```
Agent uses `FACEBOOKADS` and `LINKEDIN` toolkits to pull campaign data.

### Notify team about new leads

```
> "Get my Salesforce leads from today and post a summary in Slack #sales"
```
Agent uses `SALESFORCE` to read leads and `SLACK` to post messages.

## Limitations

- **Coverage depth varies** — some toolkits expose hundreds of actions (HubSpot, Google Sheets), others only a handful
- **No customization** — you can't modify Composio's action schemas or add custom endpoints
- **Vendor dependency** — if Composio's servers are down, all connected tools are unavailable
- **Rate limits apply** — Composio enforces its own rate limits on top of each tool's native limits
- **OAuth tokens** — managed by Composio; you don't control token refresh or storage
- **Action naming** — Composio action names may differ from native API terminology

## Pricing

| Plan | Monthly Price | API Calls | Notes |
|------|--------------|-----------|-------|
| Free | $0 | 20,000 | Good for exploration and personal use |
| Growth | $29 | 200,000 | For regular use across multiple tools |
| Business | $229 | 2,000,000 | For teams and heavy automation |

## Rate Limits

- Free tier: 20,000 calls/month, 10 req/sec
- Growth tier: 200,000 calls/month, 50 req/sec
- Business tier: 2,000,000 calls/month, 100 req/sec

## See Also

- [Quick start guide](../composio/README.md) — install, connect, and use in 5 minutes
- [Marketing tools mapping](../composio/marketing-tools.md) — detailed toolkit-to-category reference

## Relevant Skills

- analytics (cross-platform data via Composio connectors)
- emails (ActiveCampaign, Klaviyo access)
- ads (LinkedIn Ads MCP access; Meta Ads also has an official MCP)
- referrals (Shopify integration)

## File: tools/integrations/contentful.md

# Contentful

Enterprise headless CMS with multi-locale support, two-API architecture, and composable content.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Content Delivery API (read), Content Management API (write) |
| MCP | - | No official MCP server |
| CLI | ✓ | `contentful-cli` for spaces, content types, migrations |
| SDK | ✓ | `contentful` (delivery), `contentful-management` (management) |

## Authentication

- **Delivery API (CDA)**: `Authorization: Bearer {delivery_token}`
  - Base URL: `https://cdn.contentful.com`
  - Read-only, CDN-cached
- **Preview API (CPA)**: `Authorization: Bearer {preview_token}`
  - Base URL: `https://preview.contentful.com`
  - Read-only, returns draft content
- **Management API (CMA)**: `Authorization: Bearer {management_token}`
  - Base URL: `https://api.contentful.com`
  - Read/write, not cached
- **Tokens**: Create in Settings → API keys (delivery) or Settings → CMA tokens (management)

## Common Agent Operations

### Get entries (Delivery API)

```bash
GET https://cdn.contentful.com/spaces/{space_id}/environments/{environment}/entries?content_type=blogPost&limit=10

Authorization: Bearer {delivery_token}
```

### Get single entry

```bash
GET https://cdn.contentful.com/spaces/{space_id}/environments/{environment}/entries/{entry_id}

Authorization: Bearer {delivery_token}
```

### Search and filter

```bash
# By field value
GET https://cdn.contentful.com/spaces/{space_id}/environments/{environment}/entries?content_type=blogPost&fields.slug=my-post

# Full-text search
GET https://cdn.contentful.com/spaces/{space_id}/environments/{environment}/entries?query=marketing+strategy

# By date range
GET https://cdn.contentful.com/spaces/{space_id}/environments/{environment}/entries?content_type=blogPost&fields.publishDate[gte]=2024-01-01
```

### Create entry (Management API)

CMA uses PUT with a client-generated `entry_id`. To auto-generate, use POST without an ID in the path.

```bash
PUT https://api.contentful.com/spaces/{space_id}/environments/{environment}/entries/{entry_id}
Content-Type: application/vnd.contentful.management.v1+json
X-Contentful-Content-Type: blogPost
Authorization: Bearer {management_token}

{
  "fields": {
    "title": {"en-US": "New Post"},
    "slug": {"en-US": "new-post"},
    "body": {"en-US": "Post content here"}
  }
}
```

### Update entry

```bash
PUT https://api.contentful.com/spaces/{space_id}/environments/{environment}/entries/{entry_id}
Content-Type: application/vnd.contentful.management.v1+json
X-Contentful-Version: {current_version}
Authorization: Bearer {management_token}

{
  "fields": {
    "title": {"en-US": "Updated Title"}
  }
}
```

### Publish entry

```bash
PUT https://api.contentful.com/spaces/{space_id}/environments/{environment}/entries/{entry_id}/published
X-Contentful-Version: {current_version}
Authorization: Bearer {management_token}
```

### Unpublish entry

```bash
DELETE https://api.contentful.com/spaces/{space_id}/environments/{environment}/entries/{entry_id}/published
X-Contentful-Version: {current_version}
Authorization: Bearer {management_token}
```

## CLI Commands

```bash
# Login
contentful login

# List spaces
contentful space list

# Export space content
contentful space export --space-id {space_id}

# Import content
contentful space import --space-id {space_id} --content-file export.json

# Create migration
contentful space migration --space-id {space_id} migration.js

# List content types
contentful content-type list --space-id {space_id}
```

## Key Objects

- **Space** — Top-level container for content (one per project)
- **Environment** — Isolated content branch (`master`, `staging`, etc.)
- **Content Type** — Schema definition with fields and validations
- **Entry** — Content item of a specific content type
- **Asset** — Media file (image, video, document)
- **Locale** — Language/region variant (e.g., `en-US`, `de-DE`)

## When to Use

- Multi-locale marketing content (global sites)
- Enterprise content operations with approval workflows
- Composable content architecture
- Teams needing established vendor support and SLAs
- Content reuse across multiple channels

## Rate Limits

Rate limits are plan-dependent. Check `X-Contentful-RateLimit-Second-Limit` response header for your actual limits.

- Delivery API (CDA): Varies by plan (typically high throughput)
- Preview API (CPA): Lower than CDA (varies by plan)
- Management API (CMA): ~10 requests per second (default)
- See [Contentful technical limits](https://www.contentful.com/developers/docs/technical-limits/) for current values

## Relevant Skills

- content-strategy (CMS selection, content modeling)
- programmatic-seo (CMS as data source for generated pages)
- site-architecture (multi-locale URL structure)

## File: tools/integrations/converly.md

# Converly

> **◆ Verified Partner integration.** Converly sponsors Marketing Skills. This integration is disclosed and vetted for fit; it does **not** change what any skill recommends. It's listed here alongside the neutral options for the same job — use it when it's the right fit, not because it's a partner. See [Verified Partners](../REGISTRY.md#verified-partners).

Server-side conversion tracking for lead generation. When a visitor submits a form, books a meeting, or starts a chat, Converly sends the conversion to your ad platforms and analytics tools from its servers, with the lead's details attached so each platform can match it to the ad click.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API to manage sites, flows and destinations and read the conversion log. Backend-confirmed conversions go through the API trigger webhook, via the SDK below or a signed HTTP call. [developers.converly.io](https://developers.converly.io) |
| MCP | ✓ | Hosted MCP server at `https://app.converly.io/mcp` ([setup guide](https://converly.io/mcp)). An agent can do the setup and read the conversion log; the account owner signs in to each ad platform and installs the site snippet |
| CLI | ✓ | `@converly/cli`. JSON output by default, built for agents |
| SDK | ✓ | `@converly/sdk-node` for conversions only your backend can confirm (a verified signup, an API-received lead) |

## What it does

- **Sources (100).** Form builders (Gravity Forms, WPForms, Contact Form 7, Elementor, Fluent Forms, Formidable, Ninja Forms, Webflow, Framer, Wix, Squarespace and more), iframe tools connected by the account owner (Typeform, Jotform, Calendly, Acuity, Cal.com), chat (Intercom, LiveChat, Drift, HubSpot Chat), CRMs and email platforms (HubSpot, Salesforce, Pipedrive, HighLevel, ActiveCampaign, Mailchimp, Klaviyo), and course and membership platforms (Kajabi, Teachable, Thinkific, LearnDash). Full list under Supported tools below.
- **Destinations (18).** Google Ads, Meta Ads, Google Analytics, LinkedIn Ads, TikTok Ads, Microsoft Ads, Reddit Ads, ChatGPT Ads, Snapchat Ads, Pinterest Ads, X Ads, AdRoll, Taboola, and the privacy analytics tools Plausible, Fathom, GoSquared, Simple Analytics and Pirsch.
- **What travels with each conversion.** The lead's name, email and phone, the ad click IDs (gclid, gbraid, wbraid, fbclid, ttclid, li_fat_id, rdt_cid and ChatGPT's oppref), IP address and user agent. Contact details are formatted and hashed the way each platform requires, which is what Google's Enhanced Conversions and Meta's match quality run on.
- **Only confirmed successes count.** It fires on the tool's own success signal, never on a button click or a thank-you page load, so submissions the form rejects, including ones its spam protection blocks, aren't counted. For iframe tools, the lead's details are fetched from the tool's API once it confirms the submission.
- **Deduplication.** Where the platform's own tag is on the site, Converly fires into it and sends the server event with the same event ID, so the platform counts one conversion. Conversions from connected iframe tools are sent server-side only.
- **Delivery.** Failed sends retry automatically, and a recovery job picks up anything interrupted. A conversion that can't be delivered within about an hour is marked failed with the reason, so a lost connection shows up rather than failing silently.
- **Conversion log.** Organised by conversion: who converted, which form, what was captured, and whether each platform accepted it. Opening one shows the exact fields sent, the API request, the platform's response, and a plain-language error when something failed. 30 days of history.
- **Privacy.** Stops entirely when a browser sends Global Privacy Control. With a consent platform connected, it checks advertising consent at the moment of conversion. Passwords, card numbers and similar fields are never read. Data is hosted in the United States (Supabase and Railway); contact details are deleted after 7 days and conversion records after 30. An optional privacy mode keeps personal data out of the log entirely.
- **Pricing.** Standard $19/mo (1 site, 1 conversion flow, 100 conversions a month), Premium $49/mo (5 flows, 500 conversions), Enterprise custom. 14-day free trial. A flow is one source tool sending to any number of destinations, so one contact form going to Google Ads, Meta and GA4 is a single flow; a second tool, like a Calendly widget next to a Gravity Forms form, is a second flow.
- **Platform-reported results (these measure the platform features Converly uses, not Converly itself).** Meta says advertisers with a Conversions API setup saw an average 17.8% lower cost per result ([Meta, April 2026](https://www.facebook.com/business/news/pixel-conversionsapi-updates)). Google says advertisers using enhanced conversions saw an average 11% more Search conversions than with standard conversion imports ([Google, September 2026](https://blog.google/products/ads-commerce/data-strength-updates/)). These are platform averages; verify any lift in your own account with a holdout.

## Supported tools

Check this list before telling a user a tool is or isn't covered. Taken from [converly.io/integrations](https://converly.io/integrations) on 25 Sep 2026; the live page is the source of truth.

**Sources (100):** Gravity Forms, Contact Form 7, WPForms, Elementor, HubSpot Forms, Calendly, Typeform, Jotform, Intercom, ActiveCampaign, Wix Forms, Webflow, Squarespace, LiveChat, Acuity Scheduling, Tawk.to, Drift, Cal.com, Tally Forms, Ninja Forms, Formidable Forms, Fluent Forms, Forminator, Formstack, Framer, Marketo, Chili Piper, ClickFunnels, Unbounce, Pardot, Fillout Forms, Eloqua, HighLevel, Qualified, Paperform, Zoho Forms, OnceHub, Zoho SalesIQ, FormAssembly, Instapage, Avada, Duda, YouCanBookMe, Keap, Netlify, WS Form, GetLeadForms, Formsite, HubSpot Chat, HubSpot Meetings, Everest Forms, HappyForms, SureForms, Bloom, Hello Bar, OptinMonster, Popup Builder, Popup Maker, Square Appointments, Mindbody, Jobber, ServiceTitan, Housecall Pro, Mailchimp, Klaviyo, Brevo, Constant Contact, AWeber, GetResponse, MailerLite, Kit, MailPoet, Newsletter, Salesforce, Pipedrive, Systeme.io, Beaver Builder, Bricks, Brizy, Divi, SeedProd, Demio, Livestorm, WebinarJam, Goldcast, Kajabi, Teachable, Thinkific, LearnDash, LearnPress, Sensei, Tutor LMS, Mighty Networks, Paid Memberships Pro, ProfilePress, Ultimate Member, WishList Member, ThriveCart, Easy Digital Downloads, Wix Bookings.

**Destinations (18):** Google Ads, Meta Ads, Google Analytics, ChatGPT Ads, Microsoft Ads, TikTok Ads, LinkedIn Ads, Snapchat Ads, Pinterest Ads, X Ads, Reddit Ads, AdRoll, Taboola, Plausible, Fathom, GoSquared, Simple Analytics, and Pirsch.

## Authentication

- **CLI:** `converly login` opens a browser sign-in, or `converly login --device` prints a code for headless and remote agents. The session token stays on the user's machine. In CI or anywhere a login isn't possible, set `CONVERLY_API_KEY` instead.
- **MCP:** sign in through the MCP client's own connection flow.
- **Ad platforms:** the account owner connects each one on the platform's own sign-in screen. Credentials are stored in an encrypted vault, separate from conversion data, and never pass through Converly's interface. An agent cannot connect an account itself; it hands the user a link.
- **API and SDK:** server-side keys start with `sk_live_`, and the SDK signs requests with a `webhookSecret`. Both belong in environment variables or a secret manager, never in the repo or the browser.

## CLI

### Install

```bash
npm install -g @converly/cli     # Node 20+, zero dependencies
converly login --device          # or `converly login` on a machine with a browser
```

### Setup

`converly status` returns an ordered checklist, with the next command or question for each step. Run it first and again after every step, and follow it over any memorised sequence.

```bash
converly status
converly sites update <site_id> --domain https://example.com       # conversions from other domains are rejected
converly install snippet <site_id>                                  # the user pastes this into <head> on every page
converly destinations connect google-ads --site <site_id>           # returns a link the account owner opens
converly handoffs wait <handoff_id>                                 # confirms the connection finished
converly triggers connect typeform --site <site_id>                 # only for iframe tools that need a connection
converly destinations conversions google-ads                        # pick the conversion action to fire
converly flows create --site <site_id> --name "Contact form" --trigger gravity-forms --destination google-ads --conversion-id <id>
converly flows validate <flow_id>                                   # lists blockers without changing anything
converly flows publish <flow_id>
```

Nothing is captured until the flow is published, the snippet is installed, and the site's domain is set. Then the user submits a real test and the agent confirms it in the log.

### Common commands

```bash
converly events list --status failed            # recent conversions, filterable by flow, email, status, date
converly events get <event_id>                  # per-destination result for one conversion, and why it failed
converly install status <site_id>               # has the snippet ever been seen on the site?
converly destinations list                      # which platforms are connected
converly triggers                               # supported source tools, and which need a connection
converly destinations types                     # supported destinations
```

`converly test-event` sends a real conversion to platforms with no sandbox, so it requires `--allow-real` and the user's approval. `converly flows delete` requires `--yes`.

Converly also maintains its own agent skill for the full setup: `npx skills add converlyio/converly-agent`.

## Common Agent Operations

### Set up tracking for a form

Run the setup sequence above. The steps only a person can do are signing in to each ad platform, pasting the snippet into the site, and submitting the real test form. Say up front that those three are coming.

### Check whether a lead reached the ad platforms

Given the lead's email, `converly events list --email lead@example.com` then `converly events get <event_id>` shows whether each destination accepted it, and if not, why. Contact details are only searchable for 7 days.

### Diagnose "nothing is tracking"

Check the three conditions first: `converly install status <site_id>` (is the snippet live), the site's domain in `converly status`, and whether the flow is published. Then `converly flows validate <flow_id>` for anything else blocking it.

### Report a conversion your backend confirms

Install `@converly/sdk-node` on the backend, mark the form or button that starts the conversion with `data-converly-signup-intent` so the browser half is captured, then call `completeSignup` once the conversion is real (for example, after email verification). The SDK pairs it with the visitor's click IDs.

## How it fits the skills

- Converly is one of the server-side options compared in `conversion-tracking` → `references/server-side.md`, alongside direct platform APIs, server-side GTM (self-hosted or through Stape), CDPs, CRM sync tools and Tracklution. That skill owns the choice between them; this guide covers using Converly once it's the fit.
- It's also one way to **implement** the server-side send described in `attribution` → `references/first-party-tracking.md`. The strategy (what to count, source of truth, how to read the numbers) still comes from `attribution` and `analytics`.
- After conversions flow, judge results with `ads` discipline: never sum conversions across attribution windows, and treat vendor lift figures as a hypothesis to verify with a holdout.

## Links

- Site: https://converly.io
- Integrations: https://converly.io/integrations
- Pricing: https://converly.io/pricing
- Platform docs: https://help.converly.io/platform
- Developer docs and API: https://developers.converly.io
- MCP: https://converly.io/mcp

## File: tools/integrations/coupler.md

# Coupler.io

Data integration platform that connects marketing, sales, analytics, and e-commerce data sources to destinations like spreadsheets, BI tools, and data warehouses with automated scheduling.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Importers, Runs, Sources, Destinations |
| MCP | ✓ | [Claude connector](https://claude.com/connectors/coupler-io) |
| CLI | ✓ | [coupler.js](../clis/coupler.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API at https://app.coupler.io

## Common Agent Operations

### List Importers

```bash
GET https://api.coupler.io/v1/importers
```

### Get Importer Details

```bash
GET https://api.coupler.io/v1/importers/{id}
```

### Trigger an Importer Run

```bash
POST https://api.coupler.io/v1/importers/{id}/run
```

### Create an Importer

```bash
POST https://api.coupler.io/v1/importers

{
  "source_type": "google_analytics",
  "destination_type": "google_sheets",
  "name": "GA4 to Sheets Daily"
}
```

### Delete an Importer

```bash
DELETE https://api.coupler.io/v1/importers/{id}
```

### List Runs for an Importer

```bash
GET https://api.coupler.io/v1/importers/{id}/runs
```

### Get Run Details

```bash
GET https://api.coupler.io/v1/runs/{id}
```

### List Available Sources

```bash
GET https://api.coupler.io/v1/sources
```

### List Available Destinations

```bash
GET https://api.coupler.io/v1/destinations
```

## Key Metrics

### Importer Data
- `id` - Importer ID
- `name` - Importer name
- `source_type` - Source connector type
- `destination_type` - Destination connector type
- `schedule` - Automation schedule
- `status` - Current status
- `last_run_at` - Last run timestamp

### Run Data
- `id` - Run ID
- `importer_id` - Parent importer
- `status` - Run status (pending, running, completed, failed)
- `started_at` - Start timestamp
- `finished_at` - Finish timestamp
- `rows_imported` - Number of rows processed
- `error` - Error message if failed

## Parameters

### Importer Creation
- `source_type` - Source connector (e.g., google_analytics, google_ads, facebook_ads, hubspot, shopify, stripe, airtable)
- `destination_type` - Destination connector (e.g., google_sheets, bigquery, snowflake, postgresql)
- `name` - Importer name
- `schedule` - Automation schedule (e.g., hourly, daily, weekly)

### Supported Sources
- **Analytics**: Google Analytics, Adobe Analytics
- **Ads**: Google Ads, Facebook Ads, LinkedIn Ads, TikTok Ads
- **CRM**: HubSpot, Salesforce, Pipedrive
- **E-commerce**: Shopify, Stripe, WooCommerce
- **Other**: Airtable, Google Sheets, BigQuery, MySQL, PostgreSQL

### Supported Destinations
- **Spreadsheets**: Google Sheets, Excel Online
- **BI Tools**: Looker Studio, Power BI, Tableau
- **Data Warehouses**: BigQuery, Snowflake, Redshift
- **Databases**: PostgreSQL, MySQL

## When to Use

- Automating marketing data pipelines from ads and analytics platforms
- Consolidating multi-channel campaign data into a single destination
- Scheduling recurring data syncs from CRM to spreadsheets or BI tools
- Building marketing dashboards with fresh data from multiple sources
- Exporting e-commerce data for reporting and analysis
- Connecting data sources without writing custom ETL code

## Rate Limits

- Rate limits vary by plan
- Standard: API access available on Professional and higher plans
- Importer run frequency depends on plan tier

## Relevant Skills

- analytics
- ads
- revops

## File: tools/integrations/crossbeam.md

# Crossbeam

Partner ecosystem platform (now part of Reveal) for sharing account data with partners to identify co-sell opportunities, overlapping customers, and partner-sourced pipeline.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Partners, Populations, Overlaps, Reports, Threads |
| MCP | ✓ | [Claude connector](https://claude.com/connectors/crossbeam) |
| CLI | ✓ | [crossbeam.js](../clis/crossbeam.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API at https://app.crossbeam.com

## Common Agent Operations

### List Partners

```bash
GET https://api.crossbeam.com/v1/partners
Authorization: Bearer {api_key}
```

### Get Partner Details

```bash
GET https://api.crossbeam.com/v1/partners/{id}
Authorization: Bearer {api_key}
```

### List Populations

```bash
GET https://api.crossbeam.com/v1/populations
Authorization: Bearer {api_key}
```

### List Overlaps

```bash
GET https://api.crossbeam.com/v1/overlaps/accounts?partner-id={partner_id}&population-ids[]={own_population_id}
Authorization: Bearer {api_key}
```

### Find a Source Record's Overlaps

```bash
GET https://api.crossbeam.com/v1/overlaps/accounts/search?record_id={source_record_id}
Authorization: Bearer {api_key}
```

The CLI defaults to partner account overlaps; `--type leads` selects partner
lead overlaps. The type describes the partner's records, not necessarily your
own source records. Use `overlaps list --population-id` for your own population
and `overlaps get --partner-population-id` for the partner's population filter.

`overlaps get --record-id` performs exact source-record matching and returns the
API's overlap search results. `--id` remains an alias for that source record ID;
it is not an overlap object's ID. List responses expose `pagination.next_cursor`
and `has_more`; pass the cursor with `--cursor` and continue until `has_more` is
false, even if a page is empty. The search endpoint is not paged.

See the [Crossbeam Partner API reference](https://developers.crossbeam.com/).

### Search Accounts

```bash
GET https://api.crossbeam.com/v1/accounts/search?domain={domain}
Authorization: Bearer {api_key}
```

### List Reports

```bash
GET https://api.crossbeam.com/v1/reports
Authorization: Bearer {api_key}
```

### List Collaboration Threads

```bash
GET https://api.crossbeam.com/v1/threads
Authorization: Bearer {api_key}
```

## Key Metrics

### Partner Data
- `id` - Partner ID
- `name` - Partner company name
- `status` - Partnership status (active, pending, etc.)
- `created_at` - When the partnership was established
- `populations_shared` - Number of shared populations

### Population Data
- `id` - Population ID
- `name` - Population name (e.g., "Customers", "Open Opportunities")
- `record_count` - Number of records in population
- `partner_visibility` - What partners can see

### Overlap Data
- `id` - Overlap ID
- `partner_id` - Partner involved
- `population_id` - Population matched
- `account_name` - Overlapping account name
- `overlap_type` - Type of overlap (customer, prospect, etc.)
- `match_confidence` - Match confidence score

### Report Data
- `id` - Report ID
- `name` - Report name
- `type` - Report type
- `created_at` - Creation date
- `results` - Report results data

## Parameters

### Overlaps List
- `partner_id` - Filter by specific partner
- `population_id` - Filter by specific population

### Accounts Search
- `domain` - Company domain to search for

## When to Use

- Identifying co-sell opportunities with channel partners
- Finding overlapping customers and prospects across partner ecosystems
- Building partner-sourced pipeline by matching accounts
- Tracking partner influence on deals
- Creating account mapping reports for partner meetings
- Prioritizing which partners to engage based on overlap data

## Rate Limits

- Rate limits vary by plan
- Standard: 100 requests/minute
- Pagination supported on list endpoints

## Relevant Skills

- revops
- sales-enablement
- referrals
- competitors

## File: tools/integrations/customer-io.md

# Customer.io

Behavior-based messaging platform for email, push, SMS, and in-app.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Track API, App API, Journeys API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | JavaScript, iOS, Android, Ruby, Python |

## Authentication

- **Track API**: Site ID + API Key (Basic auth)
- **App API**: Bearer token
- **Header**: `Authorization: Basic {base64(site_id:api_key)}`

## Common Agent Operations

### Identify customer

```bash
PUT https://track.customer.io/api/v1/customers/{customer_id}

Authorization: Basic {base64(site_id:api_key)}

{
  "email": "user@example.com",
  "created_at": 1705312800,
  "first_name": "John",
  "plan": "pro"
}
```

### Track event

```bash
POST https://track.customer.io/api/v1/customers/{customer_id}/events

Authorization: Basic {base64(site_id:api_key)}

{
  "name": "purchase",
  "data": {
    "product": "Pro Plan",
    "amount": 99
  }
}
```

### Track anonymous event

```bash
POST https://track.customer.io/api/v1/events

Authorization: Basic {base64(site_id:api_key)}

{
  "name": "page_viewed",
  "data": {
    "page": "/pricing"
  },
  "anonymous_id": "anon_123"
}
```

### Delete customer

```bash
DELETE https://track.customer.io/api/v1/customers/{customer_id}

Authorization: Basic {base64(site_id:api_key)}
```

### Get customer (App API)

```bash
GET https://api.customer.io/v1/customers/{customer_id}/attributes

Authorization: Bearer {app_api_key}
```

### List campaigns

```bash
GET https://api.customer.io/v1/campaigns

Authorization: Bearer {app_api_key}
```

### Get campaign metrics

```bash
GET https://api.customer.io/v1/campaigns/{campaign_id}/metrics

Authorization: Bearer {app_api_key}
```

### Trigger broadcast

```bash
POST https://api.customer.io/v1/campaigns/{campaign_id}/triggers

Authorization: Bearer {app_api_key}

{
  "emails": ["user@example.com"],
  "data": {
    "coupon_code": "SAVE20"
  }
}
```

### Send transactional email

```bash
POST https://api.customer.io/v1/send/email

Authorization: Bearer {app_api_key}

{
  "transactional_message_id": "1",
  "to": "user@example.com",
  "identifiers": {
    "id": "user_123"
  },
  "message_data": {
    "order_id": "ORD-456"
  }
}
```

## JavaScript SDK

```javascript
// Initialize
_cio.identify({
  id: 'user_123',
  email: 'user@example.com',
  created_at: 1705312800,
  plan: 'pro'
});

// Track event
_cio.track('purchase', {
  product: 'Pro Plan',
  amount: 99
});

// Track page view
_cio.page();
```

## Key Concepts

- **People** - Customers and leads
- **Segments** - Dynamic groups based on attributes/behavior
- **Campaigns** - Automated message sequences
- **Broadcasts** - One-time sends
- **Transactional** - Triggered messages

## Attribute Types

- Standard: `email`, `created_at`, `unsubscribed`
- Custom: Any key you define
- Computed: Aggregations from events

## When to Use

- Behavior-based email automation
- Multi-channel messaging (email, push, SMS)
- Onboarding sequences
- Re-engagement campaigns
- Transactional messages

## Rate Limits

- Track API: 100 requests/second
- App API: 10 requests/second

## Relevant Skills

- emails
- onboarding
- analytics

## CLI account region

Set `CUSTOMERIO_REGION=eu` for a workspace hosted in Customer.io's EU region.
The CLI then uses `track-eu.customer.io` for Track operations and
`api-eu.customer.io` for App operations. Both request previews and actual
requests use the selected region, retaining their existing Basic/Bearer
authentication and request bodies.

```bash
export CUSTOMERIO_REGION=eu
node tools/clis/customer-io.js customers get --id owned-customer-id --dry-run
```

The default is `us`; `CUSTOMERIO_REGION=us` explicitly retains the existing
US hosts. Other values are rejected before requests. Check the workspace's
region rather than guessing it from an email address or the user's location.
This selects documented provider endpoints; it does not migrate a workspace
or guarantee how the provider stores/processes data. Select scoped credentials
for that workspace, and perform writes only when already authorized.

Customer.io notes that sending EU Track requests to its US host can redirect
but still pass through US servers. Use the regional host directly.
See the official [Track server regions](https://docs.customer.io/integrations/api/track/#server-addresses-us-and-eu)
and [App server regions](https://docs.customer.io/integrations/api/app/#server-addresses-us-and-eu).

## Suppression lifecycle

For an explicit erasure/suppression request, `customers suppress` invokes the
Track API operation that permanently deletes the profile and blocks its
identifier from being re-added. This is different from the existing
`customers delete` operation. Preview the request first:

```bash
node tools/clis/customer-io.js customers suppress --id customer-123 --dry-run
node tools/clis/customer-io.js customers unsuppress --id customer-123 --dry-run
```

Both commands require the Track API Site ID and API key. Unsuppressing only
releases the identifier; it does not recreate the deleted profile or restore
history. For ordinary message preferences while keeping a profile, update its
`unsubscribed` attribute instead. Use the operation appropriate to the person's
request and your workspace identifier configuration. See the official
[suppress](https://docs.customer.io/integrations/api/track/tag/track-customers/suppress/)
and [unsuppress](https://docs.customer.io/integrations/api/track/tag/track-customers/unsuppress/)
contracts. Neither operation is a substitute for handling data in other systems.

## File: tools/integrations/dataforseo.md

# DataForSEO

Comprehensive SEO data API for SERP results, keyword research, backlinks, and on-page analysis.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | SERP, Keywords Data, Backlinks, On-Page, Labs |
| MCP | - | Not available |
| CLI | ✓ | [dataforseo.js](../clis/dataforseo.js) |
| SDK | ✓ | Python, TypeScript, PHP, Java, C# |

## Authentication

- **Type**: Basic Auth
- **Header**: `Authorization: Basic {base64(login:password)}`
- **Get credentials**: API Access tab at https://app.dataforseo.com/api-access
- **Note**: API password is auto-generated, different from account password

## Common Agent Operations

### SERP - Google organic (live)

```bash
POST https://api.dataforseo.com/v3/serp/google/organic/live/regular

[{
  "keyword": "marketing automation",
  "location_name": "United States",
  "language_name": "English"
}]
```

### Keywords - Search volume (live)

```bash
POST https://api.dataforseo.com/v3/keywords_data/google_ads/search_volume/live

[{
  "keywords": ["email marketing", "marketing automation", "crm software"],
  "location_code": 2840,
  "language_code": "en"
}]
```

### Keywords - Keywords for site (live)

```bash
POST https://api.dataforseo.com/v3/keywords_data/google_ads/keywords_for_site/live

[{
  "target": "example.com",
  "location_code": 2840,
  "language_code": "en"
}]
```

### Backlinks - Summary

```bash
POST https://api.dataforseo.com/v3/backlinks/summary/live

[{
  "target": "example.com",
  "internal_list_limit": 10,
  "backlinks_status_type": "live"
}]
```

### Backlinks - List

```bash
POST https://api.dataforseo.com/v3/backlinks/backlinks/live

[{
  "target": "example.com",
  "mode": "as_is",
  "limit": 100,
  "backlinks_status_type": "live"
}]
```

### Backlinks - Referring domains

```bash
POST https://api.dataforseo.com/v3/backlinks/referring_domains/live

[{
  "target": "example.com",
  "limit": 100
}]
```

### Backlinks - Index (database stats)

```bash
GET https://api.dataforseo.com/v3/backlinks/index
```

### On-Page - Instant pages audit

```bash
POST https://api.dataforseo.com/v3/on_page/instant_pages

[{
  "url": "https://example.com/page",
  "enable_javascript": true
}]
```

### SERP - Locations list

```bash
GET https://api.dataforseo.com/v3/serp/google/locations
```

### SERP - Languages list

```bash
GET https://api.dataforseo.com/v3/serp/google/languages
```

## API Pattern

DataForSEO uses two methods for most endpoints:
- **Live** (`/live`) - Synchronous, results in same response
- **Task-based** (`/task_post` + `/task_get/$id`) - Async for large requests

Request bodies are always JSON arrays (even for single requests).

## Key Metrics

### Keyword Metrics
- `search_volume` - Monthly search volume
- `competition` - Competition level (0-1)
- `cpc` - Cost per click
- `monthly_searches` - Monthly breakdown array

### Backlink Metrics
- `total_backlinks` - Total backlink count
- `referring_domains` - Unique referring domains
- `domain_rank` - Domain authority score
- `backlinks_spam_score` - Spam score

## When to Use

- Programmatic SERP tracking at scale
- Keyword research with search volume data
- Backlink analysis and monitoring
- On-page SEO audits
- Competitor analysis

## Rate Limits

- Rate limit headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`
- Backlinks API: 2000 requests/minute, 30 simultaneous
- Varies by endpoint and plan

## Relevant Skills

- seo-audit
- programmatic-seo
- content-strategy
- competitors

### CLI market selection

For `serp google`, `--location-code` and `--language-code` select API codes
instead of location/language names. Explicit codes take precedence over name
flags; omitted flags retain United States and English. Preview the paid request
with `--dry-run`:

```bash
node tools/clis/dataforseo.js serp google --keyword chaussures \
  --location-code 2250 --language-code fr --dry-run
```

## File: tools/integrations/demio.md

# Demio

Webinar platform for hosting live, automated, and on-demand webinars with built-in registration and attendee tracking.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Events, Registration, Participants, Sessions |
| MCP | - | Not available |
| CLI | ✓ | [demio.js](../clis/demio.js) |
| SDK | ✓ | PHP (official), Ruby (community) |

## Authentication

- **Type**: API Key + API Secret
- **Headers**: `Api-Key: {key}` and `Api-Secret: {secret}`
- **Get credentials**: Account Settings > API (Owner access required)
- **Docs**: https://publicdemioapi.docs.apiary.io/

## Common Agent Operations

### Ping (health check)

```bash
GET https://my.demio.com/api/v1/ping

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

### List all events

```bash
GET https://my.demio.com/api/v1/events

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

### List events by type

```bash
GET https://my.demio.com/api/v1/events?type=upcoming

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

### Get a specific event

```bash
GET https://my.demio.com/api/v1/event/{event_id}

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

### Get event date details

```bash
GET https://my.demio.com/api/v1/event/{event_id}/date/{date_id}

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

### Register attendee for event

```bash
POST https://my.demio.com/api/v1/event/register

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
  Content-Type: application/json

{
  "id": 12345,
  "name": "Jane Doe",
  "email": "jane@example.com"
}
```

### Register attendee for specific date

```bash
POST https://my.demio.com/api/v1/event/register

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
  Content-Type: application/json

{
  "id": 12345,
  "date_id": 67890,
  "name": "Jane Doe",
  "email": "jane@example.com"
}
```

### Get participants for event date

```bash
GET https://my.demio.com/api/v1/report/{date_id}/participants

Headers:
  Api-Key: {API_KEY}
  Api-Secret: {API_SECRET}
```

## API Pattern

Participant reports use the `/report/{date_id}/participants` resource;
event-date details use `/event/{event_id}/date/{date_id}`. See the
[public Demio API reference](https://api-docs.demio.com/).

Demio uses a straightforward REST API:
- All requests require both `Api-Key` and `Api-Secret` headers
- Responses are JSON objects
- Registration returns a `join_link` URL for the attendee
- Events have multiple "dates" (sessions), each with a unique `date_id`

## Key Metrics

### Event Metrics
- `id` - Event ID
- `name` - Event name
- `date_id` - Session/date identifier
- `status` - Event status (upcoming, past, active)
- `type` - Event type (live, automated, on-demand)
- `registration_url` - Public registration page URL

### Participant Metrics
- `name` - Participant name
- `email` - Participant email
- `status` - Attendance status (registered, attended, missed)
- `attended_minutes` - Duration of attendance
- `join_link` - Unique join URL for the participant

## Parameters

### Event List Filters
- `type` - Filter by event type: `upcoming`, `past`, `all`

### Registration Fields
- `id` - Event ID (required)
- `name` - Registrant name (required)
- `email` - Registrant email (required)
- `date_id` - Specific session date ID (optional)
- `ref_url` - Referral URL for tracking (optional)

### Custom Fields
- Custom fields are supported via their UID (not display name)
- Check your event settings for available custom field UIDs

## When to Use

- Automating webinar registration from landing pages or forms
- Syncing webinar attendee data with CRM
- Building custom registration flows for webinars
- Tracking webinar attendance and engagement
- Triggering follow-up sequences based on attendance status
- Managing multiple webinar sessions programmatically

## Rate Limits

- **180 requests per minute** (3 per second)
- **Free Trial**: 100 API calls per day
- **Paid Plans**: 5,000 API calls per day (reset at 00:00 UTC)
- Contact Demio to request higher daily limits
- Exceeding limits returns an error response

## Relevant Skills

- webinar-marketing
- lead-generation
- event-marketing
- content-strategy
- lifecycle-marketing

## File: tools/integrations/dub-co.md

# Dub.co

Link management and attribution platform for modern marketing teams.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for links, analytics, domains |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | TypeScript SDK available |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API Keys in Dub dashboard

## Common Agent Operations

### Create short link

```bash
POST https://api.dub.co/links

{
  "url": "https://example.com/landing-page",
  "domain": "link.example.com",
  "key": "summer-sale",
  "tagNames": ["campaign:summer", "channel:email"]
}
```

### Get link by key

```bash
GET https://api.dub.co/links?domain=link.example.com&key=summer-sale
```

### List links

```bash
GET https://api.dub.co/links?domain=link.example.com&page=1
```

### Get link analytics

```bash
GET https://api.dub.co/analytics?domain=link.example.com&key=summer-sale&interval=30d
```

### Get clicks by location

```bash
GET https://api.dub.co/analytics?groupBy=countries&domain=link.example.com&key=summer-sale
```

### Get clicks by device

```bash
GET https://api.dub.co/analytics?groupBy=devices&domain=link.example.com&key=summer-sale
```

### Update link

```bash
PATCH https://api.dub.co/links/{link_id}

{
  "url": "https://example.com/new-landing-page",
  "tagNames": ["campaign:summer", "channel:social"]
}
```

For [link creation](https://dub.co/docs/api-reference/links/create) and
[updates](https://dub.co/docs/api-reference/links/update), use `tagNames` for names
or `tagIds` for existing tag IDs. The CLI's `--tags` flag takes comma-separated
names and sends `tagNames`. The response's `tags` field contains tag objects.

### Delete link

```bash
DELETE https://api.dub.co/links/{link_id}
```

### Bulk create links

```bash
POST https://api.dub.co/links/bulk

[
  {"url": "https://example.com/page1", "key": "page1"},
  {"url": "https://example.com/page2", "key": "page2"}
]
```

The country and device breakdowns use the `groupBy` query parameter on
[`GET /analytics`](https://dub.co/docs/api-reference/analytics/retrieve).
The CLI accepts `--interval` for each analytics subcommand.

## TypeScript SDK

### Install

```bash
npm install dub
```

### Usage

```typescript
import { Dub } from "dub";

const dub = new Dub({ token: "YOUR_API_KEY" });

// Create link
const link = await dub.links.create({
  url: "https://example.com",
  domain: "link.example.com"
});

// Get analytics
const analytics = await dub.analytics.retrieve({
  domain: "link.example.com",
  key: "summer-sale"
});
```

## Key Features

- **Custom domains** - Use your own branded domains
- **Link analytics** - Clicks, locations, devices, referrers
- **Tags** - Organize links by campaign, channel, etc.
- **QR codes** - Auto-generated for each link
- **Password protection** - Secure sensitive links
- **Expiration** - Time-limited links
- **Geo-targeting** - Redirect based on location

## Analytics Dimensions

- `clicks` - Total click count
- `country` - Clicks by country
- `city` - Clicks by city
- `device` - Clicks by device type
- `browser` - Clicks by browser
- `os` - Clicks by operating system
- `referer` - Clicks by referrer

## When to Use

- Creating trackable marketing links
- Building referral link systems
- Tracking campaign attribution
- A/B testing landing pages via links
- Generating branded short URLs
- Analyzing link performance

## Rate Limits

- Free: 1,000 links, 5 API requests/second
- Pro: Unlimited links, 50 API requests/second
- Enterprise: Custom limits

## Relevant Skills

- referrals
- analytics
- ads

## File: tools/integrations/exa.md

# Exa

AI-powered web search API built for LLMs and agents. Returns high-quality search results with neural and keyword matching, plus on-demand content retrieval (full text, highlights, and summaries) in a single request.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Search, Find Similar, Contents |
| MCP | ✓ | Official hosted server at `https://mcp.exa.ai/mcp`; works anonymously with rate limits, OAuth or API key for higher limits ([docs](https://exa.ai/docs/get-started/exa-mcp)) |
| CLI | ✓ | [exa.js](../clis/exa.js) |
| SDK | ✓ | `exa-py` (Python), `exa-js` (TypeScript) |

## Authentication

- **Type**: API Key
- **Header**: `x-api-key: {key}`
- **Get key**: https://dashboard.exa.ai

## Endpoints

Base URL: `https://api.exa.ai`

| Endpoint | Purpose |
|----------|---------|
| `POST /search` | Search the web with neural, keyword-like, or auto-routed modes |
| `POST /findSimilar` | Find pages similar to a given URL |
| `POST /contents` | Fetch text, highlights, or summaries for one or more URLs |

## Common Agent Operations

### Web Search with Content

```bash
POST https://api.exa.ai/search
{
  "query": "best B2B SaaS onboarding flows",
  "type": "auto",
  "numResults": 10,
  "contents": {
    "text": { "maxCharacters": 1000 },
    "highlights": true
  }
}
```

### Structured research output

[Exa Search](https://exa.ai/docs/reference/search) can synthesize a structured answer alongside search results and field-level grounding. Pass a JSON schema with root type `object` or `text`; the response's `output.content`, `output.grounding`, request ID and cost estimate are returned unchanged.

```bash
node tools/clis/exa.js search --query "newsletter platforms for small publishers" --type deep --output-schema '{"type":"object","properties":{"vendors":{"type":"array","items":{"type":"string"}}},"required":["vendors"]}' --objective "Compare vendors for a small publisher" --system-prompt "Use primary sources and identify missing evidence" --additional-queries '["newsletter pricing","newsletter deliverability"]' --highlights
```

`--additional-queries` takes a JSON array of one to ten nonempty query strings and requires `deep-lite`, `deep` or `deep-reasoning`. `--objective` describes the research goal (at most 4096 characters); `--system-prompt` supplies synthesis instructions. Ordinary search filters and content options still apply. Omit these flags to retain the existing request.

The CLI validates JSON shape and supported root types; Exa validates the full schema, including its object property, nesting and array-item limits. This request is non-streaming, performs one search, and does not retry or invent citations. Inspect grounding and original sources before relying on generated content. Structured synthesis adds provider latency and can affect costs; the response estimate is not a billing guarantee. Preview with `--dry-run` before a paid request.

### Competitor Content Discovery

```bash
POST https://api.exa.ai/search
{
  "query": "landing page teardowns",
  "includeDomains": ["goodui.org", "growth.design", "marketingexamples.com"],
  "startPublishedDate": "2024-01-01T00:00:00Z",
  "contents": { "highlights": true }
}
```

### Find Similar Pages

```bash
POST https://api.exa.ai/findSimilar
{
  "url": "https://stripe.com/pricing",
  "numResults": 20,
  "contents": { "summary": { "query": "What pricing model and price points does this page use?" } }
}
```

### Category-Filtered Search

```bash
POST https://api.exa.ai/search
{
  "query": "DTC beauty brand raising Series A",
  "category": "news",
  "numResults": 25,
  "startPublishedDate": "2024-06-01T00:00:00Z"
}
```

### Fetch Contents for Known URLs

```bash
POST https://api.exa.ai/contents
{
  "urls": ["https://example.com/post-1", "https://example.com/post-2"],
  "text": true,
  "summary": { "query": "Summarize this article's key argument in one paragraph." }
}
```

## Key Parameters

### Search Types
- `auto` - Automatically routes between neural and keyword matching (default)
- `neural` - Embedding-based semantic search; best for concept/idea queries
- `fast` - Lower-latency neural search
- `instant` - Returns cached results near-instantly
- `deep-lite`, `deep`, `deep-reasoning` - Agentic search variants that plan multiple queries and synthesize

### Categories
`company`, `research paper`, `news`, `personal site`, `financial report`, `people`

### Filtering
- `includeDomains` / `excludeDomains` - Restrict to or exclude specific domains (up to 1200)
- `includeText` / `excludeText` - Require or forbid phrases in result pages
- `startPublishedDate` / `endPublishedDate` - ISO 8601 publication date range
- `startCrawlDate` / `endCrawlDate` - ISO 8601 crawl date range
- `userLocation` - Two-letter country code (e.g., `US`)

### Contents (Mix and Match)
All three can be requested in the same call:
- `text: true` or `{ maxCharacters, includeHtmlTags, verbosity }` - Full or truncated page text
- `highlights: true` or `{ query, maxCharacters }` - LLM-selected relevant snippets
- `summary: { query, schema }` - LLM-generated summary, optionally conforming to a JSON schema

## When to Use

- **Content research** - Find high-quality long-form content on niche topics by meaning, not just keywords
- **Competitor discovery** - Find companies similar to one you've identified via `findSimilar`
- **SEO content gap analysis** - Search for topics your competitors rank for and pull highlights for quick review
- **Customer research** - Find forum threads, blog posts, and reviews about your product or category
- **Audience research** - Discover blogs, newsletters, and communities where your ICP publishes or comments
- **News monitoring** - Track mentions of your brand, competitors, or category with date-filtered news search
- **Link prospecting** - Find authoritative pages covering topics you write about, for outreach
- **Lead research** - Use the `company` and `people` categories to discover accounts or individuals matching criteria

## Rate Limits

- Varies by plan; see https://exa.ai/pricing
- Most production plans support hundreds of concurrent requests
- Content retrieval (text/highlights/summary) is billed separately from the base search

## Relevant Skills

- seo-audit
- ai-seo
- content-strategy
- competitor-profiling
- competitor-alternatives
- customer-research
- cold-email
- lead-magnets
- marketing-ideas

### Answers with source citations

Use `answer` when you need a provider-generated answer alongside the web sources it used. The CLI returns the complete JSON response, preserving `citations`, `requestId` and provider cost metadata instead of flattening the answer into unsourced text. The output remains model-generated; check cited pages before using its claims.

```bash
node tools/clis/exa.js answer --query "What changed in our market this quarter?" --model exa-pro
node tools/clis/exa.js answer "Research the category" --output-schema '{"type":"object","properties":{"summary":{"type":"string"}}}' --dry-run
```

`--system-prompt` supplies additional generation instructions. `--text` (or `--text true`) requests full source text; `--text false` explicitly disables it. `--output-schema` accepts a JSON object, forwarded as `outputSchema`; schema validity beyond this shape is provider-validated. Answers use one non-streaming POST to `/answer`, may consume credits and are never automatically retried. Omitted options retain provider defaults. Model availability depends on the account/API.

See [Exa’s answer contract](https://exa.ai/docs/reference/answer). Contract tests use fake credentials and local response fixtures; they do not establish authenticated provider acceptance or live answer quality.

## File: tools/integrations/firecrawl.md

# Firecrawl

Web scraping API that turns single pages or full sites into clean LLM-ready markdown. Handles JS rendering, anti-bot defenses, and proxy rotation so you can extract structured data from individual public business sites.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API + Python/Node SDKs |
| MCP | ✓ | Official hosted server: `https://mcp.firecrawl.dev/v2/mcp` with a Bearer API key (unattended), `/v2/mcp-oauth` for OAuth; a keyless tier covers scrape, search, and parse ([docs](https://docs.firecrawl.dev/mcp-server)) |
| CLI | ✓ | [firecrawl.js](../clis/firecrawl.js) |
| SDK | ✓ | Node, Python, Go, Rust |

Full API reference: https://docs.firecrawl.dev

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer fc-YOUR_API_KEY`
- **Get key**: https://www.firecrawl.dev/app/api-keys
- **Env var**: `FIRECRAWL_API_KEY`
- **Base URL**: `https://api.firecrawl.dev`

## Core Operations

### Scrape a single page

```bash
POST https://api.firecrawl.dev/v2/scrape
Authorization: Bearer fc-YOUR_API_KEY

{
  "url": "https://joescoffeeshop.com",
  "formats": ["markdown", "html"]
}
```

Returns the page as clean markdown (LLM-ready, no nav cruft) plus optional raw HTML.

### Map a site (discover all URLs)

```bash
POST https://api.firecrawl.dev/v2/map

{
  "url": "https://example.com",
  "limit": 100
}
```

Returns a list of URLs found on the site. Use this to identify key pages (`/pricing`, `/about`, `/contact`, `/team`) before scraping individually.

### Crawl multiple pages

```bash
POST https://api.firecrawl.dev/v2/crawl

{
  "url": "https://example.com",
  "limit": 20,
  "scrapeOptions": {
    "formats": ["markdown"]
  }
}
```

Crawls multiple pages from a single site. **Use sparingly** — costs scale with pages. Set `limit` and `includePaths` to target specific URL patterns.

### Structured data (scrape JSON mode)

```bash
POST https://api.firecrawl.dev/v2/scrape

{
  "url": "https://joescoffeeshop.com",
  "formats": [{
    "type": "json",
    "prompt": "Extract the business contact details",
    "schema": {
      "type": "object",
      "properties": {
        "phone": { "type": "string" },
        "address": { "type": "string" },
        "hours": { "type": "string" },
        "email": { "type": "string" }
      }
    }
  }]
}
```

Returns structured data under `data.json` matching the schema — useful when you want consistent fields across many sites rather than raw markdown.

### Search the web

```bash
POST https://api.firecrawl.dev/v2/search

{
  "query": "\"Joe's Coffee Shop\" Boulder Colorado",
  "limit": 10
}
```

Web search useful for cross-source verification (find a business's official site when you only have a name + location). v2 groups results by source under `data.web` / `data.news` / `data.images`; add `scrapeOptions` to also pull page content for each result (billed separately).

## MCP Tools (when used via MCP server)

| Tool | Purpose |
|------|---------|
| `firecrawl_scrape` | Single-page extraction |
| `firecrawl_map` | URL discovery on a site |
| `firecrawl_crawl` | Multi-page crawl |
| `firecrawl_search` | Web search + scrape |

## CLI

A zero-dependency Node CLI ships in [`tools/clis/firecrawl.js`](../clis/firecrawl.js). Set `FIRECRAWL_API_KEY` and run any of `scrape`, `search`, `map`, `crawl`, or `crawl-status`. Output is JSON on stdout (pipe to `jq`); add `--dry-run` to preview a request without sending it.

```bash
# Scrape a single business site to markdown
node tools/clis/firecrawl.js scrape --url https://joescoffeeshop.com

# Find a business's official site
node tools/clis/firecrawl.js search "\"Joe's Coffee Shop\" Boulder Colorado" --limit 5

# Discover a site's key pages before scraping
node tools/clis/firecrawl.js map --url https://example.com --search pricing

# Crawl a section, then poll the async job
node tools/clis/firecrawl.js crawl --url https://example.com --limit 20 --include-paths /pricing,/about
node tools/clis/firecrawl.js crawl-status --id <crawlId>
```

## When to Use

- **Local SMB prospecting**: verify a business's website status (live, weak, missing) at the URL level after manual Maps/Yelp discovery
- **Single-target enrichment**: pull contact info, hours, services from a business's own site
- **Competitor research**: scrape competitor pricing, features, customer pages (this is the primary use in `competitor-profiling` skill)
- **Programmatic page extraction**: when you need many sites' homepages or about pages in a consistent format
- **JS-heavy sites**: when the page won't render with a simple `curl` because content loads after page load

## When NOT to Use

**Critical — do not use Firecrawl to scrape platforms hosting prospects:**

- ✗ **Google Maps / Google search results** — Google ToS prohibits bulk extraction
- ✗ **LinkedIn** — explicit ToS violation, will get scraper accounts banned and risks legal exposure
- ✗ **Yelp** — ToS prohibits commercial scraping
- ✗ **Apollo / ZoomInfo / Clearbit listings** — their ToS prohibits using competing data extracts
- ✗ **Any platform you don't have a legitimate basis to extract from at scale**

**Use Firecrawl for**: the *business's own website* (which you found via manual discovery on those platforms). That's the line — discovery happens on platforms, extraction happens on individual public business sites.

## Pricing

- Free tier: limited monthly credits
- Paid tiers scale by request volume + concurrency
- Confirm at https://www.firecrawl.dev/pricing

## Rate Limits

- Default: tier-dependent (typically 5–20 concurrent requests on paid plans)
- Per-page cost varies by content type and rendering needs

## Relevant Skills

- prospecting (site enrichment for individual business URLs)
- competitor-profiling (primary use: full-site competitor analysis)
- ai-seo (scrape your own content for AI search optimization)
- content-strategy (scrape industry sites for content gap analysis)

## Inspecting asynchronous crawl results in the CLI

`crawl` starts a job and returns its ID. `crawl-status` retrieves a single result
page; it does not wait for completion or fetch every page automatically:

```bash
node tools/clis/firecrawl.js crawl-status --id <crawlId>
# If the returned next URL ends in ?skip=26, request that next result page:
node tools/clis/firecrawl.js crawl-status --id <crawlId> --skip 26
node tools/clis/firecrawl.js crawl-errors --id <crawlId>
```

Read the returned `next` URL and use its `skip` value unchanged for the same job.
Do not invent the offset from `completed` or increment it by a guessed page size.
A `completed` status can still have more result pages: Firecrawl uses pagination
for responses over 10MB. Follow returned pages until `next` is absent or null.
If the job is still `scraping`, a currently empty page does not establish that
there will be no more results; check status again later using your existing
workflow. `--dry-run` previews either read request with authorization masked.

Job completion does not prove every discovered URL was successfully scraped.
Inspect `crawl-errors` for failed scrapes and `robotsBlocked`, and inspect each
returned page's `metadata.statusCode` for target-site HTTP failures. Firecrawl's
error endpoint may omit some internal failure classes, so an empty error list is
not a guarantee of complete coverage. Keep the result page, job status and error
output together when reporting crawl coverage.

See [crawl response handling](https://docs.firecrawl.dev/features/crawl#response-handling)
and [crawl error reporting](https://docs.firecrawl.dev/api-reference/endpoint/crawl-get-errors)
for the current provider contracts.

## File: tools/integrations/firehose.md

# Firehose

Real-time web data streaming API that monitors web pages and delivers matching content instantly via server-sent events (SSE). Built for competitive intelligence, brand monitoring, and news tracking without polling.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | RESTful endpoints for managing rules + SSE for streaming |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | Native AI agent skill available |

## Authentication

- **Type**: API Key
- **Currently**: Free beta — no credit card required
- **Get access**: Sign up at firehose.com

## Core Concepts

**Rules** — Filters that define what content to match. Uses Lucene query syntax.

**Stream** — A server-sent event (SSE) connection that delivers matching content in real-time as it's published on the web.

Instead of polling an endpoint on a schedule, you define rules once and receive a continuous stream of matches as they happen.

## Query Syntax (Lucene)

```
# Exact phrase
"your brand name"

# Field-specific
title:tesla
domain:reuters.com
domain:techcrunch.com

# Boolean operators
"Series A" AND (SaaS OR software)
competitor OR "competitor name" NOT "your company"

# Wildcard
market* AND funding

# Language filter
language:en

# Date range
publish_time:[2026-01-01 TO 2026-03-18]

# ML-classified categories
category:finance
category:technology
```

## Common Agent Operations

### Create a monitoring rule

```bash
POST https://api.firehose.com/rules

{
  "query": "\"your brand name\" OR \"your product name\"",
  "label": "brand-mentions"
}
```

### List active rules

```bash
GET https://api.firehose.com/rules
```

### Delete a rule

```bash
DELETE https://api.firehose.com/rules/{rule_id}
```

### Connect to the stream

```bash
GET https://api.firehose.com/stream
Authorization: Bearer {api_key}

# Returns server-sent events:
# data: {"url": "...", "title": "...", "publish_time": "...", "matched_rule": "..."}
```

### Example: Node.js stream consumer

```javascript
import EventSource from 'eventsource';

const stream = new EventSource('https://api.firehose.com/stream', {
  headers: { Authorization: `Bearer ${process.env.FIREHOSE_API_KEY}` }
});

stream.onmessage = (event) => {
  const item = JSON.parse(event.data);
  console.log(`[${item.matched_rule}] ${item.title} — ${item.url}`);
};
```

## Use Cases for Marketing

### Competitive intelligence
Monitor competitors' press coverage, product announcements, and funding news in real-time.

```
query: "CompetitorName" AND (launch OR funding OR "product update" OR partnership)
```

### Brand monitoring
Track mentions of your brand across news and web content.

```
query: "YourBrand" OR "YourProductName" NOT site:yourdomain.com
```

### Category / market news
Stay current on your market without manually checking sources.

```
query: category:technology AND ("no-code" OR "low-code") AND funding
domain:techcrunch.com OR domain:venturebeat.com
```

### Lead trigger monitoring
Track signals that indicate a prospect is ready to buy (hiring, funding, tool mentions).

```
query: ("hiring" OR "we're growing") AND "RevOps" AND (HubSpot OR Salesforce)
```

### PR and link building
Get alerted when publications cover topics in your space, enabling timely outreach.

```
query: "best [category] tools" OR "top [category] software" AND publish_time:[now-7d TO now]
```

## When to Use

- Real-time competitive intelligence (faster than Google Alerts)
- Brand mention monitoring across news and web
- Market signal tracking for sales prospecting
- Automated content curation pipelines
- Trigger-based workflows (new mention → Slack alert, CRM update, etc.)

## Relevant Skills

- competitors
- customer-research
- content-strategy
- cold-email
- marketing-ideas

## File: tools/integrations/fullenrich.md

# FullEnrich

Waterfall contact enrichment: queries many data providers in sequence to find work emails, personal emails, and mobile numbers for a person, then verifies the emails it returns. Also offers people and company search, single lookups, and reverse email lookup.

Facts below were checked against [docs.fullenrich.com](https://docs.fullenrich.com/api/v2/general/introduction) (API v2 spec) and the [MCP help article](https://help.fullenrich.com/en/articles/14190120-mcp-server) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2: bulk enrich, reverse email, people/company search and lookup, credits |
| MCP | ✓ | Official hosted server at `https://mcp.fullenrich.com/mcp`, OAuth sign-in (search, enrich, export) |
| CLI | - | Use the API |
| SDK | - | Native Zapier, Make, Clay, and n8n integrations |

## Authentication

- **Type**: Bearer token, `Authorization: Bearer <key>`
- **Env var** (convention): `FULLENRICH_API_KEY`
- **Get key**: [app.fullenrich.com/app/api](https://app.fullenrich.com/app/api)
- **MCP**: OAuth browser sign-in, so it suits interactive sessions. Scheduled jobs should use the API key.

## Common Agent Operations

Base URL: `https://app.fullenrich.com/api/v2`

### Enrich contacts (asynchronous, up to 100 per request)

```bash
POST https://app.fullenrich.com/api/v2/contact/enrich/bulk
Authorization: Bearer $FULLENRICH_API_KEY

{
  "name": "Q4 CRO targets",
  "webhook_url": "https://example.com/fullenrich-done",
  "data": [
    {
      "first_name": "Jane",
      "last_name": "Doe",
      "domain": "acme.com",
      "company_name": "Acme",
      "professional_network_url": "https://www.linkedin.com/in/janedoe/",
      "enrich_fields": ["contact.work_emails"],
      "custom": { "crm_id": "12584" }
    }
  ]
}
```

- The response returns an enrichment ID right away; results arrive later by webhook (recommended) or `GET /contact/enrich/bulk/{enrichment_id}`.
- `webhook_events.contact_finished` posts each contact as it completes, instead of waiting for the whole batch.
- Ask only for the fields you need. Phones cost 10 credits each, so request `contact.phones` only for top-tier accounts.

### Other endpoints

```bash
POST /contact/reverse/email/bulk   # who is behind an email (person + company)
POST /people/search                # find people by role, company, industry, location, size
POST /company/search
POST /people/lookup                # one person by profile URL, or name + company
POST /company/lookup               # one company by domain or profile URL
GET  /account/credits
```

## Email Statuses

| Status | Meaning (FullEnrich's stated bounce rates) | Outbound action |
|--------|--------------------------------------------|-----------------|
| `DELIVERABLE` | About 2% bounce | Send after your own pre-send verification |
| `HIGH_PROBABILITY` | Catch-all, likely valid; about 9% bounce | Resolve with a catch-all verifier before sending |
| `CATCH_ALL` | Catch-all, higher bounce risk | Resolve first; send only for high-value accounts |
| `INVALID` | Very likely to bounce | Don't send |

`most_probable_work_email` returns the lowest-bounce-risk work email it found. A 9% bounce rate alone would exceed the under-2% target for cold email, so verify FullEnrich output with a dedicated verifier (see [truelist.md](truelist.md)) before it reaches a sequencer.

## Credits

Credits are charged only when a result is found:
- Work email (deliverable, high probability, or catch-all): 1 credit
- Personal email: 3 credits
- Mobile phone: 10 credits
- Search results: 0.25 credit per person or company returned (re-exports are free)

Source: [credits docs](https://docs.fullenrich.com/api/v2/general/credit). Plans: [fullenrich.com/pricing](https://fullenrich.com/pricing).

## Rate Limits

- 60 API calls per minute across all endpoints; up to 100 contacts per bulk request (about 6,000 contacts a minute)
- 100 concurrent enrichments and 100 concurrent reverse lookups per workspace
- Source: [rate limit docs](https://docs.fullenrich.com/api/v2/general/ratelimit)

## When to Use

- Filling gaps after a primary database (Apollo, ZoomInfo) returns no email
- Finding mobile numbers for tier-1 accounts before calling
- Before committing, run a 200-contact test on your own ICP against one or two alternatives (LeadMagic, Prospeo, Findymail). Public benchmarks are vendor-run and disagree.

## Relevant Skills

- prospecting
- cold-email
- revops

## File: tools/integrations/g2.md

# G2

Software review and research platform for B2B buyers. Access reviews, product data, competitor comparisons, and buyer intent signals.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Reviews, Products, Reports, Categories, Tracking |
| MCP | - | Not available |
| CLI | ✓ | [g2.js](../clis/g2.js) |
| SDK | - | REST API with JSON:API format |

## Authentication

- **Type**: API Token
- **Header**: `Authorization: Token token={YOUR_API_TOKEN}`
- **Content-Type**: `application/vnd.api+json` (JSON:API)
- **Get token**: G2 Admin Portal > Integrations > API Tokens
- **Docs**: https://data.g2.com/api/docs

## Common Agent Operations

### List reviews (survey responses)

```bash
GET https://data.g2.com/api/v1/survey-responses?page[size]=25&page[number]=1

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### Get a specific review

```bash
GET https://data.g2.com/api/v1/survey-responses/{id}

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### Filter reviews by product

```bash
GET https://data.g2.com/api/v1/survey-responses?filter[product_id]={product_id}&page[size]=25

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### List products

```bash
GET https://data.g2.com/api/v1/products?page[size]=25&page[number]=1

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### Get a specific product

```bash
GET https://data.g2.com/api/v1/products/{id}

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### List reports

```bash
GET https://data.g2.com/api/v1/reports?page[size]=25&page[number]=1

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### List categories

```bash
GET https://data.g2.com/api/v1/categories?page[size]=25&page[number]=1

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### Get competitor comparisons

```bash
GET https://data.g2.com/api/v1/competitor-comparisons?filter[product_id]={product_id}&page[size]=25

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

### Get tracking events (buyer intent)

```bash
GET https://data.g2.com/api/v1/tracking-events?filter[start_date]=2025-01-01&filter[end_date]=2025-12-31

Headers:
  Authorization: Token token={API_TOKEN}
  Content-Type: application/vnd.api+json
```

## API Pattern

G2 follows the JSON:API specification (https://jsonapi.org/):
- Responses use `data`, `attributes`, `relationships`, `meta` structure
- Pagination: `page[number]` and `page[size]` query parameters
- Filtering: `filter[field]=value` query parameters
- Reviews returned newest-first by default (10 per page default)

## Key Metrics

### Review Metrics
- `star_rating` - Overall star rating
- `title` - Review title
- `comment_answers` - Structured review responses (likes, dislikes, recommendations)
- `submitted_at` - Review submission date
- `is_public` - Whether the review is publicly visible

### Product Metrics
- `name` - Product name
- `slug` - URL slug on G2
- `avg_rating` - Average star rating
- `total_reviews` - Total review count
- `category` - G2 category placement

### Buyer Intent (Tracking)
- `company_name` - Visiting company name
- `page_visited` - G2 page URL visited
- `visited_at` - Visit timestamp
- `activity_type` - Type of buyer activity

## Parameters

### Pagination
- `page[number]` - Page number (default: 1)
- `page[size]` - Items per page (default: 10, max: 100)

### Review Filters
- `filter[product_id]` - Filter by product ID
- `filter[state]` - Filter by review state

### Tracking Filters
- `filter[start_date]` - Start date (YYYY-MM-DD)
- `filter[end_date]` - End date (YYYY-MM-DD)

## When to Use

- Monitoring and analyzing software product reviews
- Tracking buyer intent signals from G2 visitors
- Pulling competitor comparison data for positioning
- Feeding review data into CRM or marketing automation
- Building social proof content from G2 reviews
- Tracking G2 category rankings and report placements

## Rate Limits

- 10,000 requests per hour per API token
- Implement exponential backoff on 429 responses
- Cache results where possible to reduce API calls

## Relevant Skills

- competitors
- social-proof
- reputation-management
- customer-feedback
- review-generation

## File: tools/integrations/ga4.md

# Google Analytics 4 (GA4)

Web analytics platform for tracking user behavior, conversions, and marketing performance.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Data API for reports, Admin API for configuration |
| MCP | ✓ | Available via Google Analytics MCP server |
| CLI | - | Use gcloud for some operations |
| SDK | ✓ | gtag.js, Google Analytics SDK for mobile |

## Authentication

- **Data/Admin APIs**: OAuth 2.0 or Service Account
- **Scopes**: `https://www.googleapis.com/auth/analytics.readonly` (read), `https://www.googleapis.com/auth/analytics.edit` (write)
- **Setup**: Create credentials in Google Cloud Console
- **Measurement Protocol**: Authenticate with a stream API secret and measurement ID,
  independently of OAuth. The CLI `events send` command requires `--api-secret`,
  `--measurement-id`, and `--client-id`; it does not require `GA4_ACCESS_TOKEN`.

## Common Agent Operations

### Run a report (Data API)

```bash
POST https://analyticsdata.googleapis.com/v1beta/properties/{property_id}:runReport

{
  "dateRanges": [{"startDate": "30daysAgo", "endDate": "today"}],
  "dimensions": [{"name": "sessionSource"}],
  "metrics": [{"name": "sessions"}, {"name": "conversions"}]
}
```

### Get real-time data

```bash
POST https://analyticsdata.googleapis.com/v1beta/properties/{property_id}:runRealtimeReport

{
  "dimensions": [{"name": "country"}],
  "metrics": [{"name": "activeUsers"}]
}
```

### List conversion events

```bash
GET https://analyticsadmin.googleapis.com/v1beta/properties/{property_id}/conversionEvents
```

### Create a conversion event

```bash
POST https://analyticsadmin.googleapis.com/v1beta/properties/{property_id}/conversionEvents

{
  "eventName": "purchase"
}
```

## Client-Side Tracking

### Send custom event (gtag.js)

```javascript
gtag('event', 'signup_completed', {
  'method': 'email',
  'plan': 'free'
});
```

### Send event via Measurement Protocol

The CLI's `--params` must be a JSON object, such as
`'{"currency":"USD","value":12.5}'`; arrays, `null`, and scalar values are
rejected before sending. Nested ecommerce `items` arrays inside that object are
preserved. A successful HTTP response from `collect` confirms receipt, not that
Analytics processed the event. Use Google's validation guidance for semantic
checks; this CLI preflight is not a complete event-schema validator.
See the [Measurement Protocol reference](https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference).

```bash
POST https://www.google-analytics.com/mp/collect?measurement_id={measurement_id}&api_secret={api_secret}

{
  "client_id": "client_123",
  "events": [{
    "name": "purchase",
    "params": {
      "value": 99.99,
      "currency": "USD"
    }
  }]
}
```

## Key Dimensions & Metrics

### Common Dimensions
- `sessionSource` - Traffic source
- `sessionMedium` - Traffic medium
- `sessionCampaignName` - Campaign name
- `landingPage` - Entry page
- `deviceCategory` - Device type
- `country` - User country

### Common Metrics
- `sessions` - Total sessions
- `activeUsers` - Active users
- `newUsers` - New users
- `conversions` - Conversion events
- `engagementRate` - Engaged sessions rate
- `averageSessionDuration` - Session duration

## When to Use

- Tracking website traffic and user behavior
- Measuring marketing campaign performance
- Setting up conversion tracking
- Analyzing user journeys and funnels
- Attribution modeling

## Rate Limits

- Data API: 10 requests per second per property
- Admin API: Varies by endpoint
- Measurement Protocol: 1M hits/day for free tier

## Relevant Skills

- analytics
- ab-testing
- seo-audit
- cro

## Paging standard reports from the CLI

`reports run` returns one page per invocation. Use `--limit` and `--offset` to
read subsequent rows and `--order-bys` to keep their ordering explicit. The CLI
sends these pagination integers as decimal strings, as required by the Data API,
without rounding offsets through JavaScript's floating-point Number type.
`--offset 0` starts at the first row. The API defaults to 10,000 rows when limit
is omitted, and returns at most 250,000 rows per request even if you ask for more.

```bash
node tools/clis/ga4.js reports run --property 123 \
  --start-date 2026-09-01 --end-date 2026-09-30 \
  --dimensions date,country --metrics activeUsers --limit 1000 --offset 0 \
  --order-bys '[{"dimension":{"dimensionName":"date"}},{"dimension":{"dimensionName":"country"}}]'
# Repeat with --offset 1000, keeping every other report option unchanged.
```

For an export, order by the complete set of requested dimensions so ties in a
metric do not leave page order ambiguous. If metric ordering is useful, put it
first and retain dimension ordering as tie-breakers. Keep the same property,
fixed date boundaries, dimensions, metrics, page size and order on every page.
The CLI passes ordering objects unchanged; Google validates referenced fields
and ordering types. Relative dates or mutable recent analytics data can change
between requests, so pagination does not guarantee a snapshot of live data.

Read the response's `rowCount`, headers and metadata together with its rows.
Advance the offset by the number of rows actually returned and stop when all
reported rows have been consumed or a page is empty. Do not advance by a limit
larger than the API's 250,000-row cap. These flags affect `reports run`; they do
not add offset pagination to realtime reports or Measurement Protocol events.
`--dry-run` previews the same body with OAuth authorization masked.

See the official [runReport request contract](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/properties/runReport),
[report pagination guide](https://developers.google.com/analytics/devguides/reporting/data/v1/basics#pagination)
and [OrderBy schema](https://developers.google.com/analytics/devguides/reporting/data/v1/rest/v1beta/OrderBy).

## File: tools/integrations/github.md

# GitHub

GitHub REST API for prospecting use cases: listing users who star, fork, or watch a repo as a high-quality developer-intent signal.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Public REST API, well-documented |
| MCP | - | Several community MCP servers exist; not bundled here |
| CLI | ✓ | [github-prospects.js](../clis/github-prospects.js) — stargazers, forks, watchers, user, rate-limit |
| SDK | ✓ | Official Octokit (JS, Python, Ruby, .NET, Go) |

## Authentication

- **Type**: Personal Access Token (PAT) or Fine-Grained PAT
- **Header**: `Authorization: Bearer {token}`
- **Get token**: https://github.com/settings/tokens
- **Scopes for prospecting**:
  - Public data (stargazers, forks, public profiles): **no scope required** with a token, or unauthenticated
  - Public repo metadata: `public_repo` scope
- **Env var**: `GITHUB_TOKEN`

### Rate limits

| Auth | Limit | When you hit it |
|------|-------|-----------------|
| Unauthenticated | 60 req/hr | Fine for one-off small lookups |
| Authenticated PAT | 5,000 req/hr | Sufficient for a 10K-star repo pull in one hour |
| GitHub App | 5,000–15,000 req/hr | For high-volume use |

A 1,000-star repo with full enrichment (1 list call + 1 profile call per user) = ~1,011 requests. Always set a token.

## Common Agent Operations

### List stargazers (users who starred a repo)

```bash
GET https://api.github.com/repos/{owner}/{repo}/stargazers?per_page=100&page=1

Accept: application/vnd.github+json
X-GitHub-Api-Version: 2022-11-28
Authorization: Bearer {token}
```

Pagination via `Link` header (`rel="next"`, `rel="last"`). Default 30 per page, max 100.

Returns array of user objects with `login`, `id`, `html_url`, `type` (User or Organization). Full profile fields (email, company, blog, bio, location) require a follow-up call per user.

### List forks (gives fork owner profiles)

```bash
GET https://api.github.com/repos/{owner}/{repo}/forks?per_page=100&page=1
```

Each fork object includes the `owner` (the user/org that forked). Forks are a stronger signal than stars — they imply intent to modify, not just bookmark.

### List watchers (subscribers)

```bash
GET https://api.github.com/repos/{owner}/{repo}/subscribers?per_page=100&page=1
```

GitHub's "watch" → API's "subscribers". Smaller pool than stargazers but signals deeper engagement.

### Get user profile (enrichment)

```bash
GET https://api.github.com/users/{username}
```

Returns: `name`, `company`, `blog`, `email` (if public), `bio`, `twitter_username`, `location`, `public_repos`, `followers`, `created_at`, `hireable`.

**Key fields for prospecting**:
- `email`: only ~5–20% of users publish this. Always nullable.
- `company`: many users include `@org` syntax — strip the `@` for plain company name.
- `blog`: often a personal website where contact info is published.
- `twitter_username` / `bio`: useful for cross-channel research.

### Check rate limit

```bash
GET https://api.github.com/rate_limit
```

## Prospecting Workflows

### Workflow 1 — Stargazers of a competitor or adjacent tool

```bash
# 100 stargazers, enrich each one, only keep those with email or company set
node tools/clis/github-prospects.js stargazers vercel/next.js \
  --limit 100 --enrich --format csv > nextjs-stars.csv
```

Filter the CSV in your spreadsheet by `company` set OR `email` set OR `blog` set. Hand off to Apollo/Clay/Hunter to enrich the rest with email-by-name+company.

### Workflow 2 — Forks of your own repo (warm intent)

People who fork your repo have already shown direct interest. High-conversion outreach prospects.

```bash
node tools/clis/github-prospects.js forks yourorg/yourrepo \
  --enrich --with-email --format csv > my-fork-prospects.csv
```

### Workflow 3 — Watchers of a category-defining repo

Watchers are smaller in number but higher in intent — they're tracking changes, not just bookmarking.

```bash
node tools/clis/github-prospects.js watchers tldraw/tldraw \
  --enrich --with-company --format csv > tldraw-watchers.csv
```

## CLI Reference

```bash
# Stargazers
node tools/clis/github-prospects.js stargazers <owner/repo> \
  [--limit N] [--enrich] [--with-email] [--with-company] \
  [--with-blog] [--type User|Organization] [--format csv|json]

# Forks
node tools/clis/github-prospects.js forks <owner/repo> [...same flags]

# Watchers (subscribers in API terms)
node tools/clis/github-prospects.js watchers <owner/repo> [...same flags]

# Single user lookup
node tools/clis/github-prospects.js user <username>

# Check rate limit
node tools/clis/github-prospects.js rate-limit
```

**Flags**:
- `--limit N`: cap total results pulled from the list endpoint
- `--target N`: when filtering with `--with-*`, stop enriching as soon as N users match (saves quota on restrictive filters)
- `--enrich`: fetch full profile per user (1 extra request each)
- `--with-email` / `--with-company` / `--with-blog`: filter to users with these fields set (implies `--enrich`)
- `--type User|Organization`: filter by account type
- `--format csv`: output prospecting-ready CSV; default is JSON
- `--dry-run`: preview the request without sending

### Enrichment failures

If profile enrichment fails because of authentication, rate limits, or another
HTTP error, `stargazers`, `forks`, and `watchers` exit with status 1 and a JSON
diagnostic on stderr. They do not print a partial CSV or a misleading successful
empty JSON export. A missing (404) user profile can still be skipped; a valid
profile that does not match the requested filters is also skipped.


## When to Use

- **SaaS prospecting** (primary use case): stargazers of a competitor, complement, or category-defining repo as in-market developer signal
- **Open-source product marketing**: see who's forking or watching your own repo for warm outreach
- **Developer-tool ICP discovery**: stargazers of `next.js`, `prisma`, `tailwindcss`, etc., signal a Next.js / Prisma / Tailwind developer
- **Trigger event monitoring**: a recent fork of a competitor's repo often signals dissatisfaction or active evaluation

## When NOT to Use

- **Email is your only signal you need** — GitHub yields email for only ~5–20% of users. Pair with Apollo, Clay, or Hunter for enrichment from name + company.
- **Hyper-broad lists** — a repo with 100K+ stars is mostly noise. Smaller, more specific repos (5K–25K stars) give higher-signal lists.
- **You don't have a way to handle high-volume LinkedIn lookup downstream** — most enrichment from GitHub username goes through LinkedIn Sales Nav manually.

## Compliance Notes

- **GitHub data is public** — no ToS issue with reading the API. The ToS prohibits abusive scraping (bypassing rate limits, mass account creation), not legitimate API usage.
- **Personal emails published on GitHub** — users opt in to publishing their email. Treat as business contact when paired with company/blog signals; respect GDPR/CAN-SPAM for the downstream send.
- **Source URL lineage** — for every prospect added from GitHub, capture `html_url` (their profile URL) and the source repo. Required for GDPR DSAR defense.
- **Cool-down between large pulls** — even at 5,000 req/hr, don't burst-fingerprint. Pagination is naturally paced; respect `X-RateLimit-Remaining` headers.

## Pairing with Other Tools

Typical GitHub prospecting pipeline:

1. Pull stargazers/forkers via this CLI
2. Filter to users with company set (or other signal)
3. **Enrich missing emails** via Apollo / Clay / Hunter (lookup by name + company domain)
4. **Validate emails** via Truelist before adding to outreach list
5. **Hand off** to cold-email skill for outreach

See `skills/prospecting/references/saas-prospecting.md` and `data-sources.md` for the full prospecting framework.

## Relevant Skills

- prospecting (primary use case)
- cold-email (downstream outreach)
- competitor-profiling (deeper account-level research on individual stargazers worth pursuing)

### CSV export of public profiles

`github-prospects.js --format csv` prefixes formula-like profile strings with
an apostrophe so spreadsheet imports treat them as text. Numeric counts remain
numeric. Use the default JSON format when you need the original unmodified
profile values. CSV quoting alone does not prevent spreadsheet formula execution.

## File: tools/integrations/glasser.md

# Glasser

Pay-per-call access to 1,000+ paid data API endpoints from 20+ providers via a single key. Provides agent-native access to SEO, search, enrichment, email-finding, and scraping vendors that otherwise each need their own account, plan, or minimum deposit.

> **Disclosure:** this guide was contributed by a member of the Glasser team. Glasser is a young product (CLI first published September 2026), so confirm coverage, pricing, and each provider's terms before relying on it.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for searching endpoints, inspecting prices, and running calls |
| MCP | ✓ | Hosted MCP server exposes the same operations |
| CLI | ✓ | `glasser` for searching, inspecting, and running endpoints |

## Authentication

- **Type**: API Key (Bearer)
- **Setup**: `npm install -g @glasser-ai/cli`, then `glasser login` to store a key via browser approval ([current instructions](https://glasser.ai/SKILL.md))
- **API Key** (CI / MCP): `GLASSER_API_KEY` env var, created at https://app.glasser.ai/keys

Glasser holds the provider accounts: no signup, plan, or key at any provider, and every call is billed to one prepaid balance at a price shown before the call. Individual provider coverage is listed in the Data Providers table below.

## When to Use Glasser vs. Native Tools

Glasser is an **alternative integration method**, not a replacement. Follow the user's explicit tool choice first. Otherwise, prefer an existing key, integration, or free tool that meets the task's requirements. Use this decision guide:

| Scenario | Use |
|----------|-----|
| Keyword volume or a SERP snapshot for an audit, no DataForSEO account | Glasser (`dataforseo`, `serper`) |
| Occasional backlink or domain-rating checks without your own SEO tool subscription | Glasser (`ahrefs`, `semrush`, `serpstat`), if its per-call access fits the provider's terms for your use |
| Work email for one prospect, no Hunter or Apollo account | Glasser (`hunter`, `leadmagic`, `prospeo`) |
| Firmographics, tech stack, and job openings for a competitor set | Glasser (`pdl`, `builtwith`, `predictleads`) |
| What people say on TikTok, Reddit, Xiaohongshu, or Douyin about a category | Glasser (`scrapecreators`, `tikhub`) |
| You already hold a DataForSEO, Ahrefs, Semrush, Exa, Apollo, ZoomInfo, or Hunter key | That vendor's native guide |
| Your own site's Search Console or GA4 data, ad platforms, CRMs | Native MCP server or API guide |
| Vendor not covered by Glasser | Native API guide |

## Setup

### 1. Install the CLI

```bash
npm install -g @glasser-ai/cli
```

Requires Node.js 22+.

### 2. Log in

```bash
glasser login
```

This opens the console; approve when the code on the page matches the terminal. The key persists across sessions.

### 3. Verify installation

```bash
glasser balance
```

Exit 0 means the key works.

### 4. MCP server (optional)

For agents without a shell, add the hosted server to your MCP client configuration. Set `GLASSER_API_KEY` in the client's environment. For Claude Code, use `.mcp.json`:

```json
{
  "mcpServers": {
    "glasser": {
      "type": "http",
      "url": "https://api.glasser.ai/mcp",
      "headers": { "Authorization": "Bearer ${GLASSER_API_KEY}" }
    }
  }
}
```

In Claude Code, run `/mcp` to confirm `glasser` is connected. For Cursor, Codex, and other clients, follow the [client-specific MCP setup instructions](https://glasser.ai/docs/mcp-server); configuration formats and environment variable syntax differ.

## Data Providers Available via Glasser

### By Marketing Need

One key covers every row. Several providers usually sell the same job; `glasser search` lists them with the price beside each, so the agent picks per call.

| Need | Providers via Glasser | What you get |
|------|----------------------|--------------|
| Keyword research | [DataForSEO](https://glasser.ai/data-sources/dataforseo), [Ahrefs](https://glasser.ai/data-sources/ahrefs), [Semrush](https://glasser.ai/data-sources/semrush), [Serpstat](https://glasser.ai/data-sources/serpstat) | Search volume, keyword ideas, difficulty, CPC from four indexes without a plan at any of them |
| SERP snapshots and rank checks | [DataForSEO](https://glasser.ai/data-sources/dataforseo), [Serper](https://glasser.ai/data-sources/serper), [SerpApi](https://glasser.ai/data-sources/serpapi) | Google, Bing, DuckDuckGo, Baidu result pages; news, images, videos, places, scholar, shopping |
| Backlink audit and domain rating | [Ahrefs](https://glasser.ai/data-sources/ahrefs), [DataForSEO](https://glasser.ai/data-sources/dataforseo), [Semrush](https://glasser.ai/data-sources/semrush), [Serpstat](https://glasser.ai/data-sources/serpstat) | Backlink profiles, referring domains, anchors, DR, broken links — the Ahrefs index without an Ahrefs plan |
| AI search visibility | [Ahrefs](https://glasser.ai/data-sources/ahrefs), [DataForSEO](https://glasser.ai/data-sources/dataforseo) | How often a domain is cited in ChatGPT, Perplexity, Gemini, Copilot and Google AI answers; AI keyword volume |
| Competitor and company research | [People Data Labs](https://glasser.ai/data-sources/pdl), [Apollo](https://glasser.ai/data-sources/apollo), [ZoomInfo](https://glasser.ai/data-sources/zoominfo), [Crustdata](https://glasser.ai/data-sources/crustdata), [Akta](https://glasser.ai/data-sources/akta), [PredictLeads](https://glasser.ai/data-sources/predictleads), [BuiltWith](https://glasser.ai/data-sources/builtwith) | Firmographics, headcount trends, funding and news events, tech stack, products |
| Prospect lists and people search | [People Data Labs](https://glasser.ai/data-sources/pdl), [Apollo](https://glasser.ai/data-sources/apollo), [Lusha](https://glasser.ai/data-sources/lusha), [Crustdata](https://glasser.ai/data-sources/crustdata), [Prospeo](https://glasser.ai/data-sources/prospeo), [ZoomInfo](https://glasser.ai/data-sources/zoominfo) | Person search by title, company, location; lookalikes; enrichment from a LinkedIn URL |
| Work email finding | [Hunter](https://glasser.ai/data-sources/hunter), [LeadMagic](https://glasser.ai/data-sources/leadmagic), [Prospeo](https://glasser.ai/data-sources/prospeo), [ContactOut](https://glasser.ai/data-sources/contactout), [Lusha](https://glasser.ai/data-sources/lusha) | Five finders behind one key; several charge nothing when no email is found (see `inspect`) |
| Hiring signals | [TheirStack](https://glasser.ai/data-sources/theirstack), [PredictLeads](https://glasser.ai/data-sources/predictleads), [Apollo](https://glasser.ai/data-sources/apollo), [Crustdata](https://glasser.ai/data-sources/crustdata) | Job postings by company, role, or technology |
| Social listening | [ScrapeCreators](https://glasser.ai/data-sources/scrapecreators) | TikTok, Instagram, Facebook, YouTube, X, Reddit, LinkedIn, Pinterest: posts, comments, transcripts, profiles |
| Chinese platforms | [TikHub](https://glasser.ai/data-sources/tikhub) | Douyin, Xiaohongshu, Weibo, Bilibili, Kuaishou, WeChat — search, comments, trending; not covered by any other guide in this repo |
| Content research by meaning | [Exa](https://glasser.ai/data-sources/exa) | Neural web search, pages similar to a URL, answers with citations, page text for a list of URLs |
| Web and marketplace scraping | [Serper](https://glasser.ai/data-sources/serper), [Apify](https://glasser.ai/data-sources/apify), [Bright Data](https://glasser.ai/data-sources/brightdata) | Page-to-text; Amazon, app stores, Google Maps, Crunchbase, Glassdoor datasets |

### Alternative to Existing Tools

These vendors **already have API guides** in this repo. Glasser provides an alternative path:

| Tool | Glasser slug | Native Integration | Direct access | Via Glasser |
|------|--------------|-------------------|---------------|-------------|
| [DataForSEO](dataforseo.md) | [`dataforseo`](https://glasser.ai/data-sources/dataforseo) | API ✓, CLI ✓, SDK ✓ | Pay as you go with a minimum deposit | Per call, no deposit |
| [Ahrefs](ahrefs.md) | [`ahrefs`](https://glasser.ai/data-sources/ahrefs) | API ✓, CLI ✓ | API from a paid plan | Per call, no plan |
| [Semrush](semrush.md) | [`semrush`](https://glasser.ai/data-sources/semrush) | API ✓, CLI ✓ | API from a paid plan plus API units | Per call, no plan |
| [Exa](exa.md) | [`exa`](https://glasser.ai/data-sources/exa) | API ✓, MCP ✓, CLI ✓, SDK ✓ | Pay per use, free starter tier | Per call — prefer native (MCP, SDKs) |
| [Apollo](apollo.md) | [`apollo`](https://glasser.ai/data-sources/apollo) | API ✓, CLI ✓ | Free tier includes API credits | Per call, no account |
| [ZoomInfo](zoominfo.md) | [`zoominfo`](https://glasser.ai/data-sources/zoominfo) | API ✓, MCP ✓, CLI ✓ | Pricing not public | Per result — prefer native (MCP, intent data) |
| [Hunter](hunter.md) | [`hunter`](https://glasser.ai/data-sources/hunter) | API ✓, CLI ✓ | Free tier includes API credits; paid plans above | Per call, no account |

Coverage changes over time — `glasser search` lists the current providers.

## Common Agent Operations

### Search endpoints

```bash
glasser search -q "keyword search volume"
```

### Inspect an endpoint's price and input schema

```bash
glasser inspect -p dataforseo -e /v3/keywords_data/google_ads/search_volume/live
```

### Run an endpoint

```bash
glasser run -p dataforseo -e /v3/keywords_data/google_ads/search_volume/live \
  -i '{"keywords":["coffee roaster","espresso machine"],"language_code":"en","location_code":2840}'
```

### Wait for an asynchronous run

Inspect reports `run_mode`. For asynchronous endpoints, add `--wait` to `glasser run`. If a run returns `QUEUED` or `RUNNING`, fetch that run until it settles:

```bash
glasser runs get -r <runId> --wait
```

Do not submit another run to check progress. `COMPLETED` means the provider answered; check the provider response for errors or missing results, and report the final charge.

### Run an endpoint over HTTP

```http
POST https://api.glasser.ai/v1/runs
Authorization: Bearer {key}
Content-Type: application/json
Idempotency-Key: {uuid}

{ "provider": "serper", "endpoint": "/search", "input": { "q": "vector database benchmarks", "num": 10 } }
```

An asynchronous endpoint can return `202` with an in-flight run. Poll `GET /v1/runs/{runId}` until its status is terminal. On a timeout or dropped connection, retry with the same idempotency key; a new key can create a second paid run.

## Example Workflows

### Keyword research for a niche

```
> "Get monthly search volume and related keyword ideas for 'espresso machine' in the US"
```
Agent uses `dataforseo` (`/v3/keywords_data/google_ads/search_volume/live`, `/v3/dataforseo_labs/google/keyword_ideas/live`).

### Competitor profile

```
> "Pull firmographics, tech stack, and recent news for acme.com and two competitors"
```
Agent uses `pdl` (`/v5/company/enrich`), `builtwith` (`/v23/api.json`), and `serper` (`/news`).

### Find a work email before outreach

```
> "Find the work email for Patrick Collison at stripe.com"
```
Agent uses `hunter` (`/v2/email-finder`); `leadmagic` and `prospeo` sell the same lookup.

## Limitations

- **Coverage depth varies** — some providers expose hundreds of endpoints (TikHub, ScrapeCreators, DataForSEO), others a handful (Semrush, Exa, TheirStack)
- **No customization** — you can't add endpoints or change a provider's input schema
- **Vendor dependency** — if Glasser's servers are down, all providers are unavailable through this path
- **Rate limits apply** — Glasser enforces its own per-account and per-endpoint limits
- **Raw provider payloads** — output keeps each provider's own shape; field meanings come from the provider's docs, linked from `inspect`
- **Prepaid balance** — a run that exceeds the available balance is refused before it starts

## Pricing

Pay per call, no subscription. Each endpoint publishes its price; `inspect` shows it before you run. Current prices for every endpoint: https://glasser.ai/data-sources

- Provider errors, timeouts, and internal failures are never charged
- An empty result is charged per the endpoint's `NO_RESULT` clause; free on some endpoints
- A retry with the same idempotency key returns the original run and is never charged twice

## Rate Limits

- Per account and per endpoint; a `429` carries `retry_after_ms`
- `search` returns up to 20 results per page

## See Also

- [How it works](https://glasser.ai/docs/how-it-works) — endpoints, prices, run lifecycle, idempotent retries
- [CLI reference](https://glasser.ai/docs/cli) — every command, flags, exit codes, JSON mode

## Relevant Skills

- seo-audit (DataForSEO, Ahrefs, Semrush via Glasser)
- competitor-profiling (BuiltWith, People Data Labs, news search via Glasser)
- prospecting (People Data Labs, Apollo, Hunter via Glasser)
- cold-email (Hunter, LeadMagic, Prospeo via Glasser)

## File: tools/integrations/gong.md

# Gong

Revenue intelligence platform that records, transcribes, and analyzes sales conversations (calls, video meetings, emails) to surface deal insights, coaching opportunities, and competitive intelligence.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API, Basic Auth or OAuth2 |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | REST API only; community Python client via dltHub |

## Authentication

- **Type**: Basic Auth (Access Key + Secret) or OAuth2 for published apps
- **Get key**: Admin-only — Settings > API at https://app.gong.io
- **Base URL**: Tenant-specific — retrieve from your Gong API settings (typically `https://{tenant}.api.gong.io/v2/`)
- **Docs**: https://help.gong.io/docs/what-the-gong-api-provides

## API Endpoints

Most Gong API endpoints use **POST** with JSON request bodies for filtering. Check the [official API docs](https://gong.app.gong.io/settings/api/documentation) for current endpoint availability.

### Calls

```bash
# List calls (with date/user filters)
POST /v2/calls/extensive

# Get call transcripts (batch, by call IDs)
POST /v2/calls/transcript
```

### Users & Stats

```bash
# List users
GET /v2/users

# Get activity stats (talk ratio, questions asked, longest monologue)
POST /v2/stats/activity/day-by-day
```

### Engagement Flows

```bash
# List flows
GET /v2/flows

# Get flow analytics
GET /v2/flows/{id}/analytics
```

## Key Data Points

### Per Call
- Full transcript with speaker labels and timestamps
- Talk-to-listen ratio per participant
- Topics discussed (auto-detected)
- Questions asked (count and content)
- Longest monologue duration
- Next steps mentioned
- Competitor mentions
- Pricing discussions flagged

### Per Deal
- All associated calls and emails
- Deal stage progression
- Risk signals (gone dark, competitor mentioned, champion left)
- Engagement score

### Per Rep
- Talk ratio trends
- Question frequency
- Topic coverage vs. playbook
- Win rate correlation with behaviors

## Common Agent Operations

### Extract Competitive Intelligence from Calls

1. Query calls mentioning competitor names
2. Extract: objections raised, features compared, pricing discussed
3. Synthesize into competitive battlecard updates
4. Track competitor mention frequency over time

### Mine Calls for Customer Research

1. Pull transcripts from recent won/lost deals
2. Extract: pain points, trigger events, decision criteria, language used
3. Feed into persona building and messaging work
4. Identify recurring objections for sales enablement

### Revenue Attribution

1. Pull call data alongside CRM deal data
2. Map which content/pages were discussed in winning deals
3. Identify which talking points correlate with closed-won
4. Build content-to-revenue attribution reports

### Rep Coaching Insights

1. Compare top performer call patterns vs. team average
2. Identify: talk ratio, question frequency, topic coverage gaps
3. Surface specific call moments for coaching review
4. Track improvement over time

## Rate Limits

- 3 API calls per second
- 10,000 API calls per day
- Pagination required for large result sets

## When to Use

- Mining sales call transcripts for customer research and VOC data
- Extracting competitive intelligence from prospect conversations
- Building revenue attribution models (content → deal influence)
- Analyzing win/loss patterns across deal transcripts
- Coaching sales reps based on conversation analytics
- Identifying common objections and buying signals

## Limitations

- API access requires admin credentials
- Transcript quality depends on call audio quality
- Rate limits (10k/day) may constrain large-scale analysis
- Pricing is enterprise-level (not publicly listed, typically $100+/user/month)
- Requires team adoption — records calls via integrations, but also supports uploading calls from non-integrated telephony systems

## Relevant Skills

- customer-research
- sales-enablement
- competitors
- revops
- cold-email

## Sources

- [Gong API overview](https://help.gong.io/docs/what-the-gong-api-provides)
- [Gong API documentation](https://gong.app.gong.io/settings/api/documentation)
- [Call upload support](https://help.gong.io/docs/uploading-calls-from-a-non-integrated-telephony-system)

## File: tools/integrations/google-ads.md

# Google Ads

Pay-per-click advertising platform for search, display, and video campaigns.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Google Ads API for campaign management |
| MCP | ✓ | Available via Google Ads MCP server |
| CLI | ✓ | Repository zero-dependency Node.js CLI |
| SDK | ✓ | Client libraries for multiple languages |

## Authentication

- **Type**: OAuth 2.0
- **Scopes**: `https://www.googleapis.com/auth/adwords`
- **Setup**: Create credentials in Google Cloud Console, link to Google Ads account
- **Headers**: `Authorization: Bearer <access_token>`; `login-customer-id` when acting through a manager account
- **API access**: Google Ads API access is assigned to the Google Cloud project that owns your OAuth credentials. Developer tokens were sunset on September 9, 2026; the `developer-token` header is now optional and ignored. Apply for the appropriate project access level in Google Cloud Console, not the retired manager-account API Center process. [Official migration guide](https://developers.google.com/google-ads/api/docs/api-policy/developer-token).

### Repository CLI credentials

The repository's [Google Ads CLI](../clis/google-ads.js) uses `GOOGLE_ADS_TOKEN` (OAuth access token) and `GOOGLE_ADS_CUSTOMER_ID` (target customer ID without hyphens). Set `GOOGLE_ADS_LOGIN_CUSTOMER_ID` when access goes through a manager; it is normalized to digits. Existing setups can still supply `GOOGLE_ADS_DEVELOPER_TOKEN`, but new setups do not need it. The CLI consumes an access token; it does not exchange or refresh OAuth tokens for you. OAuth scopes, user access to the target account, and the Cloud project's API access level remain required.

Use a read-only first call after selecting the intended account:

```bash
node tools/clis/google-ads.js account info
```

A successful response verifies this read's access; it does not establish permission for campaign edits or budget changes.

## Common Agent Operations

### Get account info

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/googleAds:searchStream

{
  "query": "SELECT customer.id, customer.descriptive_name FROM customer"
}
```

### List campaigns

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/googleAds:searchStream

{
  "query": "SELECT campaign.id, campaign.name, campaign.status, campaign_budget.amount_micros FROM campaign ORDER BY campaign.id"
}
```

### Get campaign performance

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/googleAds:searchStream

{
  "query": "SELECT campaign.name, metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions FROM campaign WHERE segments.date DURING LAST_30_DAYS"
}
```

### Get ad group performance

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/googleAds:searchStream

{
  "query": "SELECT ad_group.name, metrics.impressions, metrics.clicks, metrics.conversions FROM ad_group WHERE segments.date DURING LAST_7_DAYS"
}
```

### Get keyword performance

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/googleAds:searchStream

{
  "query": "SELECT ad_group_criterion.keyword.text, metrics.impressions, metrics.clicks, metrics.average_cpc FROM keyword_view WHERE segments.date DURING LAST_30_DAYS ORDER BY metrics.clicks DESC LIMIT 50"
}
```

### Pause campaign

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/campaigns:mutate

{
  "operations": [{
    "update": {
      "resourceName": "customers/{customer_id}/campaigns/{campaign_id}",
      "status": "PAUSED"
    },
    "updateMask": "status"
  }]
}
```

### Update budget

```bash
POST https://googleads.googleapis.com/v24/customers/{customer_id}/campaignBudgets:mutate

{
  "operations": [{
    "update": {
      "resourceName": "customers/{customer_id}/campaignBudgets/{budget_id}",
      "amountMicros": "50000000"
    },
    "updateMask": "amountMicros"
  }]
}
```

## Key Metrics

| Metric | Description |
|--------|-------------|
| `metrics.impressions` | Ad impressions |
| `metrics.clicks` | Clicks |
| `metrics.cost_micros` | Cost in micros (divide by 1M) |
| `metrics.conversions` | Conversions |
| `metrics.conversions_value` | Conversion value |
| `metrics.average_cpc` | Average cost per click |
| `metrics.ctr` | Click-through rate |
| `metrics.conversion_rate` | Conversion rate |

## Campaign Types

- `SEARCH` - Search network text ads
- `DISPLAY` - Display network
- `SHOPPING` - Product shopping ads
- `VIDEO` - YouTube video ads
- `PERFORMANCE_MAX` - AI-optimized across channels
- `DEMAND_GEN` - Discovery/Demand Gen

## GAQL (Google Ads Query Language)

```sql
SELECT
  campaign.name,
  metrics.clicks,
  metrics.conversions
FROM campaign
WHERE
  campaign.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions DESC
LIMIT 10
```

### Analysis recipes

Baseline queries for reading an account honestly. See the ads skill's `references/reading-google-ads-data.md` for why each matters.

**Campaign inventory** (separates real campaigns from expired experiment arms and learning bid strategies):

```sql
SELECT campaign.id, campaign.name, campaign.status, campaign.serving_status,
       campaign.primary_status, campaign.primary_status_reasons,
       campaign.experiment_type, campaign.bidding_strategy_type
FROM campaign
WHERE campaign.status != 'REMOVED'
```

**Monthly performance since launch** (only months with activity come back, so the first row is the first month with spend; run before quoting any CPA):

```sql
SELECT segments.month, metrics.impressions, metrics.clicks,
       metrics.cost_micros, metrics.conversions
FROM campaign
WHERE campaign.id = <ID>
  AND segments.date BETWEEN '<EARLY_DATE>' AND '<TODAY>'
ORDER BY segments.month
```

**Conversions by action** (primary vs secondary):

```sql
SELECT segments.conversion_action_name, segments.conversion_action_category,
       metrics.conversions, metrics.all_conversions
FROM campaign
WHERE campaign.id = <ID>
  AND segments.date BETWEEN '<START>' AND '<END>'
  AND metrics.all_conversions > 0
```

**Search terms, unfiltered** (then reconcile disclosed clicks against campaign clicks for the same window):

```sql
SELECT search_term_view.search_term, ad_group.name, metrics.impressions,
       metrics.clicks, metrics.cost_micros, metrics.conversions
FROM search_term_view
WHERE campaign.id = <ID>
  AND segments.date BETWEEN '<START>' AND '<END>'
ORDER BY metrics.impressions DESC
LIMIT 1000
```

Raise the limit until disclosed clicks stop growing; a low limit hides the long tail.

**Ads with final URLs** (ad groups often serve several destinations):

```sql
SELECT ad_group.name, ad_group_ad.ad.id, ad_group_ad.status,
       ad_group_ad.ad.final_urls, metrics.clicks, metrics.conversions
FROM ad_group_ad
WHERE campaign.id = <ID>
  AND segments.date BETWEEN '<START>' AND '<END>'
```

**Change history** (who changed what; 30-day maximum):

```sql
SELECT change_event.change_date_time, change_event.change_resource_type,
       change_event.resource_change_operation, change_event.client_type,
       change_event.user_email, change_event.changed_fields
FROM change_event
WHERE change_event.change_date_time >= '<29_DAYS_AGO>'  -- 'YYYY-MM-DD HH:MM:SS'
  AND change_event.change_date_time <= '<TOMORROW>'
ORDER BY change_event.change_date_time DESC
LIMIT 200
```

`LIMIT` is required on `change_event` and capped at 10,000.

### Gotchas

| Problem | Fix |
|---|---|
| `campaign.start_date` → `UNRECOGNIZED_FIELD` | Newer API versions use `campaign.start_date_time`; if that also fails, derive the start from the first month the monthly query returns |
| `DURING LAST_90_DAYS` → `INVALID_VALUE_WITH_DURING_OPERATOR` | Only some date literals are valid; use `segments.date BETWEEN 'YYYY-MM-DD' AND 'YYYY-MM-DD'` |
| `change_event` → `START_DATE_TOO_OLD` | 30-day limit, strictly enforced; pad the start by a day |
| `change_event` errors with no limit | `LIMIT` is required |
| Cost looks 1,000,000x too big | `cost_micros` ÷ 1,000,000 |
| Keyword or change queries return huge payloads | Write to a file and parse; `keyword_view` returns negatives too (split on `ad_group_criterion.negative`) |

## When to Use

- Managing search advertising campaigns
- Analyzing campaign performance
- Adjusting budgets and bids
- Keyword research and management
- Conversion tracking analysis

## Rate Limits

- 15,000 operations per day (basic)
- Higher limits with developer token levels

## Relevant Skills

- ads
- analytics
- cro

### Manager account access in the CLI

When OAuth credentials access a client through a manager account, set
`GOOGLE_ADS_LOGIN_CUSTOMER_ID` to that manager ID. The CLI removes display hyphens
and sends `login-customer-id` on both report and mutation requests. Keep
`GOOGLE_ADS_CUSTOMER_ID` set to the target client account. Direct client access
does not require the manager variable. See
[Google Ads REST authorization](https://developers.google.com/google-ads/api/rest/auth).

### Run custom reports with the CLI

The built-in report commands cover common summaries. Use `query run` for the
[analysis recipes above](#analysis-recipes), additional dimensions, and conversion
actions without writing another client:

```bash
node tools/clis/google-ads.js query run --query \
  "SELECT campaign.id, segments.date, metrics.clicks FROM campaign WHERE segments.date BETWEEN '2026-01-01' AND '2026-01-03' ORDER BY segments.date LIMIT 100"
```

The command forwards the supplied GAQL unchanged to the same authenticated
`googleAds:searchStream` endpoint. Google validates resource and field
compatibility; it does not call a mutation endpoint. `--dry-run` previews the
request with credentials masked. Empty queries and unknown subcommands fail
locally before transport.

Select the fields you need, bound the result with `LIMIT`, and use explicit dates
for reproducible reporting. Adding a segment changes the row grain: campaign
plus date rows are not campaign totals. JSON output preserves every returned
stream chunk and provider integer strings; do not coerce large IDs into JavaScript
numbers. Cost fields in micros still require division by one million.

See [Google's GAQL overview](https://developers.google.com/google-ads/api/docs/query/overview).

## File: tools/integrations/google-search-console.md

# Google Search Console

Free tool for monitoring website search performance and indexing.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Search Analytics API, URL Inspection API |
| MCP | - | Not available |
| CLI | - | Use gcloud or API scripts |
| SDK | ✓ | Google API client libraries |

## Authentication

- **Type**: OAuth 2.0 or Service Account
- **Scopes**: `https://www.googleapis.com/auth/webmasters.readonly`
- **Setup**: Create credentials in Google Cloud Console

## Common Agent Operations

### Get search analytics

```bash
POST https://searchconsole.googleapis.com/webmasters/v3/sites/{site_url}/searchAnalytics/query

{
  "startDate": "2024-01-01",
  "endDate": "2024-01-31",
  "dimensions": ["query"],
  "rowLimit": 100
}
```

### Get performance by page

```bash
POST https://searchconsole.googleapis.com/webmasters/v3/sites/{site_url}/searchAnalytics/query

{
  "startDate": "2024-01-01",
  "endDate": "2024-01-31",
  "dimensions": ["page"],
  "rowLimit": 50
}
```

### Get performance by country

```bash
POST https://searchconsole.googleapis.com/webmasters/v3/sites/{site_url}/searchAnalytics/query

{
  "startDate": "2024-01-01",
  "endDate": "2024-01-31",
  "dimensions": ["country", "query"],
  "rowLimit": 100
}
```

### Inspect URL

```bash
POST https://searchconsole.googleapis.com/v1/urlInspection/index:inspect

{
  "inspectionUrl": "https://example.com/page",
  "siteUrl": "https://example.com/"
}
```

### List sitemaps

```bash
GET https://searchconsole.googleapis.com/webmasters/v3/sites/{site_url}/sitemaps

Authorization: Bearer {access_token}
```

### Submit sitemap

```bash
PUT https://searchconsole.googleapis.com/webmasters/v3/sites/{site_url}/sitemaps/{sitemap_url}

Authorization: Bearer {access_token}
```

A successful [sitemap submission](https://developers.google.com/webmaster-tools/v1/sitemaps/submit)
returns an empty response body. The CLI confirms submission only for a successful
HTTP response. `--dry-run` prints the redacted PUT request without claiming submission.

```bash
node tools/clis/google-search-console.js sitemaps submit --site-url sc-domain:example.com \
  --sitemap-url https://example.com/sitemap.xml --dry-run
```

### Request indexing

```bash
POST https://indexing.googleapis.com/v3/urlNotifications:publish

{
  "url": "https://example.com/new-page",
  "type": "URL_UPDATED"
}
```

## Dimensions

- `query` - Search query
- `page` - Page URL
- `country` - Country code
- `device` - Device type (MOBILE, DESKTOP, TABLET)
- `date` - Date
- `searchAppearance` - Search result type

## Metrics

- `clicks` - Clicks from search
- `impressions` - Search impressions
- `ctr` - Click-through rate
- `position` - Average position

## Filters

```json
{
  "dimensionFilterGroups": [{
    "filters": [{
      "dimension": "query",
      "operator": "contains",
      "expression": "keyword"
    }]
  }]
}
```

## When to Use

- Analyzing search performance
- Finding keyword opportunities
- Monitoring indexing status
- Submitting new pages for indexing
- Identifying crawl issues
- Tracking position changes

## Rate Limits

- 200 queries per minute
- 1,200 requests per minute

## Relevant Skills

- seo-audit
- programmatic-seo
- analytics

## CLI result pages

The local CLI supports `--start-row` for all three Search Analytics commands:
`search query`, `search pages`, and `search countries`. The offset is zero-based;
`--limit` accepts 1–25,000 rows. The CLI retains its default page size of 100 and
omits `startRow` unless you specify it.

```bash
# First page
node tools/clis/google-search-console.js search query \
  --site-url sc-domain:example.com \
  --start-date 2026-09-01 --end-date 2026-09-30 --limit 1000

# Next page, after receiving 1,000 rows
node tools/clis/google-search-console.js search query \
  --site-url sc-domain:example.com \
  --start-date 2026-09-01 --end-date 2026-09-30 --limit 1000 --start-row 1000
```

Keep the same property, command, explicit dates, and page size while reading
pages. Advance the offset by the number of rows actually returned. An offset
past the available results produces a successful empty response; do not treat
that as an API failure. `--dry-run` previews the page body with masked credentials
without making a request. Invalid offsets and page sizes fail locally.

Paging exposes additional available rows, not a complete search-data export.
Google returns top rows subject to internal limits, ordered by descending clicks;
rows tied on clicks have arbitrary order. The API provides no stable tie-breaker
or snapshot guarantee, so do not claim an exactly-once or exhaustive export.
Use explicit dates rather than recalculating the CLI's moving default range
between pages. URL Inspection and sitemap commands are unaffected.

Reference: [Search Analytics query and pagination contract](https://developers.google.com/webmaster-tools/v1/searchanalytics/query).

## File: tools/integrations/heygen.md

# HeyGen

AI avatar video generation platform. Create talking-head videos from text scripts with realistic lip-sync, expressions, and gestures.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | Yes | REST API v2 for video generation, avatars, templates |
| MCP | Yes | Official hosted MCP server — no local install needed |
| CLI | - | - |
| SDK | Yes | Node.js SDK available |

## Authentication

- **Type**: API Key
- **Header**: `X-Api-Key: {api_key}`
- **Get key**: Settings > API in HeyGen dashboard

## MCP Server Setup

HeyGen provides a hosted remote MCP server. No local installation required.

### Claude Code / Claude Desktop

Add to your MCP config:

```json
{
  "mcpServers": {
    "heygen": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.heygen.com/mcp"]
    }
  }
}
```

On first use, authenticates via browser OAuth. The MCP server exposes tools for:
- Creating videos from scripts
- Listing and selecting avatars
- Managing templates
- Checking video status

## API Quick Start

### Create a Video

```bash
curl -X POST https://api.heygen.com/v2/video/generate \
  -H "X-Api-Key: YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "video_inputs": [{
      "character": {
        "type": "avatar",
        "avatar_id": "AVATAR_ID",
        "avatar_style": "normal"
      },
      "voice": {
        "type": "text",
        "input_text": "Your script goes here.",
        "voice_id": "VOICE_ID"
      }
    }],
    "dimension": {
      "width": 1920,
      "height": 1080
    }
  }'
```

### List Avatars

```bash
curl https://api.heygen.com/v2/avatars \
  -H "X-Api-Key: YOUR_API_KEY"
```

### Check Video Status

```bash
curl https://api.heygen.com/v1/video_status.get?video_id=VIDEO_ID \
  -H "X-Api-Key: YOUR_API_KEY"
```

## Common Marketing Use Cases

| Use Case | Approach |
|----------|----------|
| Product explainer | Script from features → avatar presents |
| Feature announcement | Template with avatar + screen recording |
| Multilingual content | Same script, different language/voice |
| Personalized outreach | Dynamic variables (name, company) in script |
| Weekly updates | Recurring template, swap script text |

## Custom Avatars

Upload a 2-5 minute video of yourself speaking to create a digital twin:
- Looks and sounds like you
- Generates unlimited videos from text scripts
- Available on Creator plan and above

## Pricing

| Plan | Videos/mo | Max Duration |
|------|-----------|-------------|
| Free | 3 | 3 min |
| Creator | Unlimited | 5 min |
| Business | Unlimited | 20 min |
| Enterprise | Unlimited | Custom |

Check [heygen.com/pricing](https://www.heygen.com/pricing) for current prices — they change frequently.

## Rate Limits

- Free: 3 videos/month
- Paid: Based on plan tier, concurrent generation limits apply
- API rate limits: Check response headers for `X-RateLimit-*`

## Relevant Skills

- video
- social
- ad-creative
- sales-enablement

## File: tools/integrations/heyreach.md

# HeyReach

Cloud LinkedIn outreach automation: runs connection requests, messages, InMails, and profile engagement across multiple LinkedIn sender accounts, with a shared inbox, campaign analytics, and native Instantly and Smartlead integrations for email + LinkedIn sequences.

Facts below were checked against [docs.heyreach.io](https://docs.heyreach.io/hey-reach-api) and HeyReach's [help center](https://help.heyreach.io/en/articles/12123398-how-to-integrate-heyreach-mcp-with-claude) on 2026-10-07.

> **Terms-of-service risk.** LinkedIn's User Agreement prohibits third-party automation, so any tool like this can get sender accounts restricted. LinkedIn also acts against vendors directly: in March 2026 it removed HeyReach's company page and several executives' profiles ([HeyReach's account](https://www.heyreach.io/blog/heyreach-ban)); HeyReach says the product kept working. Use only real profiles you own, stay well under weekly limits, and keep a manual fallback. See the `cold-email` skill's LinkedIn guidance before scaling.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Public REST API: LinkedIn accounts, lists, leads, campaigns, inbox, analytics, webhooks |
| MCP | ✓ | Official, per-workspace: Integrations > HeyReach MCP Server gives a connection URL and MCP key; authenticate with the workspace API key ([guide](https://help.heyreach.io/en/articles/12123398-how-to-integrate-heyreach-mcp-with-claude)). Several community MCP servers also exist |
| CLI | ✓ | HeyReach publishes a CLI for Mac and Windows ([heyreach.io/cli](https://www.heyreach.io/cli)) |
| SDK | - | API-only |

## Authentication

- **Type**: API key in the `X-API-KEY` header
- **Env var** (convention): `HEYREACH_API_KEY`
- **Get key**: HeyReach workspace settings > Integrations > API
- **Check a key**: `GET https://api.heyreach.io/api/public/auth/CheckApiKey`

## Common Agent Operations

Base URL: `https://api.heyreach.io/api/public`. Most endpoints are `POST`, including reads.

### Campaigns

```bash
# List campaigns
POST /campaign/GetAll

# Pause or resume
POST /campaign/Pause?campaignId=<id>
POST /campaign/Resume?campaignId=<id>
```

### Add leads to a campaign (up to 100 per request)

```bash
POST /campaign/AddLeadsToCampaignV2
X-API-KEY: $HEYREACH_API_KEY

{
  "campaignId": 12345,
  "accountLeadPairs": [
    { "lead": { "profileUrl": "https://www.linkedin.com/in/janedoe", "firstName": "Jane", "companyName": "Acme" } }
  ],
  "resumeFinishedCampaign": false,
  "resumePausedCampaign": false
}
```

Optionally pin a lead to a specific sender with `linkedInAccountId` in the pair. Custom field names may only contain letters, numbers, and underscores.

### Stop a lead when they reply on another channel

```bash
POST /campaign/StopLeadInCampaign
```

Call this from your reply handler when a prospect answers by email or books a meeting, so LinkedIn steps stop too.

### Inbox and replies

```bash
POST /inbox/GetConversationsV2   # conversations across sender accounts, filterable
POST /inbox/SendMessage          # reply in an existing conversation
```

Prefer webhooks (`/webhooks` endpoints) for reply events over polling the inbox.

### Analytics

```bash
POST /stats/GetOverallStats
```

Track acceptance rate, reply rate, and positive replies per sender and campaign. A falling acceptance rate is the earliest sign an account is at risk.

## Rate Limits

- 300 API requests per minute, shared across all requests; `429` when exceeded ([docs](https://docs.heyreach.io/hey-reach-api))
- LinkedIn action limits are a separate, bigger risk than API limits. HeyReach allows up to 40 connection requests a day and caps each sender at 200 a week, but recommends 25 a day for a warmed-up account (30 above 1,000 connections) ([help article](https://help.heyreach.io/en/articles/15128619-how-do-connection-request-limits-work-in-heyreach)). New or low-acceptance accounts should run far lower; many practitioners stay near 100 a week.

## Pricing

Priced per connected LinkedIn sender account. Current plans: [heyreach.io/pricing](https://www.heyreach.io/pricing).

## Alternatives

Expandi, La Growth Machine and lemlist (email + LinkedIn in one sequence), Waalaxy, Dripify, and Unipile (LinkedIn messaging API for builders). All carry the same LinkedIn terms-of-service risk.

## Relevant Skills

- cold-email (multichannel cadence and LinkedIn steps)
- prospecting (building the lead list with LinkedIn profile URLs)
- social (LinkedIn profile and content that raise acceptance)
- revops (logging LinkedIn touches and replies in the CRM)

## File: tools/integrations/hotjar.md

# Hotjar

Behavior analytics platform with heatmaps, session recordings, and surveys for understanding user experience.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Survey export and user lookup (Scale plans) |
| MCP | - | Not available |
| CLI | ✓ | [hotjar.js](../clis/hotjar.js) |
| SDK | ✓ | JavaScript tracking snippet, Identify API, Events API |

## Authentication

- **Type**: OAuth 2.0 Client Credentials
- **Token endpoint**: `POST https://api.hotjar.io/v1/oauth/token`
- **Header**: `Authorization: Bearer {access_token}`
- **Get credentials**: Hotjar Dashboard > Integrations > API
- **Token expiry**: 3600 seconds (1 hour)

### Token Request

```bash
POST https://api.hotjar.io/v1/oauth/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}
```

### Token Response

```json
{
  "access_token": "<token>",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

## Common Agent Operations

### List Surveys

```bash
GET https://api.hotjar.io/v1/sites/{site_id}/surveys

Authorization: Bearer {access_token}
```

### Get Survey Responses

```bash
GET https://api.hotjar.io/v1/sites/{site_id}/surveys/{survey_id}/responses?limit=100

Authorization: Bearer {access_token}
```

Supports cursor-based pagination with `cursor` and `limit` parameters.

The public API reference documents survey export and user lookup. It does not
provide the site-list, heatmap, recording, or form-export routes shown in the
legacy CLI commands. Those commands are not verified public API integrations;
use the dashboard for those workflows. Find site IDs in Sites & Organizations.

Survey export requires Ask Scale. API credentials expire after one year and
must be replaced. The documented public API version is `v1`.

```bash
node tools/clis/hotjar.js surveys list --site-id 42 --limit 25 --cursor '<next_cursor>'
node tools/clis/hotjar.js surveys responses --site-id 42 --survey-id '<survey_id>' --cursor '<next_cursor>'
```

Repeat the original command with the returned `next_cursor` to retrieve another
page. Request previews use the same URL and remain offline.

Source: [Hotjar API Reference](https://help.hotjar.com/hc/en-us/articles/36820005914001-Hotjar-API-Reference).

## Key Metrics

### Survey Response Data
- `response_id` - Unique response identifier
- `answers` - Array of question/answer pairs
- `created_at` - Response timestamp
- `device_type` - Desktop, mobile, tablet

## Parameters

### Surveys and Survey Responses
- `limit` - Results per page (CLI default: 100; API maximum: 100)
- `cursor` - The `next_cursor` returned by the previous page
- Responses are sorted by creation date descending; filtering by date is not supported.

## When to Use

- Analyzing user behavior patterns on landing pages
- Collecting qualitative feedback via on-site surveys
- Identifying UX issues through session recordings
- Understanding scroll depth and engagement via heatmaps
- Validating CRO hypotheses with user behavior data
- Form abandonment analysis

## Rate Limits

- 3000 requests/minute (50 per second)
- Rate limited by source IP address
- Cursor-based pagination for large result sets

## Relevant Skills

- cro
- ab-testing
- analytics
- ux-audit
- landing-page

## File: tools/integrations/hubspot.md

# HubSpot

CRM platform for marketing, sales, and customer service.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for CRM, Marketing, Sales |
| MCP | ✓ | Official remote server at `mcp.hubspot.com` (OAuth 2.1 + PKCE), GA since 2026-04-13 on all plans, read and write ([changelog](https://developers.hubspot.com/changelog/remote-hubspot-mcp-server-is-now-generally-available)) |
| CLI | ✓ | `hs` CLI for local development |
| SDK | ✓ | Official client libraries |

## Authentication

- **Type**: Private App Token or OAuth 2.0
- **Header**: `Authorization: Bearer {access_token}`
- **Get token**: Settings > Integrations > Private Apps

## Common Agent Operations

### Get contacts

```bash
GET https://api.hubapi.com/crm/v3/objects/contacts?limit=10

Authorization: Bearer {access_token}
```

### Search contacts

```bash
POST https://api.hubapi.com/crm/v3/objects/contacts/search

{
  "filterGroups": [{
    "filters": [{
      "propertyName": "email",
      "operator": "EQ",
      "value": "user@example.com"
    }]
  }]
}
```

### Create contact

```bash
POST https://api.hubapi.com/crm/v3/objects/contacts

{
  "properties": {
    "email": "user@example.com",
    "firstname": "John",
    "lastname": "Doe",
    "company": "Example Inc"
  }
}
```

### Update contact

```bash
PATCH https://api.hubapi.com/crm/v3/objects/contacts/{contact_id}

{
  "properties": {
    "lifecyclestage": "customer"
  }
}
```

### Get deals

```bash
GET https://api.hubapi.com/crm/v3/objects/deals?limit=10&properties=dealname,amount,dealstage

Authorization: Bearer {access_token}
```

### Create deal

```bash
POST https://api.hubapi.com/crm/v3/objects/deals

{
  "properties": {
    "dealname": "New Deal",
    "amount": "10000",
    "dealstage": "appointmentscheduled",
    "pipeline": "default"
  }
}
```

### Associate contact with deal

```bash
PUT https://api.hubapi.com/crm/v3/objects/deals/{deal_id}/associations/contacts/{contact_id}/deal_to_contact
```

### Get form submissions

```bash
GET https://api.hubapi.com/form-integrations/v1/submissions/forms/{form_guid}

Authorization: Bearer {access_token}
```

### Get marketing emails

```bash
GET https://api.hubapi.com/marketing/v3/emails?limit=10

Authorization: Bearer {access_token}
```

## CLI Commands

```bash
# Install
npm install -g @hubspot/cli

# Initialize project
hs init

# Upload files
hs upload src dest

# Watch for changes
hs watch src dest

# List portals
hs accounts list
```

## Key Objects

- **Contacts** - People in CRM
- **Companies** - Organizations
- **Deals** - Sales opportunities
- **Tickets** - Support tickets
- **Products** - Items for sale
- **Line Items** - Deal line items

## Common Properties

### Contact Properties
- `email` - Email address
- `firstname`, `lastname` - Name
- `lifecyclestage` - Funnel stage
- `hs_lead_status` - Lead status

### Deal Properties
- `dealname` - Deal name
- `amount` - Deal value
- `dealstage` - Pipeline stage
- `closedate` - Expected close

## When to Use

- Managing contacts and leads
- Tracking sales deals
- Marketing automation
- Form submissions
- Email campaigns
- Customer service tickets

## Rate Limits

- 100 requests per 10 seconds
- Higher limits on enterprise plans

## Relevant Skills

- emails
- analytics
- referrals

## File: tools/integrations/hunter.md

# Hunter.io

Email finding and verification: domain search (everyone with a public email at a company), email finder (name + domain), verifier, enrichment, a B2B company database (Discover), and simple sending campaigns. Used for sales prospecting, PR, and link building. Checked against [hunter.io/api-documentation](https://hunter.io/api-documentation/v2) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for domain search, email finder, verification |
| MCP | ✓ | Official server at `https://mcp.hunter.io/mcp`: API key in `X-API-Key`, or OAuth where the client supports it; all plans ([hunter.io/mcp](https://hunter.io/mcp)) |
| CLI | [✓](../clis/hunter.js) | Zero-dependency Node.js CLI |
| SDK | - | API-only |

## Authentication

- **Type**: API Key (query parameter)
- **Parameter**: `api_key={key}`
- **Env var**: `HUNTER_API_KEY`
- **Get key**: [Hunter dashboard > API](https://hunter.io/api-keys)

The CLI URL-encodes the credential and redacts the `api_key` parameter in
`--dry-run` previews, preserving the other query values. Previews do not make
API requests. See [Hunter's authentication reference](https://hunter.io/api-documentation/v2#authentication).

## Common Agent Operations

### Find emails for a domain

```bash
node tools/clis/hunter.js domain search --domain example.com --limit 10
```

### Find a specific person's email

```bash
node tools/clis/hunter.js email find --domain example.com --first-name John --last-name Doe
```

### Verify an email address

```bash
node tools/clis/hunter.js email verify --email john@example.com
```

### Count emails available for a domain

```bash
node tools/clis/hunter.js domain count --domain example.com
```

### Manage leads

```bash
# List leads
node tools/clis/hunter.js leads list --limit 20

# Create a lead
node tools/clis/hunter.js leads create --email john@example.com --first-name John --last-name Doe --company "Example Inc"

# Delete a lead
node tools/clis/hunter.js leads delete --id 12345
```

### Manage campaigns

```bash
# List campaigns
node tools/clis/hunter.js campaigns list

# Get campaign details
node tools/clis/hunter.js campaigns get --id 12345

# Start/pause a campaign
node tools/clis/hunter.js campaigns start --id 12345
node tools/clis/hunter.js campaigns pause --id 12345
```

### Check account usage

```bash
node tools/clis/hunter.js account info
```

## Rate Limits

- Free plan: 25 searches/month, 50 verifications/month
- Paid plans scale with tier
- Domain Search and Email Finder: 15 requests/second, 500/minute
- Email Verifier: 10 requests/second, 300/minute
- Discover: 5 requests/second, 50/minute

## Use Cases

- **Sales prospecting**: find the decision maker's email at each target account (one step in an enrichment waterfall), using Discover or Domain Search to list companies and people
- **Verification**: check emails before they enter a sequence; resolve catch-all results with a dedicated verifier before sending
- **Link building and PR**: find editors and site owners at target domains

Hunter's confidence score is a guide, not a guarantee. Verify every address before it reaches a sending tool, and keep hard bounces under 2%.

### Reading complete domain and lead-list results

The CLI accepts `--offset` and `--limit` on `domain search` and `leads-lists get`. Fetch each page explicitly, advancing the offset by the returned page size until the provider returns no further records. Existing omitted pagination retains the provider default; these commands do not automatically spend credits on subsequent pages.

```bash
node tools/clis/hunter.js domain search --domain example.com --limit 100 --offset 100
node tools/clis/hunter.js leads-lists get --id 123 --limit 100 --offset 100
```

The flags require nonnegative whole-number offsets and limits from 1 to 100. Provider entitlement and total-result limits still apply. See [Hunter’s V2 API reference](https://hunter.io/api-documentation).

## Relevant Skills

- prospecting
- cold-email
- public-relations

## File: tools/integrations/hyperframes.md

# Hyperframes

Open-source programmatic video framework from HeyGen. Create videos from HTML/CSS/JS — no React, no proprietary DSL. Designed for AI agent workflows.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | - | Library, not a hosted service |
| MCP | - | - |
| CLI | Yes | `npx hyperframes render` |
| SDK | Yes | `@hyperframes/producer` for rendering from code; the `hyperframes` package itself is CLI-only |

## Why Hyperframes

- **LLM-native**: AI models generate better HTML than React components — plain web standards, no framework DSL
- **Deterministic**: Same input always produces identical output (ideal for automation)
- **Open source**: Apache 2.0 license, zero per-render fees
- **Agent-friendly**: Any coding agent that can write HTML can create videos

## Install

```bash
npx hyperframes <command>          # or: npm install -g hyperframes
```

Requires Node.js 22+ and FFmpeg. The `hyperframes` package is a **CLI only**; it has no importable API. For rendering from your own code, use `@hyperframes/producer` (below). Checked against v0.8.114, Oct 2026.

## Quick Start (CLI)

```bash
npx hyperframes init my-video        # scaffold a project from a template
cd my-video
npx hyperframes preview              # live preview in the Studio (localhost:3002)
npx hyperframes render -o output.mp4 # render the project's index.html
npx hyperframes render -c ./promo.html -o promo.mp4   # render a specific composition
npx hyperframes lint .               # catch composition errors before rendering
```

## How a Composition Works

A composition is an HTML file. The root element declares the canvas and total length, each visible element is a **clip** with its own start, duration, and track, and animation runs on a paused GSAP timeline that Hyperframes drives frame by frame. This is the shape of the package's own `blank` template:

```html
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>

<div id="root" data-composition-id="main"
     data-start="0" data-duration="8" data-width="1080" data-height="1920">
  <h1 id="title" class="clip" data-start="0" data-duration="4" data-track-index="0">Welcome to Acme</h1>
  <p id="cta" class="clip" data-start="4" data-duration="4" data-track-index="0">Try it free</p>
</div>

<script>
  const tl = gsap.timeline({ paused: true });
  tl.fromTo("#title", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.6 }, 0);
  tl.fromTo("#cta", { opacity: 0 }, { opacity: 1, duration: 0.4 }, 4);
  window.__timelines["main"] = tl;
  tl.seek(0);
</script>
```

- **Timing** lives in `data-start` and `data-duration` (seconds). `data-track-index` layers clips that overlap.
- **Size** comes from `data-width` and `data-height` on the root; set the page's `html, body` to the same size in CSS.
- **Animation** goes on the GSAP timeline, keyed to the same start times. Register it under the composition's id.
- Run `npx hyperframes lint` after editing; it catches missing attributes and timing mistakes.

## Rendering from Code

```typescript
import { createRenderJob, executeRenderJob } from "@hyperframes/producer";

const job = createRenderJob({ fps: 30, quality: "standard" });
await executeRenderJob(job, "./my-video", "./output.mp4");
```

`createRenderJob` takes the render settings (`fps` and `quality` are required; `entryFile`, `format`, `variables`, and others are optional). `executeRenderJob` takes the job, the project directory, and the output path.

## Data-Driven Videos

For batch or personalized videos, generate one composition per row (a changelog entry, a customer, a metric), then render each:

1. Keep one hand-built composition as the template.
2. For each row, write a copy with the row's text, numbers, and images filled in, and the clip timings adjusted if the content length changes.
3. Lint, then render each file with `npx hyperframes render -c <file> -o <name>.mp4` or `executeRenderJob` in a loop.

Product announcements, changelog videos, testimonial cards, and stat reveals all fit this pattern: a short sequence of clips with text, an image or two, and one or two GSAP moves each.

## Aspect Ratios

| Platform | Width | Height | Ratio |
|----------|-------|--------|-------|
| TikTok/Reels/Shorts | 1080 | 1920 | 9:16 |
| YouTube | 1920 | 1080 | 16:9 |
| Instagram Feed | 1080 | 1080 | 1:1 |
| Instagram Feed | 1080 | 1350 | 4:5 |

## Hyperframes vs. Remotion

| Factor | Hyperframes | Remotion |
|--------|-------------|----------|
| Language | HTML/CSS/JS | React/TypeScript |
| Agent compatibility | Better (plain HTML) | Good (needs React knowledge) |
| Animation | GSAP timeline (plus CSS) | Spring physics, interpolation |
| Cloud rendering | Not built-in | Lambda (AWS) |
| License | Apache 2.0 (free) | Company license for commercial use |
| Ecosystem | New, growing | Mature, large community |

**Use Hyperframes when:** AI agent is generating the video, simple animations, batch templated content, cost-sensitive.

**Use Remotion when:** Complex animations needed, already using React, need Lambda for massive scale, want larger ecosystem.

## Relevant Skills

- video
- social
- ad-creative

## File: tools/integrations/instantly.md

# Instantly

Cold email sending platform: campaigns and sequences, sending-account management with warmup, inbox rotation, a shared reply inbox (Unibox), lead lists, a built-in lead database (SuperSearch), and inbox placement tests.

API facts below were checked against [developer.instantly.ai](https://developer.instantly.ai/api-reference/introduction) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2. v1 was deprecated on 2026-01-19 ([migration guide](https://developer.instantly.ai/guides/api-v1-migration)) |
| MCP | ✓ | Official hosted server at `https://mcp.instantly.ai/mcp`, exposing the full v2 API as tools ([docs](https://developer.instantly.ai/mcp/introduction)) |
| CLI | [✓](../clis/instantly.js) | Zero-dependency Node.js CLI (API v2) |
| SDK | - | API-only |

## Authentication

- **Type**: Bearer token (`Authorization: Bearer <key>`), with scoped API keys
- **Env var**: `INSTANTLY_API_KEY`
- **Get key**: Instantly Settings > Integrations > API. Create a v2 key; v1 keys don't work with v2.
- **MCP**: send the same key as an `Authorization` header (preferred) or `x-instantly-api-key`. Avoid the URL-embedded key option; it ends up in logs. Because the MCP takes an API key rather than per-user OAuth, it also works for scheduled, unattended agent runs.

## Common Agent Operations

### Campaigns

```bash
node tools/clis/instantly.js campaigns list --limit 20
node tools/clis/instantly.js campaigns get --id <campaign-id>
node tools/clis/instantly.js campaigns activate --id <campaign-id>
node tools/clis/instantly.js campaigns pause --id <campaign-id>

# Why is a campaign not sending (or sending slowly)?
node tools/clis/instantly.js campaigns sending-status --id <campaign-id>
```

### Leads

Verify every list before it goes in (see the `prospecting` skill and the [Truelist guide](truelist.md)).

```bash
# Add one lead to a campaign
node tools/clis/instantly.js leads add --campaign-id <id> --email jane@acme.com \
  --first-name Jane --company "Acme" --job-title "VP Marketing" --skip-if-in-workspace

# Add up to 1,000 leads from a JSON file
node tools/clis/instantly.js leads bulk-add --campaign-id <id> --file leads.json --skip-if-in-workspace

# List leads in a campaign (cursor pagination)
node tools/clis/instantly.js leads list --campaign-id <id> --limit 100

# Record a reply outcome
node tools/clis/instantly.js leads interest --email jane@acme.com --status meeting-booked
```

Interest statuses: `interested`, `meeting-booked`, `meeting-completed`, `won`, `out-of-office`, `not-interested`, `wrong-person`, `lost`, `no-show`.

### Replies

```bash
# Received emails, newest first (filter to a campaign, or unread only)
node tools/clis/instantly.js emails replies --campaign-id <id> --unread
node tools/clis/instantly.js emails unread-count
```

For near-real-time reply handling, use Instantly's [webhooks](https://developer.instantly.ai/guides/webhook-events) (reply, interest-change, and bounce events) instead of polling.

### Sending accounts and warmup

```bash
node tools/clis/instantly.js accounts list --limit 50
node tools/clis/instantly.js accounts get --email sender@yourdomain.com
node tools/clis/instantly.js accounts warmup-analytics --emails sender1@yourdomain.com,sender2@yourdomain.com
```

### Analytics

```bash
node tools/clis/instantly.js analytics campaign --campaign-id <id> --start-date 2026-09-01 --end-date 2026-09-30
node tools/clis/instantly.js analytics overview
node tools/clis/instantly.js analytics steps --campaign-id <id>
```

Judge campaigns on replies, positive replies, and meetings. Open rates are unreliable since Apple Mail Privacy Protection, and many teams turn open tracking off for cold email.

### Blocklist (suppression)

```bash
node tools/clis/instantly.js blocklist list --search acme.com
node tools/clis/instantly.js blocklist add --entries "customer.com,unsubscribed@example.com"
```

Keep customers, open deals, competitors, and everyone who opted out on any channel in the blocklist.

## Rate Limits

- 100 requests per second and 6,000 per minute, shared across the whole workspace and all its API keys (v1 and v2 combined). Exceeding either returns `429`.
- A few endpoints are slower: listing emails is 20 requests per minute; sending a test email is 10 per minute.
- Source: [Rate limit docs](https://developer.instantly.ai/getting-started/rate-limit)

## Other API surfaces

Not wrapped by the CLI; call them through the MCP or the API directly:
- **Inbox placement tests** (seed tests across providers before launching a campaign)
- **Lead lists** and verification statistics per list
- **SuperSearch** lead database and enrichment
- **Done-for-you domains and mailboxes**, with domain availability checks
- **Webhooks** and custom tags

## Use Cases

- **Sales outbound**: run cold email campaigns to verified, segmented lists, from secondary domains with warmed sending accounts
- **Reply triage**: pull received replies, classify them, and set interest status so stopped leads leave the sequence
- **Deliverability monitoring**: check warmup analytics, account vitals, sending status, and placement tests before scaling volume
- **Link building and PR outreach**: the same campaign mechanics work for backlink and press outreach

## Relevant Skills

- cold-email
- prospecting
- revops
- marketing-loops

## File: tools/integrations/intercom.md

# Intercom

Customer messaging and support platform API for managing contacts, conversations, messages, companies, articles, and tags.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v2.11+ - contacts, conversations, messages, companies, articles, tags |
| MCP | - | Not available |
| CLI | ✓ | [intercom.js](../clis/intercom.js) |
| SDK | ✓ | Node.js, Ruby, Python, PHP, Go |

## Authentication

- **Type**: Bearer Token (Access Token or OAuth 2.0)
- **Header**: `Authorization: Bearer {token}`
- **Version Header**: `Intercom-Version: 2.11`
- **Get key**: Developer Hub at https://app.intercom.com/a/apps/_/developer-hub

## Common Agent Operations

### List contacts

```bash
GET https://api.intercom.io/contacts
```

### Get a contact

```bash
GET https://api.intercom.io/contacts/{id}
```

### Create a contact

```bash
POST https://api.intercom.io/contacts

{
  "role": "user",
  "email": "user@example.com",
  "name": "Jane Doe",
  "custom_attributes": {
    "plan": "pro"
  }
}
```

### Update a contact

```bash
PUT https://api.intercom.io/contacts/{id}

{
  "name": "Jane Smith",
  "custom_attributes": {
    "plan": "enterprise"
  }
}
```

### Search contacts

```bash
POST https://api.intercom.io/contacts/search

{
  "query": {
    "field": "email",
    "operator": "=",
    "value": "user@example.com"
  }
}
```

### Delete a contact

```bash
DELETE https://api.intercom.io/contacts/{id}
```

### List conversations

```bash
GET https://api.intercom.io/conversations
```

### Get a conversation

```bash
GET https://api.intercom.io/conversations/{id}
```

### Search conversations

```bash
POST https://api.intercom.io/conversations/search

{
  "query": {
    "field": "open",
    "operator": "=",
    "value": true
  }
}
```

### Reply to a conversation

```bash
POST https://api.intercom.io/conversations/{id}/reply

{
  "message_type": "comment",
  "type": "admin",
  "admin_id": "{admin_id}",
  "body": "Thanks for reaching out!"
}
```

### Create a message

```bash
POST https://api.intercom.io/messages

{
  "message_type": "inapp",
  "body": "Welcome to our platform!",
  "from": {
    "type": "admin",
    "id": "{admin_id}"
  },
  "to": {
    "type": "user",
    "id": "{user_id}"
  }
}
```

### List companies

```bash
GET https://api.intercom.io/companies
```

### Create or update a company

```bash
POST https://api.intercom.io/companies

{
  "company_id": "company_123",
  "name": "Acme Corp",
  "plan": "enterprise",
  "custom_attributes": {
    "industry": "Technology"
  }
}
```

### List tags

```bash
GET https://api.intercom.io/tags
```

### Create a tag

```bash
POST https://api.intercom.io/tags

{
  "name": "VIP Customer"
}
```

### Tag a contact

```bash
POST https://api.intercom.io/contacts/{contact_id}/tags

{
  "id": "{tag_id}"
}
```

### List articles

```bash
GET https://api.intercom.io/articles
```

### Create an article

```bash
POST https://api.intercom.io/articles

{
  "title": "Getting Started Guide",
  "body": "<p>Welcome to our platform...</p>",
  "author_id": "{admin_id}",
  "state": "published"
}
```

### List admins

```bash
GET https://api.intercom.io/admins
```

### Submit events

```bash
POST https://api.intercom.io/events

{
  "event_name": "purchased-item",
  "created_at": 1706140800,
  "user_id": "user_123",
  "metadata": {
    "item_name": "Pro Plan",
    "price": 99.00
  }
}
```

## Key Metrics

### Contact Data
- `id` - Unique contact identifier
- `role` - user or lead
- `email` - Contact email
- `name` - Contact name
- `created_at` / `updated_at` - Timestamps
- `last_seen_at` - Last activity
- `custom_attributes` - Custom data fields
- `tags` - Applied tags
- `companies` - Associated companies

### Conversation Data
- `id` - Conversation identifier
- `state` - open, closed, snoozed
- `open` - Boolean open status
- `read` - Read status
- `priority` - Priority level
- `statistics` - Response times, counts
- `conversation_parts` - Message history

## Parameters

### List Contacts
- `per_page` - Results per page (default 50, max 150)
- `starting_after` - Pagination cursor

### List Conversations
- `per_page` - Results per page (default 20, max 150)
- `starting_after` - Pagination cursor

### Search (Contacts & Conversations)
- `query.field` - Field to search
- `query.operator` - Comparison operator (=, !=, >, <, ~, IN, NIN)
- `query.value` - Search value
- `pagination.per_page` - Results per page
- `pagination.starting_after` - Cursor for next page
- `sort.field` / `sort.order` - Sort configuration

### CLI search values and pagination

`--value` preserves a string, including identifiers such as `0012`. Use
`--value-json` for numbers, booleans, or arrays required by the search field
and operator. Invalid JSON is rejected before making a request.

```bash
node tools/clis/intercom.js contacts search --field created_at --operator '>' --value-json 1700000000
node tools/clis/intercom.js conversations search --field open --value-json false
node tools/clis/intercom.js contacts search --field id --operator IN --value-json '["0012","0034"]'
```

To retrieve another search page, repeat the original filter and pass the returned
`pages.next.starting_after` as `--starting-after`, optionally with `--per-page`.
Both flags are sent inside the search request's `pagination` object.

API contracts: [contact search](https://developers.intercom.com/docs/references/2.11/rest-api/api.intercom.io/contacts/searchcontacts)
and [conversation search](https://developers.intercom.com/docs/references/2.11/rest-api/api.intercom.io/conversations/searchconversations).

## When to Use

- Managing customer contact records and segments
- Automating customer messaging and onboarding
- Monitoring and responding to support conversations
- Tracking customer events and behavior
- Building custom support workflows
- Syncing customer data between platforms

## Rate Limits

- **Default**: 10,000 API calls per minute per app
- **Per workspace**: 25,000 API calls per minute
- Distributed in 10-second windows (resets every 10 seconds)
- Headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
- HTTP 429 returned when exceeded

## Relevant Skills

- customer-onboarding
- customer-retention
- lead-generation
- customer-support
- in-app-messaging

## CLI message creation

The message creation API uses `in_app` for in-app requests (its response enum
uses `inapp`). The CLI defaults to `in_app` and keeps `--type inapp` as an alias.
Email messages require a subject and a `plain` or `personal` template; the CLI
defaults the email template to `plain`.

```bash
node tools/clis/intercom.js messages create --body "Welcome" --admin-id 123 --to user1
node tools/clis/intercom.js messages create --type email --subject "Welcome" --body "Hello" --admin-id 123 --to user1 --template personal
```

Contract: [Create a message, API 2.11](https://developers.intercom.com/docs/references/2.11/rest-api/api.intercom.io/messages/createmessage).

## File: tools/integrations/introw.md

# Introw PRM

Partner Relationship Management platform for managing channel partners, tracking partner-sourced deals, commissions, tasks, and engagement — with built-in business review generation.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | - | Not available |
| MCP | ✓ | Full read/write via Claude connector |
| CLI | - | Not available |
| SDK | - | Not available |

## Authentication

- **Type**: OAuth2 (via MCP connector)
- **Setup**: Connect via Claude MCP connector — no API key management needed
- **Scope**: All data is scoped to the authenticated organisation

## Common Agent Operations

All operations are performed via MCP tools. The following are the primary tool calls available.

### Search Partners

```
search_partners
  dateRange: { field: "CREATED_AT" | "LAST_ACTIVITY_AT", from: "YYYY-MM-DD", to: "YYYY-MM-DD" }
```

Returns: partner name/ID, contact info, tier, lifecycle stage, categories, country, last activity date.

### Search CRM Objects (Deals, Tickets, Leads, Companies, Contacts)

```
search_crm_objects
  objectType: "DEAL" | "TICKET" | "LEAD" | "COMPANY" | "CONTACT"
  stage: "OPEN" | "WON" | "LOST"
  view: "ALL" | "DUE" | "OVERDUE" | "INACTIVE"
  rollingDateFilter: { field: "CLOSED_AT", value: "THIS_QUARTER" }
  sortBy: { property: "AMOUNT", direction: "DESC" }
  limit: 10
```

Synonym mapping: Opportunity/Forecast → `DEAL`, Account → `COMPANY`, Case → `TICKET`.

### Search Tasks

```
search_tasks
  status: "TODO" | "IN_PROGRESS" | "PENDING" | "COMPLETED" | "DONE"
  partnerId: "{partner_id}"
```

### Search Commissions

```
search_commissions
  partnerId: "{partner_id}"
```

Returns: commission amounts, currency, payment status, associated partner and deals.

### Generate Business Review (QBR/MBR/WBR)

```
generate_business_review
  duration: "QUARTERLY" | "MONTHLY" | "WEEKLY"
  partnerId: "{partner_id}"
```

Returns: pipeline & forecast analysis, form submissions overview, mutual action plan, goal tracking, timed agenda and next steps.

### Search Partner Engagement

```
search_partner_engagement
  partnerId: "{partner_id}"
  type: "ROOM_VISIT" | "OBJECT_SHARE" | "COMMENT" | "FORM_SUBMIT" | "TASK_CREATED" | ...
  dateRange: { from: "YYYY-MM-DD", to: "YYYY-MM-DD" }
```

Returns: comments, deal updates, asset views, task events, portal visits, form submissions, announcements, quotes.

### Add Comment to Deal/Object

```
add_comment
  comment: "Comment text"
  objectId: "{crm_object_id}"
  objectType: "DEAL" | "TICKET" | "LEAD" | "COMPANY" | "CONTACT"
```

### Create or Update Tasks

```
add_task
  name: "Task title"
  dueDate: "2025-02-20"
  assignedTo: "PARTNER" | "ORGANISATION"
  partnerId: "{partner_id}"

update_task
  taskId: 123
  status: "TODO" | "IN_PROGRESS" | "DONE"
```

### Update CRM Object Properties

```
update_crm_object
  objectId: "{crm_object_id}"
  objectType: "DEAL"
  propertiesToUpdate: { "amount": 50000, "stage": "Negotiation" }
```

### Share Lead or Register Deal

Two-step flow:
1. **Discovery**: provide `objectType` and `callToAction` to get form fields
2. **Submit**: provide `formId` and `userProvidedData` to submit

```
share_lead_or_register_deal
  objectType: "Deal"
  callToAction: "Register Deal"
  partnerId: "{partner_id}"
```

## Key Metrics

### Partner Data
- `id` - Partner ID
- `name` - Partner company name
- `championEmail` - Primary contact email
- `tier` - Current tier level
- `lifecycleStage` - Partner lifecycle stage
- `categories` - Partner categories
- `country` - Partner country
- `lastActivityAt` - Last activity date

### CRM Object Data
- `objectId` - External CRM ID
- `objectType` - DEAL, TICKET, LEAD, COMPANY, CONTACT
- `stage` - OPEN, WON, LOST
- `amount` - Deal amount
- `closeDate` - Expected close date

### Commission Data
- `amount` - Commission amount
- `currency` - Payment currency
- `paymentStatus` - Current payment status
- `partnerId` - Associated partner
- `dealId` - Associated deal

### Engagement Data
- `type` - Activity type (ROOM_VISIT, COMMENT, FORM_SUBMIT, etc.)
- `partnerId` - Partner involved
- `crmObjectId` - Related CRM object
- `createdAt` - Activity timestamp

## When to Use

- Managing channel partner relationships and tracking partner activity
- Reviewing partner-sourced pipeline (deals, leads, opportunities)
- Preparing QBR/MBR/WBR meetings with automated business review generation
- Tracking partner commissions and payouts
- Managing mutual action plans via tasks assigned to partners or internal teams
- Processing deal registrations and lead sharing from partners
- Monitoring partner portal engagement and content asset views

## Rate Limits

- Rate limits managed by the MCP connector
- All data scoped to authenticated organisation

## Relevant Skills

- revops
- sales-enablement
- referrals
- competitors

## File: tools/integrations/keywords-everywhere.md

# Keywords Everywhere

Keyword research API for search volume, CPC, competition, related keywords, and traffic data.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for keyword data, related keywords, traffic |
| MCP | - | Community MCP server available |
| CLI | ✓ | [keywords-everywhere.js](../clis/keywords-everywhere.js) |
| SDK | - | API-only |

## Authentication

- **Type**: API Key (Bearer token)
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: https://keywordseverywhere.com/first-install-addon.html
- **Limit**: 100 keywords per request

## Common Agent Operations

### Get keyword data (volume, CPC, competition)

```bash
POST https://api.keywordseverywhere.com/v1/get_keyword_data

Authorization: Bearer {api_key}

{
  "country": "us",
  "currency": "USD",
  "dataSource": "gkp",
  "kw": ["email marketing", "marketing automation", "crm software"]
}
```

### Get related keywords

```bash
POST https://api.keywordseverywhere.com/v1/get_related_keywords

Authorization: Bearer {api_key}

{
  "keyword": "email marketing",
  "num": 5
}
```

### Get "People Also Search For" keywords

```bash
POST https://api.keywordseverywhere.com/v1/get_pasf_keywords

Authorization: Bearer {api_key}

{
  "keyword": "email marketing",
  "num": 5
}
```

Related and PASF suggestions each take one seed in `keyword`, with optional `num`
for the number of suggestions. The CLI accepts `--keyword`; `--kw` remains a scalar
alias for these two commands. Use comma-separated `--kw` only with `keywords data`.

```bash
node tools/clis/keywords-everywhere.js keywords related --keyword "email marketing" --num 5 --dry-run
node tools/clis/keywords-everywhere.js keywords pasf --keyword "email marketing" --num 5 --dry-run
```

Official request examples: [Related keywords](https://api.keywordseverywhere.com/docs/keyword_data/get_related_keywords.md),
[PASF keywords](https://api.keywordseverywhere.com/docs/keyword_data/get_pasf_keywords.md).

### Get domain keywords (what a domain ranks for)

```bash
POST https://api.keywordseverywhere.com/v1/get_domain_keywords

Authorization: Bearer {api_key}

{
  "country": "us",
  "currency": "USD",
  "domain": "example.com"
}
```

### Get URL keywords (what a specific URL ranks for)

```bash
POST https://api.keywordseverywhere.com/v1/get_url_keywords

Authorization: Bearer {api_key}

{
  "country": "us",
  "currency": "USD",
  "url": "https://example.com/page"
}
```

### Get domain traffic

```bash
POST https://api.keywordseverywhere.com/v1/get_domain_traffic

Authorization: Bearer {api_key}

{
  "country": "us",
  "domain": "example.com"
}
```

### Get URL traffic

```bash
POST https://api.keywordseverywhere.com/v1/get_url_traffic

Authorization: Bearer {api_key}

{
  "country": "us",
  "url": "https://example.com/page"
}
```

### Get domain backlinks

```bash
POST https://api.keywordseverywhere.com/v1/get_domain_backlinks

Authorization: Bearer {api_key}

{
  "domain": "example.com"
}
```

### Get page backlinks

```bash
POST https://api.keywordseverywhere.com/v1/get_page_backlinks

Authorization: Bearer {api_key}

{
  "url": "https://example.com/page"
}
```

### Check credits

```bash
GET https://api.keywordseverywhere.com/v1/get_credits

Authorization: Bearer {api_key}
```

### Get supported countries

```bash
GET https://api.keywordseverywhere.com/v1/get_countries

Authorization: Bearer {api_key}
```

### Get supported currencies

```bash
GET https://api.keywordseverywhere.com/v1/get_currencies

Authorization: Bearer {api_key}
```

## Key Metrics

### Keyword Data
- `vol` - Monthly search volume
- `cpc.value` - Cost per click
- `competition` - Competition score
- `trend` - 12-month trend data

### Traffic Data
- `estimated_traffic` - Estimated monthly traffic
- `keywords_count` - Number of ranking keywords

## Parameters

- `country` - Country code (us, uk, de, fr, etc.)
- `currency` - Currency code (USD, GBP, EUR, etc.)
- `dataSource` - Data source, default `gkp` (Google Keyword Planner)
- `kw` - Array of keywords (max 100 per request)

## When to Use

- Quick keyword research with volume and CPC
- Finding related keywords and PASF suggestions
- Analyzing domain/URL keyword rankings
- Traffic estimation for domains and pages
- Backlink discovery

## Rate Limits

- 100 keywords per request
- Credit-based pricing (1 credit per keyword)

## Relevant Skills

- seo-audit
- content-strategy
- programmatic-seo
- competitors

## File: tools/integrations/kit.md

# Kit (formerly ConvertKit)

Email marketing platform for creators and newsletter businesses.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for subscribers, forms, sequences |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | JavaScript, Ruby gems available |

## Authentication

- **Type**: API Key or API Secret
- **Parameter**: `api_key={key}` or `api_secret={secret}` in query/body
- **Get key**: Settings > Advanced in Kit dashboard

## Common Agent Operations

### List subscribers

```bash
GET https://api.convertkit.com/v3/subscribers?api_secret={api_secret}&page=1

```

### Get subscriber

```bash
GET https://api.convertkit.com/v3/subscribers/{subscriber_id}?api_secret={api_secret}
```

### Add subscriber to form

```bash
POST https://api.convertkit.com/v3/forms/{form_id}/subscribe

{
  "api_key": "{api_key}",
  "email": "user@example.com",
  "first_name": "John",
  "fields": {
    "company": "Example Inc"
  }
}
```

### Add subscriber to sequence

```bash
POST https://api.convertkit.com/v3/sequences/{sequence_id}/subscribe

{
  "api_key": "{api_key}",
  "email": "user@example.com"
}
```

### Tag subscriber

```bash
POST https://api.convertkit.com/v3/tags/{tag_id}/subscribe

{
  "api_key": "{api_key}",
  "email": "user@example.com"
}
```

### Remove tag from subscriber

```bash
DELETE https://api.convertkit.com/v3/subscribers/{subscriber_id}/tags/{tag_id}?api_secret={api_secret}
```

### Update subscriber

```bash
PUT https://api.convertkit.com/v3/subscribers/{subscriber_id}

{
  "api_secret": "{api_secret}",
  "first_name": "Jane",
  "fields": {
    "plan": "pro"
  }
}
```

### Unsubscribe

```bash
PUT https://api.convertkit.com/v3/unsubscribe

{
  "api_secret": "{api_secret}",
  "email": "user@example.com"
}
```

### List forms

```bash
GET https://api.convertkit.com/v3/forms?api_key={api_key}
```

### List sequences

```bash
GET https://api.convertkit.com/v3/sequences?api_key={api_key}
```

### List tags

```bash
GET https://api.convertkit.com/v3/tags?api_key={api_key}
```

### Create broadcast

```bash
POST https://api.convertkit.com/v3/broadcasts

{
  "api_secret": "{api_secret}",
  "subject": "Newsletter Subject",
  "content": "<p>Email content here</p>",
  "email_layout_template": "default"
}
```

## Key Concepts

- **Subscribers** - Email contacts
- **Forms** - Signup forms
- **Sequences** - Automated email series
- **Tags** - Subscriber labels
- **Broadcasts** - One-time sends
- **Custom Fields** - Subscriber attributes

## Subscriber States

- `active` - Can receive emails
- `unsubscribed` - Opted out
- `bounced` - Email bounced
- `complained` - Marked as spam
- `inactive` - Cold subscriber

## When to Use

- Creator/newsletter businesses
- Simple email automation
- Form-based list building
- Tagging and segmentation
- Course email sequences

## Rate Limits

- 120 requests per minute
- Batch endpoints available

## Relevant Skills

- emails
- content-strategy

## File: tools/integrations/klaviyo.md

# Klaviyo

E-commerce email and SMS marketing platform with profiles, flows, campaigns, segments, and event tracking.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API with JSON:API spec, revision-versioned |
| MCP | - | Not available |
| CLI | ✓ | [klaviyo.js](../clis/klaviyo.js) |
| SDK | ✓ | Python, Node.js, Ruby, PHP, Java, C# |

## Authentication

- **Type**: Private API Key
- **Header**: `Authorization: Klaviyo-API-Key {private_api_key}`
- **Revision Header**: `revision: 2024-10-15` (required on all requests)
- **Get key**: Account Settings > API Keys at https://www.klaviyo.com/settings/account/api-keys
- **Note**: Private keys are prefixed with `pk_`; public keys (6-char site ID) are for client-side only

## Common Agent Operations

### List profiles

```bash
GET https://a.klaviyo.com/api/profiles/?page[size]=20

# Filter by email
GET https://a.klaviyo.com/api/profiles/?filter=equals(email,"user@example.com")
```

### Create profile

```bash
POST https://a.klaviyo.com/api/profiles/

{
  "data": {
    "type": "profile",
    "attributes": {
      "email": "user@example.com",
      "first_name": "Jane",
      "last_name": "Doe",
      "phone_number": "+15551234567"
    }
  }
}
```

### Update profile

```bash
PATCH https://a.klaviyo.com/api/profiles/{profileId}/

{
  "data": {
    "type": "profile",
    "id": "{profileId}",
    "attributes": {
      "first_name": "Updated Name"
    }
  }
}
```

### List all lists

```bash
GET https://a.klaviyo.com/api/lists/
```

### Create list

```bash
POST https://a.klaviyo.com/api/lists/

{
  "data": {
    "type": "list",
    "attributes": {
      "name": "Newsletter Subscribers"
    }
  }
}
```

### Add profiles to list

```bash
POST https://a.klaviyo.com/api/lists/{listId}/relationships/profiles/

{
  "data": [
    { "type": "profile", "id": "{profileId1}" },
    { "type": "profile", "id": "{profileId2}" }
  ]
}
```

### Track event

The monetary event `value` belongs in `data.attributes`, alongside `properties`. Custom event properties do not set the metric's monetary value. See the [Create Event API](https://developers.klaviyo.com/en/v2024-10-15/reference/create_event).

```bash
POST https://a.klaviyo.com/api/events/

{
  "data": {
    "type": "event",
    "attributes": {
      "metric": {
        "data": {
          "type": "metric",
          "attributes": { "name": "Placed Order" }
        }
      },
      "profile": {
        "data": {
          "type": "profile",
          "attributes": { "email": "user@example.com" }
        }
      },
      "value": 99.99,
      "properties": {
        "items": ["Product A"]
      },
      "time": "2025-01-15T10:00:00Z"
    }
  }
}
```

### List campaigns

```bash
GET https://a.klaviyo.com/api/campaigns/?filter=equals(messages.channel,"email")
```

### List flows

```bash
GET https://a.klaviyo.com/api/flows/
```

### Update flow status

```bash
PATCH https://a.klaviyo.com/api/flows/{flowId}/

{
  "data": {
    "type": "flow",
    "id": "{flowId}",
    "attributes": {
      "status": "live"
    }
  }
}
```

### List metrics

```bash
GET https://a.klaviyo.com/api/metrics/
```

### List segments

```bash
GET https://a.klaviyo.com/api/segments/
```

## API Pattern

Klaviyo uses the JSON:API specification. All request/response bodies use `{ "data": { "type": "...", "attributes": {...} } }` format. Relationships are managed via `/relationships/` sub-endpoints. The `revision` header is required on every request and determines API behavior version.

## Key Metrics

### Profile Fields
- `email` - Email address
- `phone_number` - Phone for SMS
- `first_name`, `last_name` - Name fields
- `properties` - Custom properties object
- `subscriptions` - Email/SMS subscription status

### Event Fields
- `metric` - The metric/event name
- `properties` - Custom event properties
- `time` - Event timestamp
- `value` - Monetary value (for revenue tracking)

### Campaign/Flow Metrics
- `send_count` - Number of sends
- `open_rate` - Open percentage
- `click_rate` - Click percentage
- `revenue` - Attributed revenue

## Parameters

### Common Query Parameters
- `page[size]` - Results per page (default 20, max 100)
- `page[cursor]` - Cursor for pagination
- `filter` - Filter expressions (e.g., `equals(email,"user@example.com")`)
- `sort` - Sort field (prefix `-` for descending)
- `include` - Include related resources
- `fields[resource]` - Sparse fieldsets

## When to Use

- E-commerce email/SMS marketing automation
- Syncing customer profiles from external systems
- Tracking purchase events and customer behavior
- Managing email flows and drip campaigns
- Segmenting audiences for targeted campaigns
- Reporting on campaign and flow performance

## Rate Limits

- Steady-state: 75 requests/second for most endpoints
- Burst: up to 700 requests in 1 minute
- Rate limit headers: `RateLimit-Limit`, `RateLimit-Remaining`, `RateLimit-Reset`
- Lower limits on some write endpoints (profiles, events)

## Relevant Skills

- emails
- ecommerce-email
- lifecycle-marketing
- customer-segmentation

## Structured event properties

For product arrays and typed event fields, use a JSON object instead of the
flat `--property key:value,key:value` shorthand:

```bash
node tools/clis/klaviyo.js events create --metric "Placed Order" --email buyer@example.com \
  --properties '{"items":[{"SKU":"sku-1","quantity":2}],"VIP":true}' --value 42.50 --dry-run
```

`--properties` preserves JSON types and nested values; it cannot be combined
with `--property`. The CLI retains the existing API revision. API acceptance
and eligibility for segmentation are separate: Klaviyo excludes some values
(such as zero, null and empty strings) from segmentation. See the official
[Create Event API](https://developers.klaviyo.com/en/reference/create_event).

## File: tools/integrations/leadmagic.md

# LeadMagic

B2B data API priced in credits: email finding and validation, mobile numbers, person and company profiles, job-change detection, technographics, funding, lookalike companies, job postings (hiring signals), and competitor ad libraries.

Facts below were checked against [leadmagic.io/docs](https://leadmagic.io/docs/v1/introduction), its [OpenAPI spec](https://leadmagic.io/openapi.json), and the [credits page](https://leadmagic.io/docs/v1/credits) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API: people, email, company, jobs, ads, credits |
| MCP | ✓ | Official hosted server at `https://mcp.leadmagic.io/mcp`, OAuth only (static API keys aren't supported in MCP config) ([docs](https://leadmagic.io/docs/mcp/introduction)) |
| CLI | ✓ | Official `lm-tui` (installs the `lm` command) for local CSV enrichment ([docs](https://leadmagic.io/docs/cli/introduction)) |
| SDK | - | Native Clay integration; Zapier, Make, n8n |

## Authentication

- **Type**: API key in the `X-API-Key` header (keys start with `lm_`)
- **Env var**: `LEADMAGIC_API_KEY`
- **Get key**: LeadMagic app settings
- **MCP and lm-tui**: browser OAuth sign-in. Scheduled jobs should call the REST API with a key.

## Common Agent Operations

Base URL: `https://api.leadmagic.io`. All lookups are `POST` with a JSON body.

### Find and validate a work email

```bash
POST https://api.leadmagic.io/v1/people/email-finder
X-API-Key: $LEADMAGIC_API_KEY

{ "first_name": "Jane", "last_name": "Doe", "domain": "acme.com" }
```

```bash
POST /v1/people/email-validation
{ "email": "jane@acme.com" }
```

### Signals and account research

```bash
POST /v1/people/job-change-detector    { "profile_url": "https://www.linkedin.com/in/janedoe" }
POST /v1/companies/technographics      { "company_domain": "acme.com" }
POST /v1/companies/company-funding     { "company_domain": "acme.com" }
POST /v3/companies/lookalike           { "company_domain": "bestcustomer.com", "limit": 50 }
POST /v3/jobs/search                   # open roles, e.g. companies hiring a growth or lifecycle marketer
```

### Other endpoints

- `/v1/people/mobile-finder` (from profile URL or email), `/v1/people/role-finder`, `/v1/people/employee-finder`
- `/v3/people/search`, `/v3/companies/search`
- `/v1/ads/meta-ads-search`, `/v1/ads/google-ads-search`, `/v1/ads/b2b-ads-search` (whether a target account is running ads)
- `GET /v1/credits`

## Credits

Charged only for billable results; `not_found` is free, and validation charges only definitive `valid`/`invalid` results.

| Lookup | Credits |
|--------|---------|
| Email validation | 0.25 (4 per credit) |
| Email finder | 1 |
| Personal email finder | 2 |
| Job change detector | 3 |
| Mobile finder | 5 |
| Profile URL to email | 5 |
| Technographics, company search | 1 |
| Company funding | 4 |
| Competitors search | 5 |
| Employee finder | 1 per 20 employees |

Plans run from 5,000 credits/month (Essential, $99) to 100,000 (Ultimate, $849); people, company, and job search are zero-credit on Professional and Ultimate within fair-use limits. Source: [credits page](https://leadmagic.io/docs/v1/credits).

## Rate Limits

- Email finder and email validation: 600 requests per minute on standard plans
- Zero-credit search: 5 requests per second (Professional) or 10 (Ultimate), with a daily fair-use ceiling
- Source: [full docs](https://leadmagic.io/docs/llms-full.txt)

## When to Use

- One provider in an enrichment waterfall, or the email-finding step after a database search
- Cheap signal checks per account: job changes for past champions, tech stack, funding, hiring, and active ad spend
- Lookalike lists seeded from your best customers' domains
- As with any finder, run a 200-contact test against your own ICP before committing, and verify emails before sending

## Relevant Skills

- prospecting
- cold-email
- competitor-profiling
- revops

## File: tools/integrations/lemlist.md

# Lemlist

Multichannel outreach platform: email sequences plus LinkedIn steps (invitations, messages, profile visits) and WhatsApp in one campaign, with personalization, a built-in lead database and enrichment, and reply tracking. Checked against [developer.lemlist.com](https://developer.lemlist.com/api-reference/getting-started/overview) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for campaigns, leads, activities, webhooks |
| MCP | ✓ | Official hosted server at `https://app.lemlist.com/mcp`: OAuth, or an API key in `X-API-Key` ([setup](https://developer.lemlist.com/mcp/setup)) |
| CLI | [✓](../clis/lemlist.js) | Zero-dependency Node.js CLI in this repo; lemlist also publishes an [official CLI](https://developer.lemlist.com/cli/overview) |
| SDK | - | API-only |

## Authentication

- **Type**: Basic Auth (empty username, API key as password)
- **Header**: `Authorization: Basic base64(:api_key)`
- **Env var**: `LEMLIST_API_KEY`
- **Get key**: [Lemlist Settings > Integrations](https://app.lemlist.com/settings/integrations)

## Common Agent Operations

### List campaigns

```bash
node tools/clis/lemlist.js campaigns list --offset 0 --limit 20
```

### Get campaign details and stats

```bash
# Get campaign
node tools/clis/lemlist.js campaigns get --id cam_abc123

# Get campaign stats
node tools/clis/lemlist.js campaigns stats --id cam_abc123

# Export campaign data
node tools/clis/lemlist.js campaigns export --id cam_abc123
```

### Manage leads in a campaign

```bash
# List leads
node tools/clis/lemlist.js leads list --campaign-id cam_abc123

# Add a lead
node tools/clis/lemlist.js leads add --campaign-id cam_abc123 --email john@example.com --first-name John --last-name Doe --company "Example Inc"

# Get lead details
node tools/clis/lemlist.js leads get --campaign-id cam_abc123 --email john@example.com

# Remove a lead
node tools/clis/lemlist.js leads delete --campaign-id cam_abc123 --email john@example.com
```

### Manage unsubscribes

```bash
# List unsubscribed emails
node tools/clis/lemlist.js unsubscribes list

# Add to unsubscribe list
node tools/clis/lemlist.js unsubscribes add --email john@example.com

# Remove from unsubscribe list
node tools/clis/lemlist.js unsubscribes delete --email john@example.com
```

### View activities

```bash
# All activities
node tools/clis/lemlist.js activities list

# Filter by campaign and type
node tools/clis/lemlist.js activities list --campaign-id cam_abc123 --type emailsOpened
```

### Manage webhooks

```bash
# List hooks
node tools/clis/lemlist.js hooks list

# Create a webhook
node tools/clis/lemlist.js hooks create --target-url https://example.com/webhook --event emailsOpened

# Delete a webhook
node tools/clis/lemlist.js hooks delete --id hook_123
```

`--event` maps to the API's `type` filter. Sending a different field would omit
the filter and subscribe the destination to all events. See the
[Add Webhook reference](https://developer.lemlist.com/api-reference/endpoints/webhooks/add-webhook).

### Team info

```bash
node tools/clis/lemlist.js team info
```

## Rate Limits

- 20 requests per 2 seconds ([rate limit docs](https://developer.lemlist.com/api-reference/getting-started/rate-limits))
- LinkedIn steps have their own daily limits per sender (invitations, messages, profile visits), settable through the API. Keep them conservative; any LinkedIn automation risks account restrictions under LinkedIn's terms.

## Use Cases

- **Sales outbound**: email + LinkedIn sequences to verified, segmented lists, from secondary domains
- **Cross-channel stops**: a reply on any lemlist channel stops the lead's remaining steps; push replies and booked meetings that happen elsewhere back via the API so the sequence stops there too
- **Reply tracking**: webhooks for replies, bounces, and unsubscribes feed the CRM and suppression lists
- **Link building and PR outreach**: the same campaign mechanics work for backlink and press outreach

Judge campaigns on replies, positive replies, and meetings rather than opens.

## Relevant Skills

- cold-email
- prospecting
- revops

## File: tools/integrations/linkedin-ads.md

# LinkedIn Ads

B2B advertising platform with professional targeting (job title, function, seniority, company, industry, company size) and account-based targeting from uploaded company and contact lists.

API facts below were checked against the [LinkedIn Marketing API docs](https://learn.microsoft.com/en-us/linkedin/marketing/versioning) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Versioned Marketing API at `https://api.linkedin.com/rest` (accounts, campaigns, creatives, targeting, audiences, reporting) |
| MCP | - | No official server; [Composio](composio.md) offers a LinkedIn toolkit |
| CLI | [✓](../clis/linkedin-ads.js) | Zero-dependency Node.js CLI (versioned REST API) |
| SDK | - | API-only (community libraries available) |

## Authentication

- **Type**: OAuth 2.0 (3-legged) access token from an app approved for the Marketing API program
- **Header**: `Authorization: Bearer {access_token}`
- **Scopes**: `r_ads`, `rw_ads`, `r_ads_reporting`
- **Env vars**: `LINKEDIN_ACCESS_TOKEN`; optional `LINKEDIN_API_VERSION` (YYYYMM, CLI default `202609`)

## Versioning

- Every call needs a `Linkedin-Version: YYYYMM` header plus `X-Restli-Protocol-Version: 2.0.0`. Requests without a version, or with a sunset version, return an error; the latest version is never applied by default.
- New versions ship monthly and each is supported for at least a year. Version `202510` sunsets on 2026-10-15. Bump the version at least once a year.
- The old unversioned `/v2/adAccountsV2`, `/v2/adCampaignsV2`, `/v2/adCreativesV2`, `/v2/adAnalyticsV2`, and `/v2/audienceCountsV2` paths are replaced by the versioned paths below.
- Rest.li 2.0 syntax: lists are `List(a,b)`, objects are `(key:value)`, and URNs inside query parameters must be URL-encoded (`urn%3Ali%3AsponsoredCampaign%3A123`).

## Common Agent Operations

### Ad accounts

```bash
node tools/clis/linkedin-ads.js accounts list
# GET https://api.linkedin.com/rest/adAccounts?q=search
```

### Campaigns (scoped to an ad account)

```bash
node tools/clis/linkedin-ads.js campaigns list --account-id 507404993 --status ACTIVE
# GET /rest/adAccounts/{accountId}/adCampaigns?q=search&search=(status:(values:List(ACTIVE)))

node tools/clis/linkedin-ads.js campaigns create --account-id 507404993 --campaign-group-id 600 --name "ABM retargeting" --daily-budget 50
# POST /rest/adAccounts/{accountId}/adCampaigns   (created PAUSED; add targeting before activating)

node tools/clis/linkedin-ads.js campaigns update --account-id 507404993 --id 123456 --status PAUSED
# POST /rest/adAccounts/{accountId}/adCampaigns/{campaignId}
# X-RestLi-Method: PARTIAL_UPDATE   body: {"patch":{"$set":{"status":"PAUSED"}}}
```

### Reporting

```bash
node tools/clis/linkedin-ads.js campaigns analytics --id 123456 --start 2026-09-01 --end 2026-09-30
# GET /rest/adAnalytics?q=analytics&pivot=CAMPAIGN&timeGranularity=ALL
#     &dateRange=(start:(year:2026,month:9,day:1),end:(year:2026,month:9,day:30))
#     &campaigns=List(urn%3Ali%3AsponsoredCampaign%3A123456)
#     &fields=impressions,clicks,landingPageClicks,costInLocalCurrency,externalWebsiteConversions,dateRange,pivotValues
```

Request metrics explicitly with `fields` (up to 20); otherwise only impressions and clicks come back. Use `q=statistics` with `pivots=List(...)` for up to three pivots, and the `MEMBER_COMPANY` pivot to see which companies saw an ABM campaign. Professional demographic metrics are approximate and delayed 12–24 hours.

### Creatives

```bash
node tools/clis/linkedin-ads.js creatives list --account-id 507404993 --campaign-id 123456
# GET /rest/adAccounts/{accountId}/creatives?q=criteria&campaigns=List(urn%3Ali%3AsponsoredCampaign%3A123456)
```

### Audience size

```bash
node tools/clis/linkedin-ads.js audiences count \
  --targeting "(include:(and:List((or:(urn%3Ali%3AadTargetingFacet%3Alocations:List(urn%3Ali%3Ageo%3A103644278))))))"
# GET /rest/audienceCounts?q=targetingCriteriaV2&targetingCriteria=...
```

The count is 0 when the audience is under 300 members (privacy threshold). Look up targeting entity URNs with `/rest/adTargetingEntities` (typeahead or by facet).

## Account-Based and Outbound Use

- **Matched Audiences**: upload a target account list (companies) or contact list to retarget the accounts you're prospecting, so your name is familiar before and during outreach. See [Matched Audiences](https://learn.microsoft.com/en-us/linkedin/marketing/matched-audiences/matched-audiences). Test ad accounts can't upload audience segments.
- **Company engagement**: the `MEMBER_COMPANY` reporting pivot shows which target companies are seeing and clicking ads, a warm signal for sales follow-up (see the `ads` skill's ABM playbook).

## Key Metrics

| Metric | Description |
|--------|-------------|
| `impressions` | Ad impressions |
| `clicks` | Total clicks |
| `landingPageClicks` | Clicks to the landing page |
| `costInLocalCurrency` | Spend |
| `externalWebsiteConversions` | Conversions tracked with the Insight Tag or Conversions API |
| `oneClickLeads` | Lead Gen Form submissions |

## Campaign Types

- `SPONSORED_UPDATES` - Sponsored content
- `TEXT_AD` - Text ads
- `SPONSORED_INMAILS` - Message ads
- `DYNAMIC` - Dynamic ads

## Rate Limits

- Limits are set per application and per member and shown in your app's Developer Portal analytics; LinkedIn doesn't publish fixed numbers for most endpoints.
- `adAnalytics` throttles above 45 million metric values per 5-minute window; request only the fields you need. Long URLs can hit `414`; use [query tunneling](https://learn.microsoft.com/en-us/linkedin/shared/references/migrations/query-tunneling-migration).

## Relevant Skills

- ads
- analytics
- attribution
- prospecting (account lists for ABM)

## File: tools/integrations/livestorm.md

# Livestorm

Video engagement platform for webinars, virtual events, and online meetings with built-in analytics and integrations.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Events, Sessions, People, Recordings, Webhooks |
| MCP | - | Not available |
| CLI | ✓ | [livestorm.js](../clis/livestorm.js) |
| SDK | - | REST API with JSON:API format |

## Authentication

- **Type**: API Token
- **Header**: `Authorization: {API_TOKEN}` (no prefix)
- **Content-Type**: `application/vnd.api+json` (JSON:API)
- **Scopes**: Identity, Events, Admin, Webhooks
- **Get token**: Account Settings > Integrations > Public API
- **Docs**: https://developers.livestorm.co/

## Common Agent Operations

### Ping (test authentication)

```bash
GET https://api.livestorm.co/v1/ping

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### List events

```bash
GET https://api.livestorm.co/v1/events?page[number]=1&page[size]=25

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Create an event

```bash
POST https://api.livestorm.co/v1/events

Headers:
  Authorization: {API_TOKEN}
  Content-Type: application/vnd.api+json

{
  "data": {
    "type": "events",
    "attributes": {
      "title": "Product Demo Webinar",
      "slug": "product-demo-webinar",
      "estimated_duration": 60
    }
  }
}
```

### Get event details

```bash
GET https://api.livestorm.co/v1/events/{event_id}

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Update an event

```bash
PATCH https://api.livestorm.co/v1/events/{event_id}

Headers:
  Authorization: {API_TOKEN}
  Content-Type: application/vnd.api+json

{
  "data": {
    "type": "events",
    "id": "{event_id}",
    "attributes": {
      "title": "Updated Webinar Title"
    }
  }
}
```

### List sessions

```bash
GET https://api.livestorm.co/v1/sessions?page[number]=1&page[size]=25

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Create a session for an event

```bash
POST https://api.livestorm.co/v1/events/{event_id}/sessions

Headers:
  Authorization: {API_TOKEN}
  Content-Type: application/vnd.api+json

{
  "data": {
    "type": "sessions",
    "attributes": {
      "estimated_started_at": "2025-06-15T14:00:00.000Z",
      "timezone": "America/New_York"
    }
  }
}
```

### Register someone for a session

```bash
POST https://api.livestorm.co/v1/sessions/{session_id}/people

Headers:
  Authorization: {API_TOKEN}
  Content-Type: application/vnd.api+json

{
  "data": {
    "type": "people",
    "attributes": {
      "fields": [
        { "id": "email", "value": "attendee@example.com" },
        { "id": "first_name", "value": "Jane" },
        { "id": "last_name", "value": "Doe" }
      ]
    }
  }
}
```

Registration fields are an array of `id`/`value` pairs, including the required
email field. See the official [registration contract](https://developers.livestorm.co/reference/post_sessions-id-people).
Private API tokens are sent directly in `Authorization`, as described in
[API token authentication](https://developers.livestorm.co/docs/api-token-authentication).

### List session participants

```bash
GET https://api.livestorm.co/v1/sessions/{session_id}/people?page[number]=1&page[size]=25

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Remove a registrant from session

```bash
DELETE https://api.livestorm.co/v1/sessions/{session_id}/people?filter[email]=attendee@example.com

Headers:
  Authorization: {API_TOKEN}
```

### List session chat messages

```bash
GET https://api.livestorm.co/v1/sessions/{session_id}/chat-messages

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### List session questions

```bash
GET https://api.livestorm.co/v1/sessions/{session_id}/questions

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Get session recordings

```bash
GET https://api.livestorm.co/v1/sessions/{session_id}/recordings

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### List all people

```bash
GET https://api.livestorm.co/v1/people?page[number]=1&page[size]=25

Headers:
  Authorization: {API_TOKEN}
  Accept: application/vnd.api+json
```

### Create a webhook

```bash
POST https://api.livestorm.co/v1/webhooks

Headers:
  Authorization: {API_TOKEN}
  Content-Type: application/vnd.api+json

{
  "data": {
    "type": "webhooks",
    "attributes": {
      "target_url": "https://example.com/webhook",
      "event_name": "attendance"
    }
  }
}
```

## API Pattern

Livestorm follows the JSON:API specification:
- All responses use `data`, `attributes`, `relationships` structure
- Pagination: `page[number]` and `page[size]` query parameters
- Filtering: `filter[field]=value` query parameters
- Events contain multiple Sessions; Sessions contain People
- ISO 8601 timestamps throughout

## Key Metrics

### Event Metrics
- `title` - Event title
- `slug` - URL-friendly identifier
- `estimated_duration` - Duration in minutes
- `registration_page_enabled` - Registration page status
- `everyone_can_speak` - Whether all attendees can speak

### Session Metrics
- `status` - Session status (upcoming, live, past)
- `estimated_started_at` - Scheduled start time
- `started_at` - Actual start time
- `ended_at` - Actual end time
- `timezone` - Session timezone
- `attendees_count` - Number of attendees
- `registrants_count` - Number of registrants

### People Metrics
- `email` - Contact email
- `first_name` / `last_name` - Contact name
- `registrant_detail` - Registration metadata
- `attendance_rate` - Attendance percentage
- `attended_at` - Join timestamp
- `left_at` - Leave timestamp

## Parameters

### Pagination
- `page[number]` - Page number (default: 1)
- `page[size]` - Items per page (default: 25)

### Event Attributes
- `title` - Event title (required for create)
- `slug` - URL slug
- `description` - Event description
- `estimated_duration` - Duration in minutes

### Session Attributes
- `estimated_started_at` - ISO 8601 start time
- `timezone` - IANA timezone string

### Registration Fields
- `email` - Registrant email (required)
- `first_name` - First name
- `last_name` - Last name

### Webhook Events
- `attendance` - Triggered on session attendance
- `registration` - Triggered on new registration
- `unregistration` - Triggered on unregistration

## When to Use

- Hosting product demos and marketing webinars
- Automated webinar registration and attendee management
- Tracking webinar engagement and attendance rates
- Retrieving session recordings for content repurposing
- Building custom registration pages with API-driven registration
- Syncing webinar data with CRM and marketing automation
- Monitoring session Q&A and chat for follow-up

## Rate Limits

- **10,000 API calls per 30-day period** (organization-wide)
- Rate limits shared across all API tokens in the organization
- Plan accordingly for high-volume operations
- Use webhooks instead of polling to conserve quota

## Relevant Skills

- webinar-marketing
- event-marketing
- lead-generation
- content-strategy
- lifecycle-marketing
- customer-engagement

## File: tools/integrations/mailchimp.md

# Mailchimp

Email marketing platform for campaigns, automation, and audience management.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Marketing API for campaigns, audiences, automation |
| MCP | ✓ | Available via Mailchimp MCP server |
| CLI | - | Not available |
| SDK | ✓ | Official SDKs for multiple languages |

## Authentication

- **Type**: API Key or OAuth 2.0
- **Header**: `Authorization: Bearer {api_key}` or `Authorization: apikey {api_key}`
- **Base URL**: `https://{dc}.api.mailchimp.com/3.0/` (dc = datacenter from API key)

## Updating member tags

`members update <subscriber_hash> --list-id <list_id> --tags newsletter,trial` activates named tags through Mailchimp's member-tags endpoint. This adds the requested tags and does not replace or remove existing tags. Member creation still accepts its supported string-array `--tags` field.

Tag changes and member profile/status changes use separate API endpoints. Run them as separate commands; combining `--tags` with `--status`, `--first-name` or `--last-name` is rejected before either write. A tag-only preview shows the POST `/lists/{list_id}/members/{subscriber_hash}/tags` request with `{tags: [{name, status: "active"}]}`. Its successful response is HTTP 204 with no JSON body.

## Common Agent Operations

### List audiences (lists)

```bash
GET https://{dc}.api.mailchimp.com/3.0/lists
```

### Get audience members

```bash
GET https://{dc}.api.mailchimp.com/3.0/lists/{list_id}/members?count=100
```

### Add subscriber

```bash
POST https://{dc}.api.mailchimp.com/3.0/lists/{list_id}/members

{
  "email_address": "user@example.com",
  "status": "subscribed",
  "merge_fields": {
    "FNAME": "John",
    "LNAME": "Doe"
  }
}
```

### Update subscriber

```bash
PATCH https://{dc}.api.mailchimp.com/3.0/lists/{list_id}/members/{subscriber_hash}

{
  "merge_fields": {
    "FNAME": "Jane"
  },
  "tags": ["customer", "premium"]
}
```

### Get campaigns

```bash
GET https://{dc}.api.mailchimp.com/3.0/campaigns?count=20
```

### Get campaign report

```bash
GET https://{dc}.api.mailchimp.com/3.0/reports/{campaign_id}
```

### Create campaign

```bash
POST https://{dc}.api.mailchimp.com/3.0/campaigns

{
  "type": "regular",
  "recipients": {
    "list_id": "{list_id}"
  },
  "settings": {
    "subject_line": "Your Subject",
    "from_name": "Your Name",
    "reply_to": "reply@example.com"
  }
}
```

### Send campaign

```bash
POST https://{dc}.api.mailchimp.com/3.0/campaigns/{campaign_id}/actions/send
```

### List automations

```bash
GET https://{dc}.api.mailchimp.com/3.0/automations
```

## Key Metrics

### Campaign Report Fields
- `emails_sent` - Total sent
- `opens` - Open count
- `unique_opens` - Unique opens
- `open_rate` - Open rate
- `clicks` - Click count
- `click_rate` - Click rate
- `unsubscribes` - Unsubscribe count
- `bounces` - Bounce count

### Subscriber Hash

Calculate subscriber hash for updates:
```javascript
const hash = md5(email.toLowerCase());
```

## Subscriber Statuses

- `subscribed` - Active subscriber
- `unsubscribed` - Unsubscribed
- `cleaned` - Hard bounce
- `pending` - Awaiting confirmation
- `transactional` - Transactional only

## When to Use

- Managing email lists and subscribers
- Creating and sending email campaigns
- Setting up email automation
- Analyzing campaign performance
- Segmenting audiences
- A/B testing emails

## Rate Limits

- 10 concurrent connections
- 10 requests per second
- Batch endpoints for bulk operations

## Relevant Skills

- emails
- analytics
- referrals

## File: tools/integrations/mention-me.md

# Mention Me

Enterprise referral marketing platform for customer advocacy.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for referrals, customers, rewards |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | JavaScript widget for embedding |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Environment**: Separate keys for sandbox and production

## Common Agent Operations

### Create referral offer

```bash
POST https://api.mention-me.com/api/v2/referrer-offer

{
  "email": "customer@example.com",
  "firstname": "John",
  "lastname": "Doe",
  "order_number": "ORD-123",
  "order_total": 99.99,
  "order_currency": "USD"
}
```

### Get referral link for customer

```bash
GET https://api.mention-me.com/api/v2/referrer/{customer_id}/share-links
```

### Record referee (referred customer)

```bash
POST https://api.mention-me.com/api/v2/referee

{
  "email": "referred@example.com",
  "firstname": "Jane",
  "referrer_code": "JOHN123",
  "order_number": "ORD-456",
  "order_total": 149.99
}
```

### Get referral status

```bash
GET https://api.mention-me.com/api/v2/referral/{referral_id}
```

### List referrals for customer

```bash
GET https://api.mention-me.com/api/v2/referrer/{customer_id}/referrals
```

### Get reward balance

```bash
GET https://api.mention-me.com/api/v2/referrer/{customer_id}/rewards
```

### Redeem reward

```bash
POST https://api.mention-me.com/api/v2/referrer/{customer_id}/rewards/redeem

{
  "reward_id": "RWD-123",
  "order_number": "ORD-789"
}
```

## JavaScript Widget

### Embed referral widget

```html
<div id="mmWrapper"></div>
<script>
  window.MentionMe = window.MentionMe || [];
  MentionMe.push({
    type: 'offer',
    customer: {
      email: 'customer@example.com',
      firstname: 'John',
      order_number: 'ORD-123'
    }
  });
</script>
<script src="https://tag.mention-me.com/client/{partner_code}.js" async></script>
```

### Name share widget

```javascript
MentionMe.push({
  type: 'nameShare',
  customer: {
    email: 'customer@example.com'
  }
});
```

## Webhook Events

| Event | When |
|-------|------|
| `referral.created` | New referral tracked |
| `referral.converted` | Referral completed purchase |
| `reward.earned` | Reward unlocked |
| `reward.redeemed` | Reward used |

## Key Features

- **A/B testing** - Built-in experiment framework
- **Fraud prevention** - Automatic fraud detection
- **Multi-channel** - Share via link, email, social
- **Name sharing** - Refer by name, not code
- **Segmentation** - Different offers by segment
- **Analytics** - Referral program reporting

## Key Objects

- **Referrer** - Customer who refers
- **Referee** - Customer who is referred
- **Referral** - Connection between referrer and referee
- **Offer** - Referral program configuration
- **Reward** - Incentive earned

## When to Use

- Enterprise referral programs
- Multi-market referral campaigns
- A/B testing referral offers
- Fraud-resistant referral tracking
- Name-based sharing programs

## Rate Limits

- 1000 requests per minute
- Contact for higher limits

## Relevant Skills

- referrals
- pricing
- analytics

## File: tools/integrations/meta-ads.md

# Meta Ads (Facebook/Instagram)

Advertising platform for Facebook, Instagram, Messenger, and Audience Network.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Marketing API for campaigns, audiences, reporting |
| MCP | ✓ | Official remote server at `mcp.facebook.com/ads` (Meta Ads AI Connectors), open beta since 2026-04-29, read and write; see [Official MCP server](#official-mcp-server) |
| CLI | - | Not available |
| SDK | ✓ | Official SDKs for Python, PHP, Node.js |

## Authentication

- **Type**: OAuth 2.0 Access Token
- **Header**: Access token as query parameter
- **Setup**: Create app in Meta Business Suite, generate System User token

## Official MCP server

Meta hosts an official ads MCP server, part of **Meta Ads AI Connectors** (open beta since 2026-04-29, checked 2026-10-15). It works with any MCP client, including Claude and ChatGPT. Meta also ships a local ads CLI with the same tool surface for terminal agents.

- **Endpoint:** `https://mcp.facebook.com/ads`
- **Claude setup:** Settings → Connectors → Add custom connector, paste the endpoint, then sign in with Facebook Login for Business (a Facebook account or Meta Managed Account) and approve permissions. No Meta developer app or system user token is needed.
- **Access:** you see the ad accounts your Facebook profile can access through its Business Portfolio. The open beta isn't enabled for every advertiser yet; if the connector authenticates but returns no ads tools, access hasn't reached that account.
- **Tools:** 29 at launch, across performance and insights, campaign creation and management, catalog management, accounts and assets, and dataset/signal diagnostics. Meta adds tools as products leave beta, so treat any count as a floor.
- **Cost:** free during the beta, within normal Marketing API rate limits.

**Start read-only.** The connector includes write tools (create campaigns, edit budgets and status). Run reporting and diagnostics for the first few weeks and check the answers against Ads Manager before allowing any write. After that, apply changes only as a reviewed plan (current state → change → expected effect → rollback) with explicit approval of that specific change. See the ads skill's [audit guardrails](../../skills/ads/references/audit-guardrails.md).

Use the Marketing API below when you need endpoints the connector doesn't expose, scheduled jobs without a chat client, or the repository CLI.

## Common Agent Operations

### Get ad accounts

```bash
GET https://graph.facebook.com/v18.0/me/adaccounts?access_token={access_token}&fields=id,name,account_status
```

### Get campaigns

```bash
GET https://graph.facebook.com/v18.0/act_{ad_account_id}/campaigns?access_token={access_token}&fields=id,name,status,objective,daily_budget
```

### Get campaign insights

```bash
GET https://graph.facebook.com/v18.0/{campaign_id}/insights?access_token={access_token}&fields=impressions,clicks,spend,actions,cost_per_action_type&date_preset=last_30d
```

### Get ad sets

```bash
GET https://graph.facebook.com/v18.0/act_{ad_account_id}/adsets?access_token={access_token}&fields=id,name,status,targeting,daily_budget,bid_amount
```

### Get ads

```bash
GET https://graph.facebook.com/v18.0/{ad_set_id}/ads?access_token={access_token}&fields=id,name,status,creative
```

### Create campaign

```bash
POST https://graph.facebook.com/v18.0/act_{ad_account_id}/campaigns

access_token={access_token}
&name=Campaign Name
&objective=CONVERSIONS
&status=PAUSED
&special_ad_categories=[]
```

### Update campaign status

```bash
POST https://graph.facebook.com/v18.0/{campaign_id}

access_token={access_token}
&status=ACTIVE
```

### Get custom audiences

```bash
GET https://graph.facebook.com/v18.0/act_{ad_account_id}/customaudiences?access_token={access_token}&fields=id,name,approximate_count
```

### Create lookalike audience

```bash
POST https://graph.facebook.com/v18.0/act_{ad_account_id}/customaudiences

access_token={access_token}
&name=Lookalike - Top Customers
&subtype=LOOKALIKE
&origin_audience_id={source_audience_id}
&lookalike_spec={"type":"similarity","country":"US"}
```

## Key Metrics

| Metric | Description |
|--------|-------------|
| `impressions` | Ad impressions |
| `clicks` | All clicks |
| `spend` | Amount spent |
| `reach` | Unique people reached |
| `frequency` | Avg impressions per person |
| `cpm` | Cost per 1000 impressions |
| `cpc` | Cost per click |
| `actions` | Conversions array |
| `cost_per_action_type` | CPA by action |

## Campaign Objectives

- `AWARENESS` - Brand awareness
- `TRAFFIC` - Website traffic
- `ENGAGEMENT` - Post engagement
- `LEADS` - Lead generation
- `APP_PROMOTION` - App installs
- `SALES` - Conversions/catalog sales

## Targeting Options

```json
{
  "geo_locations": {
    "countries": ["US"],
    "cities": [{"key": "2420379"}]
  },
  "age_min": 25,
  "age_max": 45,
  "genders": [1, 2],
  "interests": [{"id": "6003139266461", "name": "Marketing"}],
  "behaviors": [{"id": "6002714895372"}]
}
```

## When to Use

- Creating/managing Facebook and Instagram ads
- Audience targeting and lookalikes
- Campaign performance analysis
- Retargeting setup

## Rate Limits

- 200 calls/hour per ad account
- 60 calls/hour for marketing API
- Use batch requests for efficiency

## Relevant Skills

- ads
- analytics
- cro

## File: tools/integrations/mixpanel.md

# Mixpanel

Product analytics platform for tracking user behavior and retention.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Ingestion API, Query API, Data Export |
| MCP | - | Not available |
| CLI | ✓ | [mixpanel.js](../clis/mixpanel.js) |
| SDK | ✓ | JavaScript, iOS, Android, Python, etc. |

## Authentication

- **Ingestion**: Project token (public)
- **Query API / Export**: Service Account (username:secret as Basic auth). Set
  `MIXPANEL_API_KEY` to the service-account username and `MIXPANEL_SECRET` to its secret.
  Supply `--project-id` for query/export commands; GET requests send it as `project_id`.
- **Legacy fallback**: When `MIXPANEL_API_KEY` is absent, `MIXPANEL_PROJECT_SECRET`
  (or `MIXPANEL_SECRET` alone) is sent as the Basic auth username with an empty password.
  A configured service account always takes precedence; a username without its secret
  is an error and does not fall back.
- **Deprecation**: Project-secret authentication retires on March 3, 2027 and is
  unavailable for new projects. Use service accounts for new integrations. See
  [Service Accounts](https://docs.mixpanel.com/reference/service-accounts) and
  [Project Secret](https://docs.mixpanel.com/reference/project-secret).

```bash
node tools/clis/mixpanel.js export events --project-id 123 \
  --from-date 2024-01-01 --to-date 2024-01-31 --dry-run
```

## Common Agent Operations

### Track event (Ingestion API)

```bash
POST https://api.mixpanel.com/track

{
  "event": "signup_completed",
  "properties": {
    "token": "{project_token}",
    "distinct_id": "user_123",
    "plan": "pro",
    "time": 1705312800
  }
}
```

### Set user profile

```bash
POST https://api.mixpanel.com/engage

{
  "$token": "{project_token}",
  "$distinct_id": "user_123",
  "$set": {
    "$email": "user@example.com",
    "$name": "John Doe",
    "plan": "pro"
  }
}
```

### Query events (Query API)

```bash
POST https://mixpanel.com/api/2.0/insights

{
  "project_id": {project_id},
  "bookmark_id": null,
  "params": {
    "events": [{"event": "signup_completed"}],
    "time_range": {
      "from_date": "2024-01-01",
      "to_date": "2024-01-31"
    }
  }
}
```

### Get funnel data

```bash
GET https://mixpanel.com/api/2.0/funnels?project_id={project_id}&funnel_id={funnel_id}&from_date=2024-01-01&to_date=2024-01-31
```

### Export raw events

```bash
GET https://data.mixpanel.com/api/2.0/export?project_id={project_id}&from_date=2024-01-01&to_date=2024-01-01
```

### Get retention data

```bash
GET https://mixpanel.com/api/2.0/retention?project_id={project_id}&from_date=2024-01-01&to_date=2024-01-31&retention_type=birth&born_event=signup_completed
```

## JavaScript SDK

```javascript
// Initialize
mixpanel.init('YOUR_TOKEN');

// Identify user
mixpanel.identify('user_123');

// Set user properties
mixpanel.people.set({
  '$email': 'user@example.com',
  'plan': 'pro'
});

// Track event
mixpanel.track('Feature Used', {
  'feature_name': 'export'
});
```

## Key Concepts

- **Events** - User actions (signup, purchase, etc.)
- **Properties** - Attributes on events
- **User Profiles** - Persistent user data
- **Cohorts** - Saved user segments
- **Funnels** - Conversion sequences
- **Retention** - User return patterns

## When to Use

- Tracking product usage events
- Analyzing conversion funnels
- Measuring feature adoption
- Retention analysis
- User segmentation

## Rate Limits

- Ingestion: No hard limit (batch recommended)
- Query API: Varies by plan

## Relevant Skills

- analytics
- ab-testing
- onboarding

### Select the project's API region

Set `MIXPANEL_REGION` to your existing project's region: `us` (default), `eu`,
or `in`. One setting selects the documented ingestion, query, and raw-export
API families consistently:

| Region | Ingestion | Query | Export |
|--------|-----------|-------|--------|
| `us` | `api.mixpanel.com` | `mixpanel.com` | `data.mixpanel.com` |
| `eu` | `api-eu.mixpanel.com` | `eu.mixpanel.com` | `data-eu.mixpanel.com` |
| `in` | `api-in.mixpanel.com` | `in.mixpanel.com` | `data-in.mixpanel.com` |

```bash
MIXPANEL_REGION=eu node tools/clis/mixpanel.js track event \
  --distinct-id owned-test-user --event 'Owned test event' --dry-run
```

Unknown regions fail before any request. Dry runs use the selected hosts and
mask credentials as before. Authentication, payloads, and response parsing are
unchanged. Match the region in your Mixpanel project settings; selecting a host
does not move a project or establish a data-residency guarantee. See the
[official API overview](https://docs.mixpanel.com/reference/overview).

## File: tools/integrations/nitrosend.md

# Nitrosend

AI-native email platform that combines transactional and marketing email in one stack, controlled entirely through AI assistants via MCP. No traditional dashboard required — build sequences, campaigns, and automations by prompting.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API available |
| MCP | ✓ | Full MCP support — primary integration method |
| CLI | - | Not available |
| SDK | - | Use MCP or API directly |

## Authentication

- **Type**: API Key
- **MCP Setup**: Add Nitrosend MCP server to your Claude Code / AI assistant config
- **BYO Infrastructure**: Optionally bring your own SendGrid, Postmark, SES, or Resend keys
- **Get access**: Sign up at nitrosend.com — free tier includes 8K emails initially, then 500/month

## Pricing

| Plan | Cost | Volume |
|------|------|--------|
| Free | $0 | 8K initially, then 500/mo |
| Hobby | $20/mo | 25,000/mo |
| Pro | $100/mo | 150,000/mo |
| Scale | $300/mo | 500,000/mo |
| BYO | $60/mo | Unlimited (your infrastructure) |

Unlimited contacts on all plans — pay per email sent, not per subscriber.

## What Makes It Different

- **AI-first**: Designed to be controlled by Claude, ChatGPT, Codex, Cursor, Gemini, Windsurf — not a human clicking through a dashboard
- **Unified transactional + marketing**: Single platform for both, on separate infrastructure
- **Automatic optimization**: Continuously tests subject lines, send times, and content based on engagement
- **Auto-configured deliverability**: DKIM, SPF, DMARC, and dedicated IP warmup handled automatically
- **Migration-friendly**: Import from Mailchimp, Klaviyo, ActiveCampaign, HubSpot

## Common Agent Operations (via MCP)

### Create an email sequence

```
"Create a 5-email onboarding sequence for new SaaS trial users.
Email 1: Welcome + what to do first (send immediately)
Email 2: Key feature highlight (day 2)
Email 3: Use case / success story (day 4)
Email 4: Check-in + support offer (day 7)
Email 5: Upgrade prompt (day 12)"
```

Nitrosend builds the sequence, timing, and sends — no manual setup in a dashboard.

### Send a transactional email

```
"Send a password reset email to user@example.com with a reset link valid for 1 hour."
```

### Create a campaign

```
"Create a re-engagement campaign for subscribers who haven't opened in 90 days.
Subject line variants: [A] 'We miss you', [B] 'Still interested in [topic]?'
Test both, send winner to remaining list after 4 hours."
```

### Check sequence performance

```
"Show me open rates, click rates, and unsubscribes for the onboarding sequence."
```

### Import a list

```
"Import this CSV of 2,000 subscribers from our Mailchimp export."
```

## Deliverability Setup

Nitrosend handles this automatically on signup:
- DKIM signing
- SPF record configuration
- DMARC policy
- Dedicated IP provisioning (Pro+)
- IP warmup schedule

For BYO plan users: bring your own SendGrid, Postmark, SES, or Resend account and Nitrosend routes through your infrastructure.

## When to Use

- Building email sequences via AI without touching a dashboard
- Teams already using Claude Code or other AI coding tools as their primary workflow
- Combining transactional (password resets, receipts) and marketing (nurture, campaigns) in one place
- Rapid sequence prototyping — describe the sequence, get it built
- Migrating from Mailchimp/Klaviyo and wanting AI control going forward

## When to Use Something Else

- **Customer.io** — if you need complex event-based branching logic and behavioral triggers
- **Klaviyo** — if you're in e-commerce and need deep Shopify integration
- **Resend** — if you need transactional-only and prefer a pure API/code approach
- **Kit** — if you're a creator or newsletter-first

## Relevant Skills

- emails
- onboarding
- churn-prevention
- lead-magnets

## File: tools/integrations/omnia.md

# Omnia

> **◆ Verified Partner integration.** Omnia sponsors Marketing Skills. This integration is disclosed and vetted for fit; it does **not** change what any skill recommends. It's listed here alongside the neutral options for the same job — use it when it's the right fit, not because it's a partner. See [Verified Partners](../REGISTRY.md#verified-partners).

Answer engine optimization (AEO) platform combining AI visibility monitoring, prompt discovery, competitor benchmarking, and citation analysis with an AI agent for content optimization, publishing, and third-party outreach.

## When to Use

Use when the user wants to monitor and improve their brand’s visibility in AI search answers. Track brand mentions, Share of Voice, and citations; review whether answers recommend the brand; compare competitors; and identify opportunities to improve content and third-party presence.

- **Connected assistant:** Use MCP to analyze Omnia data interactively, or the API to build recurring reports and scripts. Apply the ai-seo and content-strategy skills to turn the evidence into content briefs, page improvements, and outreach opportunities.
- **Built-in Omnia Agent:** Use your Omnia Agent to research sources, propose projects, create or update content, and publish or send outreach through connected apps with user approval. Remeasure visibility to inform the next iteration.

For a small audit, manual prompt checks and a spreadsheet are sufficient. See the ai-seo skill for other monitoring tools and options.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for brands, prompts, AI answers, performance, and saved prompt views |
| MCP | ✓ | Remote Streamable HTTP server; OAuth; data and API-documentation discovery tools |
| CLI | - | No dedicated CLI documented; use HTTP requests |
| SDK | - | No official SDK documented; use a standard HTTP client |

The [MCP overview](https://docs.useomnia.com/mcp) describes access to monitoring data and API-documentation discovery. Use current brand, prompt, and view endpoints for visibility, Share of Voice, citations, and sentiment. Engine filters include ChatGPT (`openai`), Perplexity, Google AI Overviews, Google AI Mode, Gemini, Grok, Copilot, and Claude; check the account's monitored engines before comparing results.

The built-in [Omnia Agent](https://www.useomnia.com/omnia-agent) researches citation sources, proposes projects, drafts and updates content, and supports publishing and third-party outreach through connected apps with user approval. These execution features run inside Omnia; the MCP and API setup below covers access to monitoring data and documented API operations.

## Authentication

- **MCP:** OAuth through an active Omnia account. Complete sign-in in the client; do not put an API key into the OAuth config.
- **API:** Generate a key on the [API access page](https://app.useomnia.com/api-access). Send `Authorization: Bearer $OMNIA_API_KEY`.
- Store the API key in an environment variable or secret manager. Keep it out of source control, frontend code, and logs; revoke exposed keys.

See [API authentication](https://docs.useomnia.com/api/authentication).

## MCP Setup

**Claude Code**

```bash
claude mcp add --transport http omnia https://app.useomnia.com/mcp
```

Then go to `/mcp` → omnia → Authenticate and complete OAuth.

**stdio-only clients**

Use `mcp-remote` to proxy Omnia's Streamable HTTP server to stdio:

```bash
npx -y mcp-remote https://app.useomnia.com/mcp
```

Point your client's config at that wrapper and follow its OAuth flow.

After connecting, list the server's tools and read their input schemas. Use a read-only request to confirm the intended brand is accessible. Data tools query monitoring results; discovery tools retrieve live endpoint specifications and schemas for writing API code. Do not guess tool names or assume every tool is read-only.

Example agent request: “For our tracked buyer prompts, compare brand mentions over the last two equal periods, separate citations from recommendations, and show the cited URLs behind persistent gaps.”

## API Setup and Common Operations

The base URL is `https://app.useomnia.com/api/v1`. The examples below require `curl` and an API key supplied securely as `OMNIA_API_KEY`.

### Find the Brand and Prompts

```bash
: "${OMNIA_API_KEY:?Set OMNIA_API_KEY through your secret manager or local environment}"
curl --fail-with-body --silent --show-error \
  'https://app.useomnia.com/api/v1/brands?pageSize=100' \
  -H "Authorization: Bearer $OMNIA_API_KEY"
```

Select the intended brand from `data.brands` and set `OMNIA_BRAND_ID` to its `id` (a UUID). Then read its prompts:

```bash
: "${OMNIA_BRAND_ID:?Set OMNIA_BRAND_ID from the brands response}"
curl --fail-with-body --silent --show-error \
  "https://app.useomnia.com/api/v1/brands/$OMNIA_BRAND_ID/prompts?pageSize=100" \
  -H "Authorization: Bearer $OMNIA_API_KEY"
```

The [brand prompt endpoint](https://docs.useomnia.com/api/prompt/list-brand-prompts) returns `data.prompts` and supports `type` (`Branded` or `Non-Branded`), `countries`, `tags`, and `status` (`active` or `paused`) filters. Its optional `startDate`/`endDate` range sets the window for each prompt's returned `shareOfVoice` and `netSentiment` and for metric-based sorting; it defaults to the last seven days.

### Compare Share of Voice

Set `OMNIA_START_DATE` and `OMNIA_END_DATE` to an inclusive ISO date range with collected data (for example, `2026-10-01` and `2026-10-07`).

```bash
: "${OMNIA_START_DATE:?Set OMNIA_START_DATE}"
: "${OMNIA_END_DATE:?Set OMNIA_END_DATE}"
curl --fail-with-body --silent --show-error --get \
  "https://app.useomnia.com/api/v1/brands/$OMNIA_BRAND_ID/share-of-voice/aggregates" \
  -H "Authorization: Bearer $OMNIA_API_KEY" \
  --data-urlencode "startDate=$OMNIA_START_DATE" \
  --data-urlencode "endDate=$OMNIA_END_DATE" \
  --data-urlencode 'engine=openai' \
  --data-urlencode 'pageSize=100'
```

The [endpoint reference](https://docs.useomnia.com/api/brand/performance/get-share-of-voice-aggregates) documents `engine`, `locations`, `tags`, and `promptType` (`Branded` or `Non-Branded`) filters. Results include `data.aggregates` with `brand`, `mentionCount`, `rank`, `relationship`, and `shareOfVoice`. Share of Voice is each brand's portion of all brand mentions in the sampled answers, not its citation rate. Preserve filters and sampling when comparing periods.

### Inspect the Evidence

These are read-only operations; consult each linked schema for required parameters and response fields:

| Job | Endpoint | Reference |
|-----|----------|-----------|
| Measure brand appearance | `GET /brands/{brand}/visibility/aggregates` | [Visibility aggregates](https://docs.useomnia.com/api/brand/performance/get-visibility-aggregates) |
| Analyze sentiment by brand and feature | `GET /brands/{brand}/sentiment/aggregates` | [Sentiment aggregates](https://docs.useomnia.com/api/brand/performance/get-sentiment-aggregates) |
| Read brand details | `GET /brands/{brand}` | [Brand details](https://docs.useomnia.com/api/brand/get-brand) |
| List answers behind a prompt's metrics | `GET /prompts/{prompt}/ai-answers` | [AI answers](https://docs.useomnia.com/api/ai-answer/list-ai-answers) |
| Read one answer's full text and citations | `GET /ai-answers/{ai-answer}` | [AI answer](https://docs.useomnia.com/api/ai-answer/get-ai-answer) |
| Find cited pages for a prompt | `GET /prompts/{prompt}/citations/aggregates` | [Citation aggregates](https://docs.useomnia.com/api/prompt/performance/get-citations-aggregates) |
| Compare share of voice over time | `GET /brands/{brand}/share-of-voice/timeseries` | [Time series](https://docs.useomnia.com/api/brand/performance/get-share-of-voice-time-series) |

Paths are relative to the API base URL. AI-answer and performance queries require `startDate` and `endDate`. Visibility measures the share of monitored prompts whose answers mention a brand; sentiment aggregates count endorsed, undermined, and neutral feature mentions. The answer listing returns metadata (engine, `mentioned`, `mentionedBrands`, cited `domains`), not the answer text; fetch individual answers to read the wording and distinguish recommendations from passing mentions, and read cited pages before treating brand absence as a content gap.

## Practical Workflows

1. **Visibility monitoring:** Select commercially relevant tracked prompts, record engine/location/date filters, compare brand mentions and Share of Voice across equal periods.
2. **Competitor analysis:** Compare `competitor` rows in visibility and Share of Voice aggregates, and check `mentionedBrands` in AI answers. Review recurring recommendations and their context.
3. **Citation-gap analysis:** Inspect cited URLs for prompts where competing brands appear and the user's brand does not. Check whether those pages actually cover the competitors, then distinguish missing owned answers from missing credible third-party coverage.
4. **Prioritize improvements:** Combine repeated gaps with customer questions, product fit, available evidence, and effort. Draft page updates, content briefs, or relevant third-party outreach opportunities; remeasure the same prompts after publishing. Observed patterns inform priorities; they do not prove a cause or guarantee a remedy.

Use the `ai-seo` and `content-strategy` skills for decisions and execution beyond data retrieval.

## Limitations and Prerequisites

- An active account, accessible brand, and collected prompt-monitoring data are required for meaningful analysis. Confirm plan entitlements, monitoring limits, and credits before enabling monitoring.
- MCP uses interactive OAuth. For unattended scripts, use the documented API-key flow (keys start with `ot_`); store the key in `OMNIA_API_KEY`. API-key authentication on the MCP server is not documented here.
- Rate limits: token bucket; each GET costs 1 token and each write costs 5. Check `X-RateLimit-Remaining`, and on `429` back off using `Retry-After`. See [rate limiting](https://docs.useomnia.com/api/rate-limiting).
- Some operations consume credits (e.g., generating insights). Check your account's credit balance before enabling automated workflows that may spend credits.
- AI answers vary between runs, engines, locations, and time periods. Monitoring reflects the configured prompt sample, not every buyer conversation or actual search demand. Citation changes do not prove an intervention caused recommendations.
- APIs also support writes. Read the current schema and confirm intended scope before changing brands, prompts, or monitoring; deletions can remove history permanently.
- Follow pagination `links.next` until exhausted (`pageSize` accepts 5–100). AI-answer listing warns that page lengths and reported totals can be approximate. See [pagination](https://docs.useomnia.com/api/pagination) and the AI-answer reference above.
- Response shapes vary by endpoint. Parse the documented `data` fields; [streaming metrics exports](https://docs.useomnia.com/api/brand/performance/stream-metrics-export) use NDJSON, while [asynchronous metrics exports](https://docs.useomnia.com/api/brand/performance/create-metrics-export-task) produce a downloadable ZIP with NDJSON or CSV files. Exports cover Share of Voice, visibility, and citations at brand or prompt granularity. Async results can be obtained by polling or completion webhooks; see [responses](https://docs.useomnia.com/api/responses) and [async operations](https://docs.useomnia.com/api/async-operations).

## Documentation

- [REST API overview](https://docs.useomnia.com/api)
- [MCP overview and tool families](https://docs.useomnia.com/mcp)

## File: tools/integrations/onesignal.md

# OneSignal

Push notification, email, SMS, and in-app messaging platform for customer engagement at scale.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Notifications, Users, Segments, Templates, Apps |
| MCP | - | Not available |
| CLI | ✓ | [onesignal.js](../clis/onesignal.js) |
| SDK | ✓ | JavaScript, Node.js, Python, Java, PHP, Ruby, Go, .NET |

## Authentication

- **Type**: App API Key
- **Header**: `Authorization: Key {REST_API_KEY}`
- **App ID**: Required as `app_id` in request bodies
- **Get credentials**: Dashboard > Settings > Keys & IDs
- **Security**: HTTPS required, TLS 1.2+ on port 443

## Common Agent Operations

### Send push notification to segment

```bash
POST https://api.onesignal.com/api/v1/notifications

Headers:
  Authorization: Key {REST_API_KEY}
  Content-Type: application/json

{
  "app_id": "YOUR_APP_ID",
  "included_segments": ["Subscribed Users"],
  "headings": { "en": "New Feature!" },
  "contents": { "en": "Check out our latest update." },
  "url": "https://example.com/feature"
}
```

### Send notification to specific users

```bash
POST https://api.onesignal.com/api/v1/notifications

Headers:
  Authorization: Key {REST_API_KEY}
  Content-Type: application/json

{
  "app_id": "YOUR_APP_ID",
  "include_aliases": { "external_id": ["user-123", "user-456"] },
  "target_channel": "push",
  "contents": { "en": "You have a new message." }
}
```

### Send email using the local CLI

```bash
node tools/clis/onesignal.js notifications send --emails "user@example.com" --email-subject "Welcome" --email-body "<p>Thanks for joining.</p>"
node tools/clis/onesignal.js notifications send --channel email --segment "Customers" --heading "News" --message "<p>Product update.</p>"
```

Email sends require an email subject and HTML body. `--heading` and `--message` remain aliases for these email fields. `--emails` selects the email channel automatically; `--channel email` also works with existing alias, segment, or subscription targeting. Push remains the default channel, and SMS uses `--channel sms --message ...`. An explicit incompatible channel with `--emails` is rejected locally.

The send command uses the current `/notifications?c=<channel>` resource, `target_channel`, and `email_to` for direct email recipients. It does not send push `contents`, `headings`, `url`, `data`, or `ttl` as email content. `--dry-run` previews the same request with masked authorization and no network request.

Primary contracts: [Email](https://documentation.onesignal.com/reference/email), [SMS](https://documentation.onesignal.com/reference/sms), and [sending messages](https://documentation.onesignal.com/reference/create-message).

### Schedule a notification

```bash
POST https://api.onesignal.com/api/v1/notifications

Headers:
  Authorization: Key {REST_API_KEY}
  Content-Type: application/json

{
  "app_id": "YOUR_APP_ID",
  "included_segments": ["Subscribed Users"],
  "contents": { "en": "Scheduled notification" },
  "send_after": "2025-12-01 12:00:00 GMT-0500"
}
```

### List notifications

```bash
GET https://api.onesignal.com/api/v1/notifications?app_id={APP_ID}&limit=50&offset=0

Headers:
  Authorization: Key {REST_API_KEY}
```

### View a notification

```bash
GET https://api.onesignal.com/api/v1/notifications/{notification_id}?app_id={APP_ID}

Headers:
  Authorization: Key {REST_API_KEY}
```

### Cancel a scheduled notification

```bash
DELETE https://api.onesignal.com/api/v1/notifications/{notification_id}?app_id={APP_ID}

Headers:
  Authorization: Key {REST_API_KEY}
```

### List segments

```bash
GET https://api.onesignal.com/api/v1/apps/{APP_ID}/segments

Headers:
  Authorization: Key {REST_API_KEY}
```

### Create a segment

```bash
POST https://api.onesignal.com/api/v1/apps/{APP_ID}/segments

Headers:
  Authorization: Key {REST_API_KEY}
  Content-Type: application/json

{
  "name": "Active Users",
  "filters": [
    { "field": "session_count", "relation": ">", "value": "5" }
  ]
}
```

### Get user by external ID

```bash
GET https://api.onesignal.com/apps/{APP_ID}/users/by/external_id/{external_id}

Headers:
  Authorization: Key {REST_API_KEY}
```

### Create a user

```bash
POST https://api.onesignal.com/apps/{APP_ID}/users

Headers:
  Authorization: Key {REST_API_KEY}
  Content-Type: application/json

{
  "identity": { "external_id": "user-789" },
  "subscriptions": [
    { "type": "Email", "token": "user@example.com" }
  ],
  "properties": { "tags": { "plan": "pro", "signup_source": "organic" } }
}
```

### List templates

```bash
GET https://api.onesignal.com/api/v1/templates?app_id={APP_ID}

Headers:
  Authorization: Key {REST_API_KEY}
```

## Key Metrics

### Notification Metrics
- `successful` - Number of successful deliveries
- `failed` - Number of failed deliveries
- `converted` - Users who clicked/converted
- `remaining` - Notifications still queued
- `errored` - Count of errors
- `opened` - Notification open count

### User Metrics
- `session_count` - Total user sessions
- `last_active` - Last activity timestamp
- `tags` - Custom key-value metadata
- `subscriptions` - Active subscription channels

## Parameters

### Notification Parameters
- `app_id` - Application ID (required)
- `included_segments` - Target segments array
- `excluded_segments` - Excluded segments array
- `include_aliases` - Target specific users by alias
- `target_channel` - Channel: `push`, `email`, `sms`
- `contents` - Message content by language code
- `headings` - Notification title by language code
- `url` - Launch URL on click
- `data` - Custom key-value data payload
- `send_after` - Scheduled send time (UTC string)
- `ttl` - Time to live in seconds

### Segment Filter Fields
- `session_count` - Number of sessions
- `first_session` - First session date
- `last_session` - Last session date
- `tag` - Custom tag value
- `language` - User language
- `app_version` - App version
- `country` - User country code

## When to Use

- Sending push notifications for product updates
- Triggered notifications based on user behavior
- Multi-channel messaging (push + email + SMS)
- Re-engagement campaigns for inactive users
- Segmenting users for targeted messaging
- A/B testing notification content
- Scheduling promotional campaigns

## Rate Limits

- **Free Plan**: 150 notification requests/second per app
- **Paid Plan**: 6,000 notification requests/second per app
- **User/Subscription ops**: 1,000 requests/second per app
- **Burst limit**: No more than 10x total subscribers in 15 minutes
- **429 response**: Includes `RetryAfter` header with seconds to wait

## Relevant Skills

- push-notifications
- customer-engagement
- retention-campaign
- re-engagement
- lifecycle-marketing

## File: tools/integrations/optimizely.md

# Optimizely

A/B testing and experimentation platform with a REST API for managing projects, experiments, campaigns, and results.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Projects, Experiments, Campaigns, Audiences, Results |
| MCP | - | Not available |
| CLI | ✓ | [optimizely.js](../clis/optimizely.js) |
| SDK | ✓ | JavaScript, Python, Ruby, Java, Go, C#, PHP, React, Swift, Android |

## Authentication

- **Type**: Bearer Token (Personal Access Token or OAuth 2.0)
- **Header**: `Authorization: Bearer {personal_token}`
- **Get token**: https://app.optimizely.com/v2/profile/api > Generate New Token

## Common Agent Operations

### List Projects

```bash
GET https://api.optimizely.com/v2/projects
```

### Get Project

```bash
GET https://api.optimizely.com/v2/projects/{project_id}
```

### List Experiments

```bash
GET https://api.optimizely.com/v2/experiments?project_id={project_id}
```

### Get Experiment

```bash
GET https://api.optimizely.com/v2/experiments/{experiment_id}
```

### Get Experiment Results

```bash
GET https://api.optimizely.com/v2/experiments/{experiment_id}/results
```

### Create Experiment

```bash
POST https://api.optimizely.com/v2/experiments

{
  "project_id": 12345,
  "name": "Homepage CTA Test",
  "type": "a/b",
  "variations": [
    { "name": "Control", "weight": 5000 },
    { "name": "Variation 1", "weight": 5000 }
  ],
  "metrics": [{ "event_id": 67890 }],
  "status": "not_started"
}
```

### Update Experiment

```bash
PATCH https://api.optimizely.com/v2/experiments/{experiment_id}

{
  "status": "running"
}
```

### List Campaigns

```bash
GET https://api.optimizely.com/v2/campaigns?project_id={project_id}
```

### Get Campaign Results

```bash
GET https://api.optimizely.com/v2/campaigns/{campaign_id}/results
```

### List Audiences

```bash
GET https://api.optimizely.com/v2/audiences?project_id={project_id}
```

### List Events

```bash
GET https://api.optimizely.com/v2/events?project_id={project_id}
```

### List Pages

```bash
GET https://api.optimizely.com/v2/pages?project_id={project_id}
```

## Key Metrics

### Experiment Results
- `variation_id` - Variation identifier
- `variation_name` - Variation display name
- `visitors` - Unique visitors per variation
- `conversions` - Conversion count
- `conversion_rate` - Rate as decimal
- `improvement` - Percentage improvement vs. control
- `statistical_significance` - Confidence level
- `is_baseline` - Whether this is the control

### Experiment Properties
- `name` - Experiment name
- `status` - not_started, running, paused, archived
- `type` - a/b, multivariate, personalization
- `traffic_allocation` - Percentage of traffic (0-10000 = 0-100%)
- `variations` - Array of variations with weights

## Parameters

### List Experiments
- `project_id` (required) - Project to list experiments for
- `page` - Page number
- `per_page` - Results per page (default: 25)
- `status` - Filter by status

### Get Results
- `start_time` - Results start time (ISO 8601)
- `end_time` - Results end time (ISO 8601)

### Create Experiment
- `project_id` (required) - Parent project
- `name` (required) - Experiment name
- `type` - Experiment type (default: a/b)
- `variations` (required) - Array of variations with name and weight
- `metrics` - Array of metric/event configurations
- `audience_conditions` - Targeting conditions
- `traffic_allocation` - Traffic percentage (0-10000)

## When to Use

- Running A/B tests on web pages and features
- Managing experimentation programs at scale
- Pulling experiment results for analysis
- Automating experiment creation and monitoring
- Feature flag management
- Personalization campaigns

## Rate Limits

- 50 requests/second per personal token
- Pagination via `page` and `per_page` parameters
- OpenAPI spec available at https://api.optimizely.com/v2/swagger.json

## Relevant Skills

- ab-testing
- cro
- landing-page
- personalization
- analytics

## File: tools/integrations/outreach.md

# Outreach

Sales engagement platform for managing prospects, sequences, and outbound campaigns at scale.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Prospects, Sequences, Mailings, Accounts, Tasks |
| MCP | ✓ | Official remote server at `https://api.outreach.io/mcp/` (OAuth); requires a licensed seat and the Amplify add-on; no update tools yet ([docs](https://developers.outreach.io/mcp-server)) |
| CLI | ✓ | [outreach.js](../clis/outreach.js) |
| SDK | - | REST API only (JSON:API format) |

## Authentication

- **Type**: OAuth2 Bearer Token
- **Header**: `Authorization: Bearer {access_token}`
- **Content-Type**: `application/vnd.api+json`
- **Get token**: Settings > API at https://app.outreach.io or via OAuth2 flow

## Common Agent Operations

### List Prospects

```bash
curl -s https://api.outreach.io/api/v2/prospects \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

### Get a Prospect

```bash
curl -s https://api.outreach.io/api/v2/prospects/42 \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

### Create a Prospect

```bash
curl -s -X POST https://api.outreach.io/api/v2/prospects \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json" \
  -d '{
    "data": {
      "type": "prospect",
      "attributes": {
        "emails": ["jane@example.com"],
        "firstName": "Jane",
        "lastName": "Doe"
      }
    }
  }'
```

### List Sequences

```bash
curl -s https://api.outreach.io/api/v2/sequences \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

### Add Prospect to Sequence

```bash
curl -s -X POST https://api.outreach.io/api/v2/sequenceStates \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json" \
  -d '{
    "data": {
      "type": "sequenceState",
      "relationships": {
        "prospect": { "data": { "type": "prospect", "id": 42 } },
        "sequence": { "data": { "type": "sequence", "id": 7 } },
        "mailbox": { "data": { "type": "mailbox", "id": 9 } }
      }
    }
  }'
```

For sequences with mailing steps, pass `--mailbox-id` to `sequence-states create`
to select the sending mailbox. It is included as the `mailbox` relationship.
Non-mail sequences can omit it. See
[add prospects to sequences](https://developers.outreach.io/api/common-patterns).


### List Mailings for a Sequence

```bash
curl -s "https://api.outreach.io/api/v2/mailings?filter[sequence][id]=7" \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

### List Accounts

```bash
curl -s https://api.outreach.io/api/v2/accounts \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

### List Tasks

```bash
curl -s "https://api.outreach.io/api/v2/tasks?filter[state]=incomplete" \
  -H "Authorization: Bearer $OUTREACH_ACCESS_TOKEN" \
  -H "Content-Type: application/vnd.api+json"
```

## Key Metrics

### Prospect Data
- `firstName`, `lastName` - Name
- `emails` - Email addresses
- `title` - Job title
- `company` - Company name
- `tags` - Prospect tags
- `engagedAt` - Last engagement timestamp

### Sequence Data
- `name` - Sequence name
- `enabled` - Whether sequence is active
- `sequenceType` - Type (e.g., interval, date-based)
- `stepCount` - Number of steps
- `openCount`, `clickCount`, `replyCount` - Engagement metrics

### Mailing Data
- `mailingType` - Type of mailing
- `state` - Delivery state
- `openCount`, `clickCount` - Engagement
- `deliveredAt`, `openedAt`, `clickedAt` - Timestamps

## Parameters

### Collection pagination

All CLI list commands support `--after <cursor>` or `--before <cursor>` plus `--per-page <n>` (maximum 1000). Take the opaque token from the API's `links.next` or `links.prev` URL; the CLI encodes it as `page[after]` or `page[before]` and preserves existing resource filters.

```bash
node tools/clis/outreach.js tasks list --state pending --after '<next-cursor>' --per-page 50
node tools/clis/outreach.js mailings list --sequence-id 123 --after '<next-cursor>'
```

The existing `--page <n>` spelling remains a compatibility option: it translates to the documented `page[offset]` and `page[limit]` using the requested size (default 50). Outreach deprecates offset pagination and caps the offset at 10,000; prefer cursor pagination for large collections. Cursor directions and `--page` cannot be combined. Default unfiltered requests remain unchanged. The CLI performs one request per invocation.

Source: [Outreach request and pagination contracts](https://developers.outreach.io/api/making-requests#pagination).

### Prospects
- `filter[emails]` - Filter by email
- `filter[firstName]` - Filter by first name
- `filter[lastName]` - Filter by last name
- `sort` - Sort field (e.g., `createdAt`, `-updatedAt`)

### Sequences
- `filter[name]` - Filter by sequence name
- `filter[enabled]` - Filter by active status

### Mailings
- `filter[sequence][id]` - Filter by sequence ID
- `filter[prospect][id]` - Filter by prospect ID

### Tasks
- `filter[state]` - Filter by state (e.g., `pending`, `incomplete`, `complete`)
- `filter[taskType]` - Filter by type (e.g., `call`, `email`, `action_item`)

## When to Use

- Managing outbound sales sequences and cadences
- Adding prospects to automated email sequences
- Tracking prospect engagement across touchpoints
- Managing sales tasks and follow-ups
- Coordinating multi-channel outreach campaigns
- Monitoring sequence performance and reply rates

## Rate Limits

- 10,000 requests per hour per user
- Burst limit: 100 requests per 10 seconds
- Rate limit headers returned: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
- 429 responses when limits exceeded

## Relevant Skills

- cold-email
- revops
- sales-enablement
- emails

The task filter is `state` (`pending`, `incomplete`, or `complete`). Use
`tasks list --state incomplete`; the CLI retains `--status` as an alias.
See [discover open tasks](https://developers.outreach.io/api/common-patterns).

Without pagination flags the CLI leaves provider defaults untouched. The legacy
`--page` option explicitly uses a default limit of 50 when `--per-page` is absent;
cursor pagination uses `page[size]`, while legacy offsets use `page[limit]`.

## File: tools/integrations/paddle.md

# Paddle

SaaS billing and payments platform with built-in tax compliance, acting as merchant of record for global sales.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for products, prices, subscriptions, transactions |
| MCP | - | Not available |
| CLI | ✓ | [paddle.js](../clis/paddle.js) |
| SDK | ✓ | Node.js, Python, PHP, Go |

## Authentication

- **Type**: Bearer Token
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Paddle dashboard > Developer Tools > Authentication
- **Production URL**: `https://api.paddle.com`
- **Sandbox URL**: `https://sandbox-api.paddle.com`
- **Note**: Version specified via header, not path. Set `PADDLE_SANDBOX=true` env var for sandbox.

## Common Agent Operations

### List products

```bash
GET https://api.paddle.com/products
```

### Create a product

```bash
POST https://api.paddle.com/products

{
  "name": "Pro Plan",
  "tax_category": "standard",
  "description": "Professional tier subscription"
}
```

### Create a price for a product

```bash
POST https://api.paddle.com/prices

{
  "product_id": "pro_01abc...",
  "description": "Monthly Pro",
  "unit_price": {
    "amount": "2999",
    "currency_code": "USD"
  },
  "billing_cycle": {
    "interval": "month",
    "frequency": 1
  }
}
```

### List customers

```bash
GET https://api.paddle.com/customers
```

### Create a customer

```bash
POST https://api.paddle.com/customers

{
  "email": "customer@example.com",
  "name": "Jane Smith"
}
```

### List subscriptions

```bash
GET https://api.paddle.com/subscriptions?status=active
```

### Get subscription details

```bash
GET https://api.paddle.com/subscriptions/{subscription_id}
```

### Change a subscription plan or billing date

Use the subscription update operation, with an explicit proration choice:

```bash
node tools/clis/paddle.js subscriptions update --id sub_01example \
  --items '[{"price_id":"pri_01example","quantity":1}]' \
  --proration-billing-mode prorated_next_billing_period --dry-run

node tools/clis/paddle.js subscriptions update --id sub_01example \
  --next-billed-at 2026-11-01T00:00:00Z \
  --proration-billing-mode do_not_bill --dry-run
```

`--items` replaces the **complete** subscription item list. Include retained items; omitted items are removed. Check the dry-run payload and the chosen billing mode before running without `--dry-run`. The CLI does not pick a billing policy for you. Existing `--scheduled-change null` still removes a scheduled change without an item or billing-date edit.

[Paddle's update contract](https://developer.paddle.com/api-reference/subscriptions/update-subscription/) requires `proration_billing_mode` when changing items or the next billing date; its [proration guide](https://developer.paddle.com/concepts/subscriptions/proration/) explains the available modes.

### Cancel a subscription

```bash
POST https://api.paddle.com/subscriptions/{subscription_id}/cancel

{
  "effective_from": "next_billing_period"
}
```

### Pause a subscription

```bash
POST https://api.paddle.com/subscriptions/{subscription_id}/pause
```

### List transactions

```bash
GET https://api.paddle.com/transactions
```

### Create a discount

```bash
POST https://api.paddle.com/discounts

{
  "amount": "20",
  "type": "percentage",
  "description": "20% off first month",
  "code": "WELCOME20"
}
```

### Create a refund adjustment

```bash
POST https://api.paddle.com/adjustments

{
  "transaction_id": "txn_01abc...",
  "action": "refund",
  "reason": "Customer requested refund",
  "items": [{"item_id": "txnitm_01abc...", "type": "full"}]
}
```

### List events

```bash
GET https://api.paddle.com/events
```

### List event types

```bash
GET https://api.paddle.com/event-types
```

## Key Metrics

### Transaction Metrics
- `totals.total` - Total amount charged
- `totals.tax` - Tax amount
- `totals.subtotal` - Amount before tax
- `totals.discount` - Discount applied
- `currency_code` - Transaction currency

### Subscription Metrics
- `status` - active, canceled, paused, past_due, trialing
- `current_billing_period` - Current period start/end
- `next_billed_at` - Next billing date
- `scheduled_change` - Pending changes (cancellation, plan change)

### Product/Price Metrics
- `unit_price.amount` - Price in lowest denomination
- `billing_cycle` - Interval and frequency
- `trial_period` - Trial duration if set

## Parameters

### List Filtering
- `status` - Filter by status (e.g., active, archived)
- `after` - Cursor for pagination
- `per_page` - Results per page (default: 50)
- `order_by` - Sort field and direction

### Subscription Cancel Options
- `effective_from` - `immediately` or `next_billing_period`

### Price Billing Cycle
- `interval` - `day`, `week`, `month`, `year`
- `frequency` - Number of intervals between billings

### Tax Categories
- `standard` - Standard tax rate
- `digital-goods` - Digital goods tax rate
- `saas` - SaaS-specific tax rate

## When to Use

- Managing SaaS subscription billing with tax compliance
- Creating products and pricing tiers
- Processing refunds and adjustments
- Handling subscription lifecycle (create, pause, cancel, resume)
- Global tax handling as merchant of record
- Discount and coupon management for promotions

## Rate Limits

- 100 requests per minute
- Applies across all endpoints
- HTTP 429 returned when exceeded

## Relevant Skills

- pricing-page
- saas-metrics
- churn-reduction
- launch-sequence
- monetization-strategy

## File: tools/integrations/partnerstack.md

# PartnerStack

Partner and affiliate program management platform for SaaS companies with deal tracking, rewards, and multi-tier partnerships.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Vendor API v2 for partnerships, deals, customers, transactions |
| MCP | - | Not available |
| CLI | ✓ | [partnerstack.js](../clis/partnerstack.js) |
| SDK | - | No official SDK; REST API with Basic Auth |

## Authentication

- **Type**: Basic Auth (Vendor API)
- **Header**: `Authorization: Basic {base64(public_key:secret_key)}`
- **Get credentials**: Vendor dashboard > Settings > Integrations > PartnerStack API Keys
- **Note**: Separate Test and Production API keys. Test transactions can only be added to customers created with Test keys.

## Common Agent Operations

### List partnerships

```bash
GET https://api.partnerstack.com/api/v2/partnerships?limit=25

Authorization: Basic {base64(public_key:secret_key)}
```

### Create a partnership

```bash
POST https://api.partnerstack.com/api/v2/partnerships

{
  "email": "partner@example.com",
  "group_key": "affiliates",
  "first_name": "Jane",
  "last_name": "Smith"
}
```

### List customers

```bash
GET https://api.partnerstack.com/api/v2/customers?limit=25
```

### Create a customer (attribute to partner)

```bash
POST https://api.partnerstack.com/api/v2/customers

{
  "email": "customer@example.com",
  "partner_key": "prtnr_abc123",
  "name": "John Doe"
}
```

### Record a transaction

```bash
POST https://api.partnerstack.com/api/v2/transactions

{
  "customer_key": "cust_abc123",
  "amount": 9900,
  "currency": "USD",
  "product_key": "pro_plan"
}
```

### List deals

```bash
GET https://api.partnerstack.com/api/v2/deals?limit=25
```

### Create a deal

```bash
POST https://api.partnerstack.com/api/v2/deals

{
  "partner_key": "prtnr_abc123",
  "name": "Enterprise Opportunity",
  "amount": 50000,
  "stage": "qualified"
}
```

### Record an action (event-based rewards)

The CLI maps `--customer-key` to the customer target and `--action-key` to
the action `type`. `--value` is the number of occurrences, defaulting to one.

```bash
POST https://api.partnerstack.com/api/v2/actions

{
  "target_key": "cust_abc123",
  "target_type": "customer",
  "type": "signup_completed",
  "value": 1
}
```

### Create a reward

```bash
POST https://api.partnerstack.com/api/v2/rewards

{
  "partner_key": "prtnr_abc123",
  "amount": 5000,
  "description": "Bonus for Q1 performance"
}
```

### List leads

```bash
GET https://api.partnerstack.com/api/v2/leads?limit=25
```

### Create a lead

```bash
POST https://api.partnerstack.com/api/v2/leads

{
  "partner_key": "prtnr_abc123",
  "email": "lead@company.com",
  "name": "Potential Customer",
  "company": "Acme Corp"
}
```

### List partner groups

```bash
GET https://api.partnerstack.com/api/v2/groups
```

### Manage webhooks

Both the destination URL and a nonempty event list are required when creating
a webhook (`--target` and `--events` in the CLI).

```bash
POST https://api.partnerstack.com/api/v2/webhooks

{
  "target_url": "https://example.com/webhooks/partnerstack",
  "events": ["deal.created", "transaction.created", "customer.created"]
}
```

## API Pattern

PartnerStack uses cursor-based pagination. List responses include `has_more` and item keys for `starting_after` / `ending_before` parameters.

All responses follow the format:
```json
{
  "data": { ... },
  "message": "...",
  "status": "2xx"
}
```

## Key Metrics

### Partnership Metrics
- `partner_key` - Unique partner identifier
- `group` - Partner tier/group
- `status` - active, pending, archived
- `created_at` - Partnership start date

### Transaction Metrics
- `amount` - Transaction value in cents
- `currency` - Currency code
- `product_key` - Associated product
- `customer_key` - Associated customer

### Deal Metrics
- `amount` - Deal value
- `stage` - Deal pipeline stage
- `status` - open, won, lost

### Reward Metrics
- `amount` - Reward amount in cents
- `status` - pending, approved, paid

## Parameters

### Pagination Parameters
- `limit` - Items per page (1-250, default: 10)
- `starting_after` - Cursor for next page (item key)
- `ending_before` - Cursor for previous page (item key)
- `order_by` - Sort field, prefix with `-` for descending

### Common Filters
- `include_archived` - Include archived records
- `has_sub_id` - Filter by sub ID presence

## When to Use

- Managing SaaS affiliate and referral programs
- Tracking partner-driven revenue and attributions
- Automating partner onboarding and rewards
- Deal registration and pipeline tracking
- Multi-tier partnership programs (affiliates, resellers, agencies)
- Event-based reward triggers (signups, upgrades, etc.)

## Rate Limits

- Not explicitly documented
- Use reasonable request rates; implement exponential backoff on 429 responses

## Relevant Skills

- referrals
- affiliate-marketing
- partner-enablement
- saas-metrics
- launch-sequence

## File: tools/integrations/pendo.md

# Pendo

Product analytics and in-app guidance platform for tracking user behavior, measuring feature adoption, and delivering targeted in-app messages.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Features, Pages, Guides, Visitors, Accounts, Reports, Metadata |
| MCP | - | Not available |
| CLI | ✓ | [pendo.js](../clis/pendo.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: Integration Key
- **Header**: `x-pendo-integration-key: {key}`
- **Get key**: Settings > Integrations at https://app.pendo.io

## Common Agent Operations

### List Features

```bash
GET https://app.pendo.io/api/v1/feature
```

### Get Feature Details

```bash
GET https://app.pendo.io/api/v1/feature/{featureId}
```

### List Pages

```bash
GET https://app.pendo.io/api/v1/page
```

### Get Page Details

```bash
GET https://app.pendo.io/api/v1/page/{pageId}
```

### List Guides

```bash
GET https://app.pendo.io/api/v1/guide?state=public
```

### Get Guide Details

```bash
GET https://app.pendo.io/api/v1/guide/{guideId}
```

### Get Visitor Data

```bash
GET https://app.pendo.io/api/v1/visitor/{visitorId}
```

### Search Visitors

```bash
POST https://app.pendo.io/api/v1/aggregation

{
  "response": { "mimeType": "application/json" },
  "request": {
    "pipeline": [
      { "source": { "visitors": null } },
      { "filter": "lastVisitedAt > 1700000000000" }
    ]
  }
}
```

### Get Account Data

```bash
GET https://app.pendo.io/api/v1/account/{accountId}
```

### Search Accounts

```bash
POST https://app.pendo.io/api/v1/aggregation

{
  "response": { "mimeType": "application/json" },
  "request": {
    "pipeline": [
      { "source": { "accounts": null } },
      { "filter": "metadata.auto.lastupdated > 1700000000000" }
    ]
  }
}
```

### Run Funnel Report

```bash
POST https://app.pendo.io/api/v1/aggregation

{
  "response": { "mimeType": "application/json" },
  "request": {
    "pipeline": [
      { "source": { "visitors": null, "timeSeries": { "period": "dayRange", "first": 1700000000000, "last": 1700600000000 } } },
      { "identified": "visitorId" },
      { "filter": "pageId == \"page-id-1\"" },
      { "filter": "pageId == \"page-id-2\"" }
    ]
  }
}
```

`reports funnel --pipeline` accepts a JSON array of aggregation steps and wraps it
in `response.mimeType` and `request.pipeline`, as described in Pendo's
[aggregation guide](https://www.pendo.io/pendo-blog/pendo-aggs-writing-your-first-aggregation/).
Existing full aggregation objects are also accepted, preserving request settings.
The supplied steps determine the report; the CLI does not construct funnel logic.

```bash
node tools/clis/pendo.js reports funnel \
  --pipeline '[{"source":{"visitors":null}},{"limit":10}]' --dry-run
```

### List Metadata Fields

```bash
GET https://app.pendo.io/api/v1/metadata/schema/visitor
GET https://app.pendo.io/api/v1/metadata/schema/account
GET https://app.pendo.io/api/v1/metadata/schema/parentAccount
```

## Key Metrics

### Feature Data
- `id` - Feature ID
- `name` - Feature name
- `kind` - Feature type
- `elementPath` - CSS selector for the tracked element
- `pageId` - Associated page ID
- `numEvents` - Event count
- `numVisitors` - Unique visitor count

### Page Data
- `id` - Page ID
- `name` - Page name
- `rules` - URL matching rules
- `numEvents` - Pageview count
- `numVisitors` - Unique visitor count

### Guide Data
- `id` - Guide ID
- `name` - Guide name
- `state` - Guide state (draft, staged, public, disabled)
- `launchMethod` - How the guide is triggered
- `steps` - Guide step definitions
- `numSteps` - Number of steps
- `numViews` - Total views
- `numVisitors` - Unique visitors who saw the guide

### Visitor Data
- `visitorId` - Unique visitor identifier
- `lastVisitedAt` - Last visit timestamp
- `firstVisit` - First visit timestamp
- `numEvents` - Total event count
- `metadata` - Custom visitor metadata

### Account Data
- `accountId` - Unique account identifier
- `lastVisitedAt` - Last visit from any account member
- `numVisitors` - Number of visitors in the account
- `metadata` - Custom account metadata

## Parameters

### Guide Filtering
- `state` - Filter by state: draft, staged, public, disabled

### Aggregation Queries
- `source` - Data source: visitors, accounts, features, pages, guides
- `filter` - Expression-based filtering
- `sort` - Sort results
- `limit` - Max results to return
- `timeSeries` - Time range with period, first, last

### Metadata Kinds
- `visitor` - Visitor metadata schema
- `account` - Account metadata schema
- `parentAccount` - Parent account metadata schema

## When to Use

- Tracking feature adoption and usage patterns
- Building and managing in-app onboarding guides
- Analyzing user behavior across pages and features
- Segmenting users by engagement level
- Running funnel analysis on user journeys
- Identifying at-risk accounts based on usage decline
- A/B testing in-app messages and tooltips

## Rate Limits

- Rate limits vary by plan
- Standard: 500 requests per minute
- Aggregation queries: may take longer for large datasets
- Use pagination for large result sets

## Relevant Skills

- analytics
- onboarding
- churn-prevention
- ab-testing

## File: tools/integrations/plausible.md

# Plausible Analytics

Privacy-focused, open-source web analytics with a simple API for stats queries without cookies or personal data collection.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Stats v2 Query, Sites Provisioning, Goals, Shared Links |
| MCP | - | Not available |
| CLI | ✓ | [plausible.js](../clis/plausible.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: Bearer Token
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: https://plausible.io/settings > API Keys
- **Note**: Sites API requires Enterprise plan

## Common Agent Operations

### Stats Query (v2)

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "pageviews", "bounce_rate", "visit_duration"],
  "date_range": "30d"
}
```

### Top Pages

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "pageviews"],
  "date_range": "30d",
  "dimensions": ["event:page"]
}
```

### Traffic Sources

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "bounce_rate"],
  "date_range": "30d",
  "dimensions": ["visit:source"]
}
```

### Time Series

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "pageviews"],
  "date_range": "30d",
  "dimensions": ["time:day"]
}
```

### Breakdown by Country

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "percentage"],
  "date_range": "30d",
  "dimensions": ["visit:country"]
}
```

### Filtered Query (specific page)

```bash
POST https://plausible.io/api/v2/query

{
  "site_id": "example.com",
  "metrics": ["visitors", "pageviews", "bounce_rate"],
  "date_range": "30d",
  "filters": [["is", "event:page", ["/pricing"]]]
}
```

### Realtime Visitors (v1)

```bash
GET https://plausible.io/api/v1/stats/realtime/visitors?site_id=example.com
```

### List Sites

```bash
GET https://plausible.io/api/v1/sites
```

## Key Metrics

### Available Metrics
- `visitors` - Unique visitors
- `visits` - Total visits (sessions)
- `pageviews` - Total page views
- `views_per_visit` - Pages per session
- `bounce_rate` - Bounce rate percentage
- `visit_duration` - Average session duration (seconds)
- `events` - Total events
- `conversion_rate` - Goal conversion rate
- `time_on_page` - Average time on page
- `scroll_depth` - Average scroll depth
- `percentage` - Share of total

### Available Dimensions
- `event:page` - Page path
- `event:goal` - Goal name
- `visit:source` - Traffic source
- `visit:referrer` - Referrer URL
- `visit:channel` - Traffic channel
- `visit:utm_source`, `visit:utm_medium`, `visit:utm_campaign` - UTM params
- `visit:device` - Device type
- `visit:browser` - Browser name
- `visit:os` - Operating system
- `visit:country`, `visit:region`, `visit:city` - Location
- `visit:entry_page`, `visit:exit_page` - Entry/exit pages
- `time`, `time:day`, `time:week`, `time:month` - Time periods

## Parameters

### Stats Query (v2)
- `site_id` (required) - Domain registered in Plausible
- `metrics` (required) - Array of metrics to return
- `date_range` (required) - Time period: "day", "7d", "30d", "month", "6mo", "12mo", "year", or custom ["2024-01-01", "2024-01-31"]
- `dimensions` - Array of dimensions to group by
- `filters` - Array of filter conditions: `[operator, dimension, values]`
- `order_by` - Array of sort specs: `[[metric, "desc"]]`
- `pagination` - `{ "limit": 100, "offset": 0 }`

### Filter Operators
- `is` / `is_not` - Exact match
- `contains` / `contains_not` - Substring match
- `matches` / `matches_not` - Wildcard match

## When to Use

- Privacy-first web analytics without cookies
- Simple, lightweight traffic analysis
- UTM campaign performance tracking
- Goal and conversion tracking
- Geographic and device breakdown
- GDPR/CCPA-compliant analytics alternative to GA4

## Rate Limits

- 600 requests/hour per API key
- All requests must be over HTTPS

## Relevant Skills

- analytics
- content-strategy
- programmatic-seo
- cro
- utm-tracking

## Custom date ranges in the CLI

Pass custom boundaries as a JSON array of two strings. For example:

```bash
node tools/clis/plausible.js stats aggregate --site-id example.com \
  --date-range '["2026-09-01","2026-09-30"]'
```

ISO8601 timestamps are also supported, including their timezone offsets:
`--date-range '["2026-09-01T12:00:00+02:00","2026-09-01T15:59:59+02:00"]'`.
The CLI sends these values as an array without converting them to UTC. Existing
presets (such as `7d`) and the default `30d` remain strings. Malformed arrays or
arrays without exactly two nonempty strings fail before the stats request;
Plausible validates the date values. See the
[Stats API date_range contract](https://plausible.io/docs/stats-api).

## Paginating CLI results

The CLI returns one page per invocation; it does not automatically fetch every
page. Use the pagination scheme of the endpoint you selected:

- **Sites and goals:** pass the response's opaque `meta.after` or `meta.before`
  cursor unchanged as `--after` or `--before`. Keep `--limit` unchanged between
  requests (or leave it unset for the default 100). A null cursor means there is
  no next or previous page. Do not supply both cursors in one request.
- **Stats breakdowns and query:** use `--limit` and `--offset` for `pages`,
  `sources`, `countries`, `devices`, `utm`, or `query`. Offset zero starts at the
  first result; increase it by the page size for the next page. Keep metrics,
  dimensions, filters, date range and ordering consistent while paging. These
  flags do not paginate aggregate, timeseries or realtime operations.

```bash
node tools/clis/plausible.js sites list --limit 20
# Copy meta.after from the response, without decoding or altering it:
node tools/clis/plausible.js sites list --limit 20 --after '<returned cursor>'

node tools/clis/plausible.js goals list --site-id example.com --limit 20 \
  --before '<returned cursor>'

node tools/clis/plausible.js stats pages --site-id example.com --limit 20 --offset 20
```

`--dry-run` previews the same encoded query or stats pagination body without
making a request. See the official [Sites API pagination](https://plausible.io/docs/sites-api#pagination)
and [Stats API pagination](https://plausible.io/docs/stats-api#pagination-optional)
contracts. Read-only Sites endpoints, including listing sites and goals, also
accept a Stats API key on plans that include that API; Sites API mutations
require the appropriate Enterprise permissions.

## File: tools/integrations/plivo.md

# Plivo

Cloud communications API platform — SMS, MMS, voice, WhatsApp. Direct Twilio competitor with similar pricing and developer-first positioning.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API |
| MCP | - | Not available |
| CLI | - | None official |
| SDK | ✓ | Node, Python, Ruby, PHP, Java, Go, .NET |

## Authentication

- **Type**: Basic auth with Auth ID + Auth Token
- **Header**: `Authorization: Basic base64(AuthID:AuthToken)`
- **Get credentials**: https://console.plivo.com → Account → Account Settings
- **Note**: Subaccounts available for isolating environments or customers

## Common Agent Operations

### Send SMS

```bash
POST https://api.plivo.com/v1/Account/{AuthID}/Message/

{
  "src": "+15559876543",
  "dst": "+15551234567",
  "text": "Hello from Plivo"
}
```

### Send MMS

```bash
POST https://api.plivo.com/v1/Account/{AuthID}/Message/

{
  "src": "+15559876543",
  "dst": "+15551234567",
  "text": "Check this out",
  "type": "mms",
  "media_urls": ["https://example.com/image.jpg"]
}
```

### Bulk send (powerpack)

Use Plivo's Powerpack feature to send from a pool of numbers with sticky sender + automatic A2P registration. Configured in console; messages then sent with `powerpack_uuid` instead of `src`.

```bash
POST https://api.plivo.com/v1/Account/{AuthID}/Message/

{
  "powerpack_uuid": "...",
  "dst": "+15551234567",
  "text": "Hello"
}
```

### Get message details

```bash
GET https://api.plivo.com/v1/Account/{AuthID}/Message/{MessageUUID}/
```

### List messages

```bash
GET https://api.plivo.com/v1/Account/{AuthID}/Message/?limit=20&offset=0
```

### Rent a phone number

```bash
# Search available
GET https://api.plivo.com/v1/Account/{AuthID}/PhoneNumber/?country_iso=US&type=local

# Rent
POST https://api.plivo.com/v1/Account/{AuthID}/PhoneNumber/{NumberID}/
```

### Configure inbound message webhook on an Application

```bash
POST https://api.plivo.com/v1/Account/{AuthID}/Application/

{
  "app_name": "SMS Receiver",
  "message_url": "https://your-app.com/sms-webhook",
  "message_method": "POST"
}
```

Then assign the application to the phone number.

### A2P 10DLC registration (US)

Configured through console UI under Compliance. Programmatic registration available for high-volume customers via dedicated API endpoints (request access).

## API Pattern

REST + JSON. Pagination via `limit` + `offset`. Webhook callbacks for inbound messages and delivery status (configured per-application).

## Pricing

- US 10DLC SMS: $0.0055/msg (typically lower than Twilio)
- US toll-free SMS: $0.0055/msg
- US short code SMS: similar + monthly lease
- MMS: ~$0.02
- Carrier surcharges layered on top
- Phone number rental: ~$0.80/mo local, ~$1/mo toll-free

Plivo typically prices 5–20% under Twilio at the per-send level. Less of an ecosystem advantage but real cost savings at high volume.

## Rate Limits

- Default: 1 msg/sec
- Powerpacks scale throughput based on number pool size and A2P trust
- Short codes: 100+ msg/sec

## When to Use

- Custom SMS build, want a Twilio-like API with lower cost
- High-volume sending where the per-message delta matters
- Want bulk sending with sticky sender via Powerpack
- B2B SaaS embedding SMS or transactional/auth at scale

## When NOT to Use

- DTC ecom marketing flows — Klaviyo, Postscript, Attentive
- Ecosystem matters more than price — Twilio's broader product surface (Voice, Studio, SendGrid, Segment, etc.) wins
- Need mature WhatsApp Business — Twilio has deeper WhatsApp tooling

## Relevant Skills

- sms
- onboarding (post-signup notifications)

## File: tools/integrations/ploy.md

# Ploy

> **◆ Verified Partner integration.** Ploy sponsors Marketing Skills. This integration is disclosed and vetted for fit; it does **not** change what any skill recommends. It's listed here alongside the neutral options for the same job — use it when it's the right fit, not because it's a partner. See [Verified Partners](../REGISTRY.md#verified-partners).
>
> **Second disclosure:** Corey Haines, who maintains this repository, is the credited author of several Ploybooks in Ploy's library, including "Programmatic SEO at Scale," which follows the same 12 playbooks as this repo's `programmatic-seo` skill.

AI marketing platform built around a hosted website builder. An in-app agent builds and edits pages, writes copy, runs research and analysis, and publishes; Ploybooks (markdown runbooks the agent executes) automate recurring work on a schedule or from a webhook. Built by a team led by Webflow's former CTO; generally available since June 2026.

Facts below were checked against [docs.ploy.ai](https://docs.ploy.ai) and [ploy.ai/pricing](https://ploy.ai/pricing) on 2026-10-02. Ploy ships fast, so re-check anything an answer depends on.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | Partial | No general public API for sites, pages, or publishing (the CLI is the management surface). Two public APIs exist: the [PloyDB external API](https://docs.ploy.ai/database/external-apps) for reading and writing database rows, and a migration-estimate endpoint (`GET https://ploy.ai/agent-tools/migration-estimate?url=`, spec at `/.well-known/api-catalog`). Inbound [webhooks](https://docs.ploy.ai/webhooks) only |
| MCP | – | No Ploy MCP server. Ploy can *add* WebMCP to your site through a Ploybook (see below), which is a different thing |
| CLI | ✓ | Standalone binary (macOS/Linux): sites, publishing, domains, routing, PloyDB, Ploybooks, forms, variables and secrets, Code Sync — [docs.ploy.ai/cli](https://docs.ploy.ai/cli) |
| Agent skill | ✓ | [`Ploy-AI/ploy-tools`](https://github.com/Ploy-AI/ploy-tools) (MIT): a `ploy-site` skill for building or migrating into Ploy's Astro starter. `npx skills add Ploy-AI/ploy-tools`, or as a Claude Code plugin |

## What it does

- **Site builder.** Every site is Astro + React + TypeScript + Tailwind, hosted on Cloudflare Workers. Pages are built from sections on a design system you can import from a live URL, Figma, or chat. Deploy history with instant promote-to-rollback in the UI.
- **Agent.** Chat-based (Lite, Agent, and Ultra profiles) with sub-agents for design, code, research, and copy. Projects add a goal, task board, and memory; active projects run a daily check-in that uses credits.
- **PloyDB.** Spreadsheet-style database (97 columns per table, CSV import up to 32 MB, 30-day version history). Pages built on a table update within about a minute without a republish, which is what makes pages-at-scale work.
- **CMS migration.** Imports content from WordPress, Squarespace, Sanity, Webflow, Framer, Wix, and Notion into PloyDB. It's a one-time import, not a sync, and **routes, metadata, and redirects aren't carried over**; rebuild them as part of the launch.
- **Routing rules.** Ploy's edge sits in front of your domain and routes by path to a Ploy site, proxies to another origin, or redirects (up to 20 rules). This lets you put Ploy pages on a subpath of an existing site without migrating it.
- **Analytics and visitors.** Built-in cookie-free analytics with an AI-referrer channel (ChatGPT, Perplexity, Claude, Gemini, Copilot), plus visitor identification (person, company, title) and contact enrichment, metered by plan. Ploy says visitor identification needs no consent banner; whether that holds for your audience and jurisdiction is a legal question for you, not something the vendor can settle.
- **Forms.** Native form submissions with email notifications.
- **Integrations.** Figma, GA4, Search Console, HubSpot (two-way), Salesforce (Enterprise), Attio, Semrush, PostHog, Slack, Notion, the Google, Meta, LinkedIn, and Reddit ad platforms (reporting), and more. Write access is off by default per connection.
- **SSO.** OIDC single sign-on is live on the Enterprise plan.
- **Coming soon (waitlist, as of 2026-10):** PloyGrow (outreach) and PloyAds (managed paid campaigns).

## Pricing (as of 2026-10-02)

| | Free | Starter | Pro | Enterprise |
|---|---|---|---|---|
| Price | $0 | $50/mo | $300/mo | Custom |
| Credits | 500/day, capped at 2,000 | 4,000/mo | 24,000/mo | Custom |
| Custom domains | None | 1 domain family | 5 | Custom |
| Code Sync (source via GitHub) | No | Yes | Yes | Yes |
| Visitor enrichment | None | 50/mo | 1,000/mo | Custom |
| Ad, HubSpot, Attio integrations | No | No | Yes | Yes |

Credits don't roll over. AI credits, visitor enrichment, and contact lookups are metered separately. Scheduled Ploybooks and project check-ins use credits even when nobody's in the workspace.

## Authentication

- **Interactive:** `ploy login` (browser) or `ploy login --with-device` (device flow for SSH or remote machines).
- **Headless and CI:** a workspace API token (Settings → Developer → API tokens) exported as `PLOY_API_TOKEN`. Tokens are pinned to one workspace, expire after 30, 90, or 365 days, are rate-limited to 60 requests a minute, and are never written to disk. Keep them in a secret manager, never in the repo.
- **PloyDB API:** a per-table access key sent as `Authorization: Bearer <key>`.

## Common agent workflows

**Install and connect**

```bash
curl -fsSL https://ploy.ai/install.sh | sh
ploy login                      # or export PLOY_API_TOKEN=... for headless use
ploy whoami
ploy workspace use --id <workspace-id>
ploy site use --id <site-id>
```

**Publish and verify.** The CLI has no staging target: `ploy site publish` always goes to production (preview-only publishing exists in the app). Roll back from the Deploys screen in the UI (no CLI command).

```bash
ploy --dry-run site publish
ploy site publish --wait --json          # returns an operationId
ploy site publish-status <operationId> --json
```

If `--wait` gives up on a rate limit, the publish keeps running; check `publish-status`.

**Connect a custom domain** (needs Admin or Owner)

```bash
ploy domain add www.example.com          # prints the DNS records to add
# add the records at your DNS provider, wait for propagation, then:
ploy domain add www.example.com          # rerun to connect
ploy domain status www.example.com --json   # dns_pending → provisioning → connected
```

**Put Ploy pages on a subpath of an existing site**

1. Give the existing site a stable HTTPS origin (for example `origin.example.com`).
2. Connect a test subdomain in Ploy first.
3. `ploy site routing get > routing.json`, then add a path-prefix rule (for example `/experience`) that sends to the Ploy site, plus its asset paths, and set the default fallback to the origin.
4. `ploy site routing set --file routing.json --dry-run`, then without `--dry-run`.
5. Test both the new path and the existing site, then repeat on the production domain.

`routing set` replaces the whole document, so always start from `routing get`. The exact JSON shape for a "send to Ploy site" rule isn't documented; copy it from an existing document.

**Pages at scale from PloyDB**

```bash
ploy database create --name "Integrations"
ploy database import <db-id> --table-name "Integrations" --file integrations.csv --dry-run
ploy database import <db-id> --table-name "Integrations" --file integrations.csv
```

Then have the agent (or a Ploybook) build one dynamic template route over the table. Keep rows current with `ploy database row add|update`, the PloyDB API, or a webhook that writes rows. Apply the `programmatic-seo` skill's quality and indexation rules before publishing hundreds of pages.

**Trigger work from another system.** Create a webhook endpoint in Workspace Settings → Webhooks, then `POST https://ploy.ai/api/v1/webhook/<endpointSlug>` with `Authorization: Bearer <apiKey>` and a JSON body (up to 1 MB). It returns 202 and never retries, so the sender must. Ploy's documented example: a Clay row posts to a webhook that runs a Ploybook to publish an account page at `/for/<company>`. Unattended production publishing needs automatic publishing set to "Preview + Production."

**Add WebMCP to the site.** Run the "Make your website agent-ready with WebMCP" Ploybook. It checks spec support, inspects the site, defines tool contracts, implements them against your existing form logic, and validates. No dedicated commands.

**Coding-agent loop (paid plans).** `ploy site code-sync init`, clone, edit, push to `main`, `ploy site code-sync sync`, then `ploy site publish --wait`. Bringing your own repo requires Ploy's Astro shape (Astro 6, `@astrojs/cloudflare`, a `package.json` named `ploy-web`); other frameworks have to be ported.

## Tradeoffs

- **Hosting is Ploy-only**, and routing means Ploy's edge sits in front of your whole domain. Source access is via Code Sync on paid plans only, in Ploy's Astro shape; there's no documented self-hosting path.
- **Export is limited.** PloyDB CSV export caps at 10,000 rows, and Ploy itself calls it not a lossless backup.
- **Marketing sites, not apps or stores.** Carts, checkout, and authenticated apps stay elsewhere and get proxied.
- **Young product.** GA in June 2026, CLI at 0.16.x; some marketed features (localization, AEO citation tracking, A/B testing) aren't in the docs yet. Ploy's own comparison page suggests Webflow when heavy programmatic SEO or ecommerce is the core motion.
- **Credit costs** depend on agent usage and scheduled work, so estimate from a trial before committing.

## How it fits the skills

- Ploy is one way to **build and host** the site, alongside Webflow, Framer, WordPress, dedicated landing-page tools, AI app builders, and hand-coded stacks. The comparison is in the `site-architecture` skill's platform reference. What pages, copy, and structure to build still come from `site-architecture`, `copywriting`, and `cro`.
- For pages at scale, PloyDB is one implementation option in the `programmatic-seo` skill's platform reference.
- For WebMCP and agent-actionable sites, see the `ai-seo` skill's agent-readiness reference.
- Before going live, run the `launch` skill's site launch QA; rebuild redirects after any CMS import.
- Judge Ploy's analytics and visitor data with `analytics` and `attribution` discipline, and its AEO features with `ai-seo`.

## Links

- Site: https://ploy.ai
- Docs: https://docs.ploy.ai (index at https://docs.ploy.ai/llms.txt)
- CLI reference: https://docs.ploy.ai/cli/reference
- Agent skill: https://github.com/Ploy-AI/ploy-tools
- Pricing: https://ploy.ai/pricing
- Support: support@ploy.ai

## File: tools/integrations/posthog.md

# PostHog

Open-source product analytics with session replay and feature flags.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Capture API, Query API, Feature Flags API |
| MCP | - | Not available |
| CLI | ✓ | `posthog` CLI for local development |
| SDK | ✓ | JavaScript, Python, Ruby, Go, etc. |

## Authentication

- **Type**: API Key (Personal or Project)
- **Header**: `Authorization: Bearer {api_key}`
- **For capture**: Project API Key in payload

## Common Agent Operations

### Capture event

```bash
POST https://app.posthog.com/capture/

{
  "api_key": "{project_api_key}",
  "event": "signup_completed",
  "distinct_id": "user_123",
  "properties": {
    "plan": "pro",
    "$current_url": "https://example.com/signup"
  }
}
```

### Batch events

```bash
POST https://app.posthog.com/batch/

{
  "api_key": "{project_api_key}",
  "batch": [
    {"event": "pageview", "distinct_id": "user_1"},
    {"event": "signup", "distinct_id": "user_2"}
  ]
}
```

### Get person by distinct_id

```bash
GET https://app.posthog.com/api/projects/{project_id}/persons/?distinct_id=user_123

Authorization: Bearer {api_key}
```

### Query events (HogQL)

```bash
POST https://app.posthog.com/api/projects/{project_id}/query/

{
  "query": {
    "kind": "HogQLQuery",
    "query": "SELECT event, count() FROM events WHERE timestamp > now() - interval 7 day GROUP BY event ORDER BY count() DESC LIMIT 10"
  }
}
```

### Get feature flag value

```bash
POST https://app.posthog.com/decide?v=3

{
  "api_key": "{project_api_key}",
  "distinct_id": "user_123"
}
```

### Get insights

```bash
GET https://app.posthog.com/api/projects/{project_id}/insights/

Authorization: Bearer {api_key}
```

### Get session recordings

```bash
GET https://app.posthog.com/api/projects/{project_id}/session_recordings/

Authorization: Bearer {api_key}
```

## JavaScript SDK

```javascript
// Initialize
posthog.init('PROJECT_API_KEY', {
  api_host: 'https://app.posthog.com'
});

// Identify user
posthog.identify('user_123', {
  email: 'user@example.com',
  plan: 'pro'
});

// Track event
posthog.capture('signup_completed', {
  method: 'email'
});

// Check feature flag
if (posthog.isFeatureEnabled('new-pricing')) {
  // Show new pricing
}
```

## Key Features

- **Event tracking** - Product analytics
- **Session replay** - Watch user sessions
- **Feature flags** - Control feature rollout
- **A/B testing** - Built-in experiments
- **HogQL** - SQL-like query language
- **Self-hostable** - Run on your infrastructure

## When to Use

- Product analytics with privacy focus
- Session replay for UX insights
- Feature flag management
- Self-hosted analytics needs
- Open-source requirements

## Rate Limits

- Cloud: 10,000 events/second
- Self-hosted: Unlimited

## Relevant Skills

- analytics
- ab-testing
- onboarding

## File: tools/integrations/postmark.md

# Postmark

Transactional email delivery service with fast delivery, templates, bounce management, and detailed analytics.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for email sending, templates, bounces, stats |
| MCP | - | Not available |
| CLI | ✓ | [postmark.js](../clis/postmark.js) |
| SDK | ✓ | Node.js, Ruby, Python, PHP, Java, .NET, Go |

## Authentication

- **Type**: Server Token (or Account Token for account-level ops)
- **Header**: `X-Postmark-Server-Token: {server_token}` (server-level)
- **Header**: `X-Postmark-Account-Token: {account_token}` (account-level)
- **Get key**: API Tokens tab at https://account.postmarkapp.com/servers
- **Note**: Server tokens are per-server; account tokens apply across all servers

## Common Agent Operations

### Send single email

```bash
POST https://api.postmarkapp.com/email

{
  "From": "sender@example.com",
  "To": "recipient@example.com",
  "Subject": "Welcome!",
  "HtmlBody": "<html><body><p>Hello!</p></body></html>",
  "TextBody": "Hello!",
  "MessageStream": "outbound",
  "TrackOpens": true,
  "TrackLinks": "HtmlAndText"
}
```

### Send with template

```bash
POST https://api.postmarkapp.com/email/withTemplate

{
  "From": "sender@example.com",
  "To": "recipient@example.com",
  "TemplateId": 12345,
  "TemplateModel": {
    "name": "Jane",
    "action_url": "https://example.com/verify"
  },
  "MessageStream": "outbound"
}
```

### Send batch emails

```bash
POST https://api.postmarkapp.com/email/batch

[
  {
    "From": "sender@example.com",
    "To": "user1@example.com",
    "Subject": "Notification",
    "TextBody": "Hello user 1"
  },
  {
    "From": "sender@example.com",
    "To": "user2@example.com",
    "Subject": "Notification",
    "TextBody": "Hello user 2"
  }
]
```

### List templates

```bash
GET https://api.postmarkapp.com/templates?Count=100&Offset=0
```

### Get template

```bash
GET https://api.postmarkapp.com/templates/{templateIdOrAlias}
```

### Create template

```bash
POST https://api.postmarkapp.com/templates

{
  "Name": "Welcome Email",
  "Alias": "welcome",
  "Subject": "Welcome {{name}}!",
  "HtmlBody": "<html><body><p>Hello {{name}}</p></body></html>",
  "TextBody": "Hello {{name}}"
}
```

### Get delivery stats

```bash
GET https://api.postmarkapp.com/deliverystats
```

### List bounces

```bash
GET https://api.postmarkapp.com/bounces?count=50&offset=0&type=HardBounce
```

### Activate bounce (reactivate recipient)

```bash
PUT https://api.postmarkapp.com/bounces/{bounceId}/activate
```

### Search outbound messages

```bash
GET https://api.postmarkapp.com/messages/outbound?count=50&offset=0&recipient=user@example.com
```

### Get outbound stats overview

```bash
GET https://api.postmarkapp.com/stats/outbound?fromdate=2025-01-01&todate=2025-01-31
```

### Get open stats

```bash
GET https://api.postmarkapp.com/stats/outbound/opens?fromdate=2025-01-01&todate=2025-01-31
```

### Get click stats

```bash
GET https://api.postmarkapp.com/stats/outbound/clicks?fromdate=2025-01-01&todate=2025-01-31
```

### Get server info

```bash
GET https://api.postmarkapp.com/server
```

### List suppressions

```bash
GET https://api.postmarkapp.com/message-streams/outbound/suppressions/dump
```

### Create suppression

```bash
POST https://api.postmarkapp.com/message-streams/outbound/suppressions

{
  "Suppressions": [
    { "EmailAddress": "user@example.com" }
  ]
}
```

## API Pattern

Postmark uses simple REST endpoints with PascalCase field names in request/response bodies. Authentication is via custom headers rather than Authorization. Pagination uses `Count` and `Offset` parameters. Email sending is synchronous with immediate delivery confirmation.

## Key Metrics

### Delivery Metrics
- `Sent` - Total emails sent
- `Bounced` - Bounce count by type (hard, soft, transient)
- `SpamComplaints` - Spam complaint count
- `Opens` - Open count and unique opens
- `Clicks` - Click count and unique clicks

### Bounce Types
- `HardBounce` - Permanent delivery failure
- `SoftBounce` - Temporary delivery failure
- `Transient` - Temporary issue (retry)
- `SpamNotification` - Marked as spam

### Message Fields
- `MessageID` - Unique message identifier
- `SubmittedAt` - Submission timestamp
- `Status` - Delivery status
- `Recipients` - Recipient list

## Parameters

### Email Parameters
- `From` - Sender address (must be verified)
- `To` - Recipient (comma-separated for multiple)
- `Subject` - Email subject
- `HtmlBody` / `TextBody` - Email content
- `MessageStream` - outbound (transactional) or broadcast
- `TrackOpens` - Enable open tracking (boolean)
- `TrackLinks` - None, HtmlAndText, HtmlOnly, TextOnly
- `Tag` - Custom tag for categorization

### Stats Parameters
- `fromdate` - Start date (YYYY-MM-DD)
- `todate` - End date (YYYY-MM-DD)
- `tag` - Filter by tag

## When to Use

- Transactional emails (password resets, order confirmations, notifications)
- Template-based email sending with dynamic variables
- Monitoring email deliverability and bounce rates
- Tracking email engagement (opens, clicks)
- Managing email suppressions and bounces
- High-reliability email delivery with fast performance

## Rate Limits

- 500 messages per batch request
- 10 MB max per single message (including attachments)
- 50 MB max per batch request
- API rate limits vary by plan

## Relevant Skills

- emails
- transactional-email
- email-deliverability
- onboarding-email

### Structured template models

Use `--model-json` for nested template data, line-item arrays, numbers and booleans. The existing `--model key:value,...` shorthand remains available for simple strings; choose one input format per invocation.

```bash
node tools/clis/postmark.js email send-template --from sender@example.com --to recipient@example.com --template receipt --model-json '{"customer":{"name":"Growth, Inc."},"items":[{"title":"Service: priority","quantity":2}],"paid":true}' --dry-run
```

The CLI requires a JSON object and preserves its nested value types in `TemplateModel`. Preview first; removing `--dry-run` sends the message. See the [Postmark Templates API](https://postmarkapp.com/developer/api/templates-api).

## File: tools/integrations/postscript.md

# Postscript

SMS marketing platform built for Shopify direct-to-consumer brands. Deepest Shopify integration of any SMS platform.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API |
| MCP | - | Not available |
| CLI | - | None |
| SDK | - | Use API directly |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}` or `X-Postscript-Api-Key: {api_key}`
- **Get key**: Postscript dashboard → Settings → API
- **Note**: Keys are scoped per shop

## Common Agent Operations

### Search subscribers

```bash
GET https://api.postscript.io/api/v2/subscribers?phone_number=%2B15551234567
```

### Create subscriber (opt-in)

```bash
POST https://api.postscript.io/api/v2/subscribers

{
  "phone_number": "+15551234567",
  "email": "user@example.com",
  "first_name": "Jane",
  "subscribed_at": "2026-05-15T10:00:00Z",
  "opt_in_source": "checkout_keyword"
}
```

Must include valid opt-in metadata for TCPA compliance.

### Unsubscribe

```bash
DELETE https://api.postscript.io/api/v2/subscribers/{subscriberId}/subscription
```

### List keywords (e.g., JOIN, SAVE)

```bash
GET https://api.postscript.io/api/v2/keywords
```

### Send transactional message

```bash
POST https://api.postscript.io/api/v2/transactional/sms

{
  "phone_number": "+15551234567",
  "message": "Your order #1234 shipped. Track at https://..."
}
```

Transactional requires separate enablement; counts under transactional consent.

### List campaigns

```bash
GET https://api.postscript.io/api/v2/campaigns
```

### List automations (flows)

```bash
GET https://api.postscript.io/api/v2/automations
```

### Webhooks

Subscribe to events: `subscriber.created`, `subscriber.unsubscribed`, `message.delivered`, `message.failed`, `conversion.attributed`.

## API Pattern

REST + JSON. Standard `Bearer` auth. Pagination via `cursor` and `limit` (max 100).

## Key Features

- Native Shopify integration: purchases, abandoned carts, browse, product catalog auto-sync
- Strong abandoned cart and browse abandonment automation builders
- AI Reply (auto-reply trained on brand voice)
- Conversational SMS / live agent for two-way
- Opt-in tools: popups, keyword opt-in, checkout opt-in
- A2P 10DLC managed in-platform
- Reporting: revenue, click-through, conversion attribution, opt-out rate

## Pricing

- Plans: Starter (free, 1K msgs/mo), Growth ($100+/mo), Professional, Enterprise
- Per-send pricing on top: ~$0.015 SMS, ~$0.04 MMS
- Annual contracts standard at Growth+
- Pricing scales meaningfully past 50K subscribers

## When to Use

- Shopify DTC brand wanting SMS-specific tooling (vs combined email/SMS)
- Need deep abandoned cart, browse abandonment, post-purchase automation out of the box
- Want managed A2P 10DLC + compliance tools
- Mid-size DTC brand (10K–500K SMS subscribers)

## When NOT to Use

- Non-Shopify ecom — integration is shallow
- Already on Klaviyo for email and SMS is secondary — Klaviyo SMS is simpler
- Mid-market/enterprise needing concierge support — Attentive
- Custom platform or B2B SaaS — Twilio

## Relevant Skills

- sms
- emails (run alongside via Klaviyo or similar)
- churn-prevention (win-back flows)
- onboarding (post-purchase activation)

## File: tools/integrations/rankparse.md

# RankParse

Agent-friendly SEO data API for backlinks, domain authority, tech stack, and on-page metadata. Designed as a low-cost alternative to enterprise SEO suites.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API at `api.rankparse.com` |
| MCP | ✓ | Hosted MCP server for agent use |
| CLI | [✓](../clis/rankparse.js) | Node CLI wrapper |
| SDK | - | API-only (SDKs in progress) |

## Authentication

- **Type**: API Key
- **Header**: `X-API-Key: rp_...`
- **Get key**: Sign up at https://rankparse.com and create a key in the dashboard
- **Billing**: Credit-based (one-time credit packs, no subscription). Each endpoint deducts a fixed number of credits per call.

## Common Agent Operations

### Domain authority

```bash
GET https://api.rankparse.com/v1/domain-authority?domain=example.com

X-API-Key: rp_...
```

Returns authority score, registered date, registrar, and popularity rank.

### Backlinks

```bash
GET https://api.rankparse.com/v1/backlinks?domain=example.com&limit=100

X-API-Key: rp_...
```

Optional params: `sort=importance|recent`, `from_domain=`, `link_type=`, `score=true`.

### Referring domains

```bash
GET https://api.rankparse.com/v1/referring-domains?domain=example.com&limit=100

X-API-Key: rp_...
```

### Outbound links

```bash
GET https://api.rankparse.com/v1/outbound-links?domain=example.com&limit=100

X-API-Key: rp_...
```

### Anchor text profile

```bash
GET https://api.rankparse.com/v1/anchor-text?domain=example.com&limit=100

X-API-Key: rp_...
```

### Top pages

```bash
GET https://api.rankparse.com/v1/top-pages?domain=example.com&limit=50

X-API-Key: rp_...
```

### Domain overlap

```bash
GET https://api.rankparse.com/v1/domain-overlap?domains=a.com,b.com,c.com

X-API-Key: rp_...
```

Compare 2–5 domains.

### Link intersect

```bash
GET https://api.rankparse.com/v1/link-intersect?domain_a=a.com&domain_b=b.com

X-API-Key: rp_...
```

Domains that link to both targets.

### Competitor gap

```bash
GET https://api.rankparse.com/v1/competitor-gap?domain=mysite.com&vs=competitor.com

X-API-Key: rp_...
```

### Similar domains

```bash
GET https://api.rankparse.com/v1/similar-domains?domain=example.com

X-API-Key: rp_...
```

### Tech stack

```bash
GET https://api.rankparse.com/v1/tech-stack?domain=example.com

X-API-Key: rp_...
```

### Page SEO

```bash
GET https://api.rankparse.com/v1/page-seo?url=https://example.com/page

X-API-Key: rp_...
```

Returns title, meta description, OG tags, canonical, and structured metadata for a single URL.

### Page performance

```bash
GET https://api.rankparse.com/v1/page-performance?url=https://example.com/page&strategy=mobile

X-API-Key: rp_...
```

Core Web Vitals via Google PageSpeed Insights. Daily quotas apply.

### Site health

```bash
GET https://api.rankparse.com/v1/site-health?domain=example.com

X-API-Key: rp_...
```

### Sitemap

```bash
GET https://api.rankparse.com/v1/sitemap?domain=example.com&limit=100

X-API-Key: rp_...
```

### Crawl history

```bash
GET https://api.rankparse.com/v1/crawl-history?domain=example.com

X-API-Key: rp_...
```

Wayback Machine snapshots for the domain.

### Link audit

```bash
GET https://api.rankparse.com/v1/link-audit?domain=example.com

X-API-Key: rp_...
```

Combined health score, risk flags, anchor profile, and top backlinks.

### Site explorer

```bash
GET https://api.rankparse.com/v1/site-explorer?domain=example.com

X-API-Key: rp_...
```

All-in-one snapshot of a domain.

### Batch lookup

```bash
POST https://api.rankparse.com/v1/batch
Content-Type: application/json
X-API-Key: rp_...

{ "domains": ["a.com", "b.com", "c.com"] }
```

Bulk domain summaries in one call.

## Free Tools (Unauthenticated)

Public, IP-rate-limited endpoints for quick lookups without an API key:

- `GET /v1/tools/backlinks?domain=`
- `GET /v1/tools/domain-authority?domain=`
- `GET /v1/tools/tech-stack?domain=`
- `GET /v1/tools/similar-websites?domain=`
- `GET /v1/tools/domain-age?domain=`
- `GET /v1/tools/meta-tag-analyzer?url=`
- `GET /v1/tools/link-intersect?domain_a=&domain_b=`
- `GET /v1/tools/page-speed?url=`

## Key Response Fields

### Domain Metrics
- `authority` - Domain authority score
- `popularity_rank` - Tranco popularity rank
- `registered_at` - Domain registration date
- `registrar` - Registrar name

### Backlink Fields
- `from_url` - Source URL
- `to_url` - Target URL
- `anchor` - Anchor text
- `link_type` - dofollow / nofollow / ugc / sponsored
- `first_seen` - First discovery date

## When to Use

- Backlink discovery and analysis
- Competitor link research and gap analysis
- Domain authority lookups at scale
- Tech stack detection
- On-page SEO audits
- Sitemap and crawl history discovery
- Agent-driven SEO workflows where per-call cost matters

## Pricing Model

- Pay-as-you-go credit packs (no subscription)
- Most domain endpoints: 1–2 credits per call
- Aggregated endpoints (overlap, intersect, similar, gap): 5 credits
- Link audit: 8 credits
- Site explorer: 10 credits
- Batch: 1 credit per domain
- Free tier available for unauthenticated endpoints

## MCP Server

RankParse ships a hosted MCP server exposing all endpoints as tools — connect from Claude, Cursor, or any MCP-compatible agent. See https://rankparse.com for connection details.

## Relevant Skills

- seo-audit
- content-strategy
- competitors
- competitor-profiling
- ai-seo
- site-architecture
- schema

## File: tools/integrations/rb2b.md

# RB2B

Website visitor identification platform that de-anonymizes B2B website traffic, revealing the individual people visiting your site with LinkedIn profiles, emails, and company data.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | Limited | API Partner Program (separate from standard app) |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | Not available |

Most teams use RB2B via its native integrations (Slack, CRM push, Zapier, webhooks) rather than direct API access. A separate [API Partner Program](https://www.rb2b.com/apis) exists for programmatic access.

## Authentication

- **Type**: Native integrations (no API key needed for standard use)
- **API Partner Program**: Separate credentials via https://www.rb2b.com/apis
- **Free tier**: Limited credits/month with Slack alerts

## Pricing Tiers

Pricing changes frequently — verify at https://www.rb2b.com/pricing.

| Plan | Approx. Price | Key Features |
|------|--------------|-------------|
| Free | $0 | Limited credits, Slack alerts, LinkedIn profiles |
| Starter | ~$79/mo | Person-level ID, basic integrations |
| Pro | ~$129-349/mo | CSV export, CRM push, validated emails |
| Pro+ | ~$299+/mo | All integrations, higher credit volume |

## Key Integrations

RB2B pushes identified visitor data to 50+ tools:
- **CRM**: Salesforce, HubSpot
- **Outreach**: Instantly, HeyReach, Lemlist
- **Enrichment**: Clay, Apollo, LeadMagic, FullEnrich
- **Automation**: Zapier, Make
- **Alerts**: Slack (real-time notifications)

## What RB2B Reveals Per Visitor

- Full name and LinkedIn profile URL
- Job title and company
- Validated business email (Pro+)
- Pages visited and visit duration
- Number of visits and return frequency
- Company data (size, industry, location)

## Common Agent Operations

### Real-Time Visitor Alerts

Configure Slack alerts for high-intent visitors:
- Visitors who hit pricing page
- Visitors who return 3+ times
- Visitors from target account list
- Visitors matching ICP job titles

### Visitor-to-Outreach Pipeline

1. RB2B identifies visitor with LinkedIn + email
2. Filter by ICP criteria (title, company size, pages visited)
3. Route to outreach tool (Instantly, Lemlist) or CRM (HubSpot, Salesforce)
4. Trigger personalized cold email referencing pages they visited

### Intent Scoring

Score visitors by behavior signals:
- **High intent**: Pricing page, demo page, comparison pages, 3+ visits
- **Medium intent**: Feature pages, case studies, 2 visits
- **Low intent**: Blog only, single visit, bounced quickly

### Suppression Lists

Prevent outreach to:
- Existing customers (match against CRM)
- Active deals in pipeline
- Competitors and agencies
- Recently contacted prospects

## When to Use

- Identifying anonymous website visitors for sales outreach
- Building ABM (account-based marketing) target lists from site traffic
- Understanding which companies are researching your product
- Triggering personalized outreach based on page-level intent signals
- Feeding enrichment tools (Clay, Apollo) with warm visitor data

## Limitations

- Person-level identification works best for US B2B traffic
- Not all visitors can be identified (typical match rates: 15-30%)
- Requires sufficient website traffic to be cost-effective
- Privacy considerations — ensure compliance with applicable regulations
- Free tier limited to Slack alerts (no CRM push or email export)

## Relevant Skills

- cold-email
- revops
- customer-research
- ads

## Sources

- [RB2B pricing](https://www.rb2b.com/pricing)
- [RB2B plans comparison](https://support.rb2b.com/en/articles/9173659-rb2b-plans-side-by-side-comparisons)
- [RB2B API Partner Program](https://support.rb2b.com/en/articles/12579420-rb2b-apis-rb2b-s-api-partner-program)

## File: tools/integrations/resend.md

# Resend

Developer-friendly transactional email service with modern API.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Simple REST API for sending emails |
| MCP | ✓ | Available via Resend MCP server |
| CLI | ✓ | Official Resend CLI |
| SDK | ✓ | Official SDKs for Node.js, Python, Go, etc. |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: API Keys section in Resend dashboard

## CLI

### Install

```bash
npm install -g resend-cli
```

### Setup

```bash
resend login
# or set env var: RESEND_API_KEY=re_xxx
```

### Common commands

```bash
# Send a test email
resend emails send --from hello@example.com --to user@example.com --subject "Test" --text "Hello"

# List recent emails
resend emails list

# Get email status
resend emails get <email_id>

# List domains
resend domains list

# Add a domain
resend domains create --name example.com

# Verify a domain
resend domains verify <domain_id>

# List API keys
resend api-keys list

# Create an API key
resend api-keys create --name "Production"
```

## Common Agent Operations

### Send email

```bash
POST https://api.resend.com/emails

{
  "from": "hello@example.com",
  "to": ["user@example.com"],
  "subject": "Welcome!",
  "html": "<h1>Welcome to our app!</h1>"
}
```

### Send with React template

```bash
POST https://api.resend.com/emails

{
  "from": "hello@example.com",
  "to": ["user@example.com"],
  "subject": "Welcome!",
  "react": "WelcomeEmail",
  "props": {
    "name": "John"
  }
}
```

### Get email status

```bash
GET https://api.resend.com/emails/{email_id}
```

### List emails

```bash
GET https://api.resend.com/emails
```

### Send batch emails

```bash
POST https://api.resend.com/emails/batch

[
  {
    "from": "hello@example.com",
    "to": ["user1@example.com"],
    "subject": "Welcome User 1"
  },
  {
    "from": "hello@example.com",
    "to": ["user2@example.com"],
    "subject": "Welcome User 2"
  }
]
```

### List domains

```bash
GET https://api.resend.com/domains
```

### Verify domain

```bash
POST https://api.resend.com/domains/{domain_id}/verify
```

## Node.js SDK

### Install

```bash
npm install resend
```

### Usage

```typescript
import { Resend } from 'resend';

const resend = new Resend('re_xxx');

await resend.emails.send({
  from: 'hello@example.com',
  to: 'user@example.com',
  subject: 'Welcome!',
  html: '<h1>Welcome!</h1>'
});
```

### With React Email

```typescript
import { WelcomeEmail } from './emails/welcome';

await resend.emails.send({
  from: 'hello@example.com',
  to: 'user@example.com',
  subject: 'Welcome!',
  react: WelcomeEmail({ name: 'John' })
});
```

## Email Statuses

- `queued` - Email queued for delivery
- `sent` - Email sent to recipient server
- `delivered` - Email delivered
- `opened` - Email opened (if tracking enabled)
- `clicked` - Link clicked (if tracking enabled)
- `bounced` - Email bounced
- `complained` - Marked as spam

## Webhook Events

| Event | When |
|-------|------|
| `email.sent` | Email sent |
| `email.delivered` | Email delivered |
| `email.opened` | Email opened |
| `email.clicked` | Link clicked |
| `email.bounced` | Email bounced |
| `email.complained` | Spam complaint |

## When to Use

- Sending transactional emails
- Welcome emails, password resets
- Receipt and notification emails
- Developer-friendly email integration
- React-based email templates
- Quick CLI testing of email flows without writing code

## Rate Limits

- Free: 100 emails/day, 3,000/month
- Pro: 100 emails/second
- Higher limits on scale plans

## Relevant Skills

- emails
- onboarding

## Retry identity in the bundled CLI

For single `send` and whole `batch` operations, pass `--idempotency-key <stable_key>` to send the `Idempotency-Key` header. Use one key per logical send and retain the same payload/key when retrying; use a new key for a different send. The CLI accepts 1–256 printable ASCII characters, forwards the caller's key, and never generates a new key or retries automatically.

```bash
node tools/clis/resend.js send --from sender@example.org --to user@example.org --subject Welcome --text Hello --idempotency-key welcome/user-123 --dry-run
```

Resend retains keys for 24 hours. Reusing a key with a different payload returns a conflict; once retention expires it cannot prevent duplicates. This is a provider feature, not permanent exactly-once delivery. See [Resend idempotency keys](https://resend.com/docs/dashboard/emails/idempotency-keys). Dry runs show the key with authentication redacted; contract tests use fixtures and send no email.

## Paging bundled CLI collections

The `emails list`, `domains list`, `broadcasts list`, `segments list`, `api-keys list` and `templates list` commands accept `--limit <1-100>` and either `--after <id>` or `--before <id>`. Inspect the provider's `has_more` and returned object IDs, then request the next page manually. The CLI preserves raw responses and does not silently aggregate or issue more calls.

```bash
node tools/clis/resend.js emails list --limit 100 --after <last_email_id> --dry-run
```

No flags retains provider defaults, including unpaginated legacy lists where the provider returns all items unless a limit is supplied. Supplying both directions, an empty cursor or an invalid limit fails before fetch. See [Resend pagination](https://resend.com/docs/api-reference/pagination); fixtures verify request construction without live account calls.

## File: tools/integrations/rewardful.md

# Rewardful

Affiliate and referral tracking for Stripe-based SaaS businesses.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for affiliates, referrals, commissions |
| MCP | - | Not available |
| CLI | ✓ | [rewardful.js](../clis/rewardful.js) |
| SDK | - | API-only, JavaScript snippet for tracking |

## Authentication

- **Type**: HTTP Basic authentication
- **Username**: API secret; leave the password empty
- **Header**: `Authorization: Basic {base64(api_secret + ":")}`
- **Get key**: Settings > API in Rewardful dashboard

## Common Agent Operations

### List affiliates

```bash
GET https://api.getrewardful.com/v1/affiliates
```

### Get affiliate by ID

```bash
GET https://api.getrewardful.com/v1/affiliates/{affiliate_id}
```

### Search affiliate by email

```bash
GET https://api.getrewardful.com/v1/affiliates?email=affiliate@example.com
```

### Get referral by Stripe customer

```bash
GET https://api.getrewardful.com/v1/referrals?stripe_customer_id={customer_id}
```

### List referrals for affiliate

```bash
GET https://api.getrewardful.com/v1/referrals?affiliate_id={affiliate_id}
```

### Get commission details

```bash
GET https://api.getrewardful.com/v1/commissions/{commission_id}
```

### List commissions

```bash
GET https://api.getrewardful.com/v1/commissions?affiliate_id={affiliate_id}
```

### Create affiliate link

```bash
POST https://api.getrewardful.com/v1/affiliate_links
Content-Type: application/x-www-form-urlencoded

affiliate_id={affiliate_id}&token=custom-link-token
```

### Update affiliate

```bash
PUT https://api.getrewardful.com/v1/affiliates/{affiliate_id}
Content-Type: application/x-www-form-urlencoded

first_name=John&last_name=Doe&paypal_email=john%40example.com
```

Mutation requests use form encoding, including spaces, Unicode, `+`, `&`, and email addresses. `--dry-run` shows the exact encoded request body with masked authentication. HTTP errors exit unsuccessfully.

`links create --affiliate-id <id> [--token <token>]` passes the affiliate ID in the form body. The token is optional; Rewardful can generate one. The API does not accept a destination `--url`; configure the campaign destination in Rewardful. Additional affiliate links require a Growth or Enterprise plan.

Primary contracts: [request format and authentication](https://developers.rewardful.com/rest-api/overview), [affiliate update](https://developers.rewardful.com/rest-api/affiliates/update), and [affiliate link creation](https://developers.rewardful.com/rest-api/affiliate-links/create).

## JavaScript Tracking

### Install snippet

```html
<script>
(function(w,r){w._rwq=r;w[r]=w[r]||function(){(w[r].q=w[r].q||[]).push(arguments)}})(window,'rewardful');
</script>
<script async src='https://r.wdfl.co/rw.js' data-rewardful='YOUR_API_KEY'></script>
```

### Track conversion manually

```javascript
rewardful('convert', { email: 'customer@example.com' });
```

## Webhook Events

| Event | When |
|-------|------|
| `affiliate.created` | New affiliate signs up |
| `affiliate.approved` | Affiliate approved |
| `referral.created` | New referral tracked |
| `referral.converted` | Referral becomes customer |
| `commission.created` | Commission generated |
| `commission.paid` | Commission paid out |

## Key Objects

- **Affiliate** - Partner promoting your product
- **Referral** - Tracked visit/lead from affiliate
- **Commission** - Earned payment for affiliate
- **Campaign** - Program with specific terms
- **Link** - Tracking URL for affiliate

## Integration with Stripe

Rewardful automatically:
1. Tracks referral cookie when user visits via affiliate link
2. Associates Stripe customer with referral on checkout
3. Creates commissions when subscriptions are paid
4. Handles recurring commissions for subscriptions

## When to Use

- Setting up affiliate/referral programs for SaaS
- Tracking referral attribution from Stripe payments
- Managing affiliate relationships
- Processing affiliate payouts
- Analyzing referral program performance

## Rate Limits

- 120 requests per minute
- Contact support for higher limits

## Relevant Skills

- referrals
- pricing

### Listing all collection pages with the CLI

Rewardful returns paginated affiliate, referral and commission collections. Pass `--page` and `--limit` (provider maximum 100) to advance while preserving the selected filters:

```bash
node tools/clis/rewardful.js referrals list --affiliate-id aff_123 --page 3 --limit 50
node tools/clis/rewardful.js commissions list --affiliate-id aff_123 --page 2 --limit 50
node tools/clis/rewardful.js affiliates list --page 2 --limit 50
```

Read the response's pagination metadata before requesting another page. No flags retain the provider's default page and size; the CLI does not automatically fetch every page.

Sources: [referrals](https://developers.rewardful.com/rest-api/referrals/list), [commissions](https://developers.rewardful.com/rest-api/commissions/list), [affiliates](https://developers.rewardful.com/rest-api/affiliates/list).

## File: tools/integrations/rowbound.md

# rowbound

Open-source **CLI + MCP server** that turns a Google Sheet into a GTM enrichment pipeline — sources create rows, actions enrich them, with native **waterfalls**. The self-hosted, bring-your-own-key alternative to Clay: your data lives in your Sheet, you supply the provider API keys, and an agent can drive it over MCP.

- **Repo**: [github.com/eliasstravik/rowbound](https://github.com/eliasstravik/rowbound) (MIT)
- **Runtime**: Node 22+ CLI over the Google Workspace CLI (`gws`); ships an MCP server (`rowbound mcp`, stdio).
- Credit: by Elias Stråvik. This is an integration guide for an external open-source tool, not an affiliation.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | - | No hosted REST API — it's a local CLI + MCP over your Google Sheet |
| MCP | ✓ | `rowbound mcp` (stdio) exposes ~20 tools to Claude Desktop / any MCP client |
| CLI | ✓ | Node 22+; drives Sheets via `gws` |
| SDK | - | Use the CLI or MCP |
| License | MIT | Open source, self-hosted |

## Setup

1. Install the CLI (Node 22+) and authenticate Google via the Workspace CLI (`gws`) it builds on.
2. Point it at a Google Sheet; pipeline config lives in the Sheet's **Developer Metadata** (an Apps Script sidebar can edit it in-sheet).
3. Supply provider API keys as environment variables (bring your own keys for Apollo, Hunter, FullEnrich, and others).
4. Register the MCP server (`rowbound mcp`) with your agent to drive it conversationally.

See the repo README for exact install commands and flags (they evolve; don't hard-code them).

## Model: sources → actions

- **Sources** create rows: `http`, `exec`, `webhook`, `script`.
- **Actions** enrich rows. Action types include:
  - **`waterfall`** — try providers in fallback order (e.g. Clearbit → Apollo → Hunter) until one returns. The headline feature.
  - **`http`** — call any HTTP API per row.
  - **`ai`** — run a per-row prompt via a headless agent (Claude/Codex).
  - **`formula`**, **`lookup`**, **`write`**, **`exec`**, **`script`**.
- **`when`** conditions gate each action; smart-skip, rate limiting, retry/backoff, run history, dry-run, and SSRF protection are built in.

## Common Agent Operations (MCP)

The `rowbound mcp` server exposes tools an agent calls directly — representative ones:

- `run_pipeline` — execute the Sheet's configured pipeline (respecting `when` gates and skips).
- `add_action` — append an enrichment action (e.g. a waterfall) to the pipeline.
- `preview_rows` — inspect current rows / a dry-run before spending credits.

(~20 tools total; see the repo for the full list and arguments.)

## When to Use

- You want **Clay-style waterfall enrichment** but **self-hosted, BYOK, and version-controllable** — no per-seat SaaS, your data in your own Sheet.
- An agent needs to **drive enrichment over MCP** (build a list, add a waterfall, run it, read results) rather than clicking a no-code tool.
- Cost-sensitive enrichment where you want direct control of provider keys and fallback order.

## vs. the paid options in this category

- **Clay** — hosted, no-code, 75+ providers, MCP connector. Pick when you want the managed platform and breadth.
- **rowbound** — open-source, local, BYOK, native waterfalls, MCP. Pick when you want ownership, cost control, and an agent-drivable pipeline.

## Relevant Skills

- prospecting
- cold-email
- revops
- sales-enablement

## File: tools/integrations/salesforce.md

# Salesforce

Enterprise CRM platform for sales, service, and marketing.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API, SOAP API, Bulk API |
| MCP | - | Not available |
| CLI | ✓ | Salesforce CLI (`sf`) |
| SDK | ✓ | JSforce, simple-salesforce, etc. |

## Authentication

- **Type**: OAuth 2.0 (Web Server Flow or JWT Bearer)
- **Header**: `Authorization: Bearer {access_token}`
- **Instance URL**: Use instance_url from auth response

## Common Agent Operations

### Query records (SOQL)

```bash
GET https://{instance}.salesforce.com/services/data/v59.0/query?q=SELECT+Id,Name,Email+FROM+Contact+LIMIT+10

Authorization: Bearer {access_token}
```

### Get record by ID

```bash
GET https://{instance}.salesforce.com/services/data/v59.0/sobjects/Contact/{record_id}

Authorization: Bearer {access_token}
```

### Create record

```bash
POST https://{instance}.salesforce.com/services/data/v59.0/sobjects/Contact

{
  "FirstName": "John",
  "LastName": "Doe",
  "Email": "john@example.com",
  "AccountId": "{account_id}"
}
```

### Update record

```bash
PATCH https://{instance}.salesforce.com/services/data/v59.0/sobjects/Contact/{record_id}

{
  "Title": "Senior Developer"
}
```

### Search records (SOSL)

```bash
GET https://{instance}.salesforce.com/services/data/v59.0/search?q=FIND+{searchTerm}+IN+ALL+FIELDS+RETURNING+Contact(Id,Name,Email)

Authorization: Bearer {access_token}
```

### Get opportunities

```bash
GET https://{instance}.salesforce.com/services/data/v59.0/query?q=SELECT+Id,Name,Amount,StageName,CloseDate+FROM+Opportunity+WHERE+IsClosed=false

Authorization: Bearer {access_token}
```

### Describe object

```bash
GET https://{instance}.salesforce.com/services/data/v59.0/sobjects/Contact/describe

Authorization: Bearer {access_token}
```

## CLI Commands

```bash
# Authenticate
sf org login web

# Query records
sf data query --query "SELECT Id, Name FROM Account LIMIT 10"

# Create record
sf data create record --sobject Account --values "Name='New Account'"

# Deploy metadata
sf project deploy start

# Run Apex
sf apex run --file script.apex
```

## SOQL Examples

```sql
-- Get contacts with accounts
SELECT Id, Name, Email, Account.Name
FROM Contact
WHERE Account.Industry = 'Technology'

-- Get opportunities by stage
SELECT StageName, COUNT(Id)
FROM Opportunity
GROUP BY StageName

-- Get recent leads
SELECT Id, Name, Company, Status
FROM Lead
WHERE CreatedDate = LAST_N_DAYS:30
ORDER BY CreatedDate DESC
```

## Key Objects

- **Lead** - Potential customer
- **Contact** - Person at account
- **Account** - Company/organization
- **Opportunity** - Sales deal
- **Case** - Support ticket
- **Campaign** - Marketing campaign

## When to Use

- Enterprise CRM operations
- Complex sales processes
- Multi-object relationships
- Custom object management
- Marketing campaign tracking

## Rate Limits

- 15,000 API calls per 24 hours (Enterprise)
- Higher limits available

## Relevant Skills

- emails
- analytics
- ads

## File: tools/integrations/sanity.md

# Sanity

Headless CMS with real-time collaboration, GROQ query language, and schema-as-code.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | GROQ queries, Mutations API, Assets API |
| MCP | - | No official MCP server |
| CLI | ✓ | `sanity` CLI for studio, datasets, deployment |
| SDK | ✓ | `@sanity/client`, `next-sanity`, `@sanity/image-url` |

## Authentication

- **Type**: API Token (Bearer)
- **Header**: `Authorization: Bearer skXXXXXX`
- **Tokens**: Create in Sanity Manage → API → Tokens
- **Permissions**: Read-only or Read+Write per token

## Common Agent Operations

### Query documents (GROQ)

URL-encode the `query` parameter value in practice.

```bash
GET https://{projectId}.api.sanity.io/v2024-01-01/data/query/{dataset}?query=*[_type == "post"]{title, slug, publishedAt}
```

### Query with parameters

```bash
GET https://{projectId}.api.sanity.io/v2024-01-01/data/query/{dataset}?query=*[_type == "post" && slug.current == $slug][0]&$slug="my-post"
```

### Get document by ID

```bash
GET https://{projectId}.api.sanity.io/v2024-01-01/data/doc/{dataset}/{documentId}
```

### Create document (Mutations API)

```bash
POST https://{projectId}.api.sanity.io/v2024-01-01/data/mutate/{dataset}

{
  "mutations": [
    {
      "create": {
        "_type": "post",
        "title": "New Post",
        "slug": {"_type": "slug", "current": "new-post"},
        "body": [{"_type": "block", "children": [{"_type": "span", "text": "Hello"}]}]
      }
    }
  ]
}
```

Use `createOrReplace` instead if you want to upsert (requires `_id` field).

### Delete document

```bash
POST https://{projectId}.api.sanity.io/v2024-01-01/data/mutate/{dataset}

{
  "mutations": [
    {"delete": {"id": "document-id"}}
  ]
}
```

### Patch document

```bash
POST https://{projectId}.api.sanity.io/v2024-01-01/data/mutate/{dataset}

{
  "mutations": [
    {
      "patch": {
        "id": "document-id",
        "set": {"title": "Updated Title"}
      }
    }
  ]
}
```

## CLI Commands

```bash
# Create a new Sanity project
sanity init

# Start the studio locally
sanity dev

# Deploy studio to Sanity hosting
sanity deploy

# Export dataset
sanity dataset export production ./backup.tar.gz

# Import dataset
sanity dataset import ./data.ndjson production

# List datasets
sanity dataset list

# Run a GROQ query
sanity documents query '*[_type == "post"][0..9]{title, slug}'
```

## Key Objects

- **Document** — Top-level content item with `_id`, `_type`, `_rev`
- **Asset** — Images and files stored in Sanity CDN
- **Reference** — Link between documents (`{_type: "reference", _ref: "doc-id"}`)
- **Portable Text** — Rich text as structured array of blocks
- **Dataset** — Isolated content database (e.g., `production`, `staging`)
- **Slug** — URL-friendly identifier (`{_type: "slug", current: "my-slug"}`)

## When to Use

- Structured content for marketing sites and blogs
- Multi-channel content delivery (web, mobile, email)
- Real-time collaborative editing workflows
- Content-heavy sites with complex models
- Next.js or React-based frontends

## Rate Limits

Rate limits vary by plan. Documented defaults:

- CDN API (queries): High throughput, globally distributed (no hard per-second cap published)
- API (without CDN): Rate-limited per project (varies by plan)
- Mutations: Rate-limited per project (varies by plan)
- See [Sanity technical limits](https://www.sanity.io/docs/technical-limits) for current values

## Relevant Skills

- content-strategy (CMS selection, content modeling)
- programmatic-seo (CMS as data source for generated pages)
- site-architecture (URL structure from CMS slugs)

## File: tools/integrations/savvycal.md

# SavvyCal

Scheduling platform API for managing scheduling links, events, availability slots, and webhooks.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API v1 - scheduling links, events, webhooks |
| MCP | - | Not available |
| CLI | ✓ | [savvycal.js](../clis/savvycal.js) |
| SDK | - | No official SDK |

## Authentication

- **Type**: Bearer Token (Personal Access Token or OAuth 2.0)
- **Header**: `Authorization: Bearer {token}`
- **Get key**: Developer Settings in SavvyCal dashboard (create a Personal Access Token)

## Common Agent Operations

### Get current user

```bash
GET https://api.savvycal.com/v1/me
```

### List scheduling links

```bash
GET https://api.savvycal.com/v1/links
```

### Get a scheduling link

```bash
GET https://api.savvycal.com/v1/links/{id}
```

### Create a scheduling link

```bash
POST https://api.savvycal.com/v1/links

{
  "name": "Introductory Meeting"
}
```

The personal-link endpoint creates a link for the current authenticated user. These examples use the documented `name` field; configure meeting duration and URL details in SavvyCal rather than assuming undocumented request fields take effect.

### Update a scheduling link

```bash
PATCH https://api.savvycal.com/v1/links/{id}

{
  "name": "Updated Meeting Name"
}
```

### Delete a scheduling link

```bash
DELETE https://api.savvycal.com/v1/links/{id}
```

### Duplicate a scheduling link

```bash
POST https://api.savvycal.com/v1/links/{id}/duplicate
```

### Toggle link state (active/disabled)

```bash
POST https://api.savvycal.com/v1/links/{id}/toggle
```

### Get available time slots

```bash
GET https://api.savvycal.com/v1/links/{id}/slots
```

### List events

```bash
GET https://api.savvycal.com/v1/events
```

### Get an event

```bash
GET https://api.savvycal.com/v1/events/{id}
```

### Create an event

```bash
POST https://api.savvycal.com/v1/links/{link_id}/events

{
  "start_at": "2024-01-20T10:00:00Z",
  "end_at": "2024-01-20T10:30:00Z",
  "time_zone": "America/New_York",
  "display_name": "John Doe",
  "email": "john@example.com"
}
```

The CLI maps `--name` to `display_name` and requires the booking start, end, and
attendee time zone. Choose an available slot for the scheduling link:

```bash
node tools/clis/savvycal.js events create --link-id link_123 \
  --start-at 2024-01-20T10:00:00Z --end-at 2024-01-20T10:30:00Z \
  --time-zone America/New_York --name "John Doe" --email john@example.com
```

See the official [create event contract](https://developers.savvycal.com/api/create-event).

### Cancel an event

```bash
POST https://api.savvycal.com/v1/events/{id}/cancel
```

### List webhooks

```bash
GET https://api.savvycal.com/v1/webhooks
```

### Create a webhook

```bash
POST https://api.savvycal.com/v1/webhooks

{
  "url": "https://example.com/webhook",
  "events": ["event.created", "event.canceled"]
}
```

## Key Metrics

### Scheduling Link Data
- `id` - Unique link identifier
- `name` - Display name
- `slug` - URL slug
- `duration_minutes` - Meeting duration
- `state` - Active or disabled
- `url` - Full scheduling URL

### Event Data
- `id` - Unique event identifier
- `name` - Invitee name
- `email` - Invitee email
- `start_at` / `end_at` - Event timing
- `status` - Event status
- `scheduling_link` - Associated scheduling link

## Parameters

### List Events
- `before` / `after` - Pagination cursors
- `limit` - Results per page (default 20, max 100)

### List Scheduling Links
- `before` / `after` - Pagination cursors
- `limit` - Results per page

## When to Use

- Managing scheduling links programmatically
- Retrieving booked events for CRM or analytics sync
- Checking available time slots for custom booking UIs
- Automating scheduling link creation for campaigns
- Monitoring booking activity via webhooks

## Rate Limits

- Not officially documented
- Implement retry logic with exponential backoff
- Monitor for HTTP 429 responses

## Relevant Skills

- lead-generation
- sales-automation
- appointment-scheduling
- customer-onboarding

## API References

- [Scheduling-link endpoints](https://developers.savvycal.com/api/scheduling-links)
- [Create-link request fields](https://developers.savvycal.com/api/schemas/createlinkrequest)
- [Update-link request fields](https://developers.savvycal.com/api/schemas/updatelinkrequest)

## File: tools/integrations/segment.md

# Segment

Customer data platform for collecting, routing, and activating user data.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Tracking API, Profile API, Config API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | analytics.js, iOS, Android, server libraries |

## Authentication

- **Tracking**: Write Key (per source)
- **API**: Access Token (OAuth 2.0)
- **Header**: `Authorization: Bearer {access_token}`

## Common Agent Operations

### Track event

```bash
POST https://api.segment.io/v1/track

Authorization: Basic {base64(write_key:)}

{
  "userId": "user_123",
  "event": "signup_completed",
  "properties": {
    "plan": "pro",
    "method": "email"
  }
}
```

### Identify user

```bash
POST https://api.segment.io/v1/identify

Authorization: Basic {base64(write_key:)}

{
  "userId": "user_123",
  "traits": {
    "email": "user@example.com",
    "name": "John Doe",
    "plan": "pro"
  }
}
```

### Track page view

```bash
POST https://api.segment.io/v1/page

Authorization: Basic {base64(write_key:)}

{
  "userId": "user_123",
  "name": "Pricing",
  "properties": {
    "title": "Pricing - Example",
    "url": "https://example.com/pricing"
  }
}
```

### Batch events

```bash
POST https://api.segment.io/v1/batch

Authorization: Basic {base64(write_key:)}

{
  "batch": [
    {"type": "identify", "userId": "user_1", "traits": {"plan": "free"}},
    {"type": "track", "userId": "user_1", "event": "signup"}
  ]
}
```

### Get user profile (Profile API)

```bash
GET https://profiles.segment.com/v1/spaces/{space_id}/collections/users/profiles/user_id:{user_id}/traits

Authorization: Basic {base64(access_token:)}
```

### Get user events

```bash
GET https://profiles.segment.com/v1/spaces/{space_id}/collections/users/profiles/user_id:{user_id}/events

Authorization: Basic {base64(access_token:)}
```

## JavaScript SDK

```javascript
// Initialize
analytics.load('WRITE_KEY');

// Identify user
analytics.identify('user_123', {
  email: 'user@example.com',
  plan: 'pro'
});

// Track event
analytics.track('Feature Used', {
  feature_name: 'export'
});

// Page view
analytics.page('Pricing');
```

## Key Concepts

- **Sources** - Where data comes from (website, app, server)
- **Destinations** - Where data goes (analytics, CRM, ads)
- **Tracking Plan** - Schema for events and properties
- **Protocols** - Data governance and validation
- **Personas** - Unified user profiles
- **Audiences** - Computed user segments

## Common Destinations

- Analytics: GA4, Mixpanel, Amplitude
- CRM: HubSpot, Salesforce
- Email: Customer.io, Mailchimp
- Ads: Google Ads, Meta
- Data Warehouse: BigQuery, Snowflake

## When to Use

- Centralizing event tracking
- Routing data to multiple tools
- Maintaining consistent tracking
- Building unified user profiles
- Syncing audiences across platforms

## Rate Limits

- 500 requests/second per source
- Batch up to 500KB or 32KB per event

## Relevant Skills

- analytics
- emails
- ads

### Profile identifiers in the CLI

Pass the raw user ID to `profiles traits` or `profiles events`. The CLI URL-encodes
the value so characters such as `/`, `+`, `?`, and `#` remain part of the user ID.
Do not pre-encode it. See [Profile API identifiers](https://www.twilio.com/docs/segment/unify/profile-api).

## CLI anonymous and known identities

The `track event`, `page view`, and `identify user` commands accept either
`--user-id`, `--anonymous-id`, or both. Use an existing anonymous identifier
for pre-signup activity rather than inventing a known customer ID:

```bash
node tools/clis/segment.js track event --anonymous-id anon-owned \
  --event 'Pricing Viewed' --properties '{"plan":"pro"}' --dry-run

# When this same visitor becomes a known user
node tools/clis/segment.js identify user --user-id user-owned \
  --anonymous-id anon-owned --traits '{"plan":"paid"}' --dry-run
```

The CLI passes the IDs through unchanged; it does not generate an anonymous
ID, store identity state, or infer that two people are the same. Reuse the
actual identifier associated with that visitor and supply both only when the
association is known. Destination identity handling varies: acceptance by
Segment does not prove every destination merged the history. An anonymous ID
is an identifier, not a guarantee of anonymity or permission to collect data.
Send events only when the collection is already authorized.

At least one ID is required before sending these single-event requests.
Existing `--user-id` calls and raw batch payloads are unchanged. Profile
lookups continue to require a known `--user-id`; `--anonymous-id` does not
change their resource path. Previews mask the write key and make no request.

Official [common identity fields](https://www.twilio.com/docs/segment/connections/spec/common)
and [Identify semantics](https://www.twilio.com/docs/segment/connections/spec/identify).

## Importing and retrying individual events

Single `track event`, `identify user`, and `page view` calls accept
`--timestamp` and `--message-id`. Use an ISO datetime with a timezone to retain
when a historical event occurred, and reuse the source event's ID when retrying:

```bash
node tools/clis/segment.js track event --user-id customer-1 --event "Order Completed" \
  --timestamp 2024-04-12T10:15:30Z --message-id order-123 --dry-run
```

Both fields are omitted when flags are absent, leaving Segment's defaults
intact. Message IDs must contain 1–100 characters. For `batch send`, place the
metadata on each event in `--events`; these individual-call flags do not rewrite
batches. See [common fields](https://www.twilio.com/docs/segment/connections/spec/common)
and [duplicate handling](https://www.twilio.com/docs/segment/guides/duplicate-data).
Downstream destinations can handle these fields differently.

## File: tools/integrations/semrush.md

# SEMrush

SEO and competitive analysis platform for keyword research and site audits.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Analytics API, Projects API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | API-only |

## Authentication

- **Type**: API Key
- **Parameter**: `key={api_key}` in query string
- **Get key**: My Profile > API in SEMrush dashboard

## Common Agent Operations

### Domain overview

```bash
GET https://api.semrush.com/?type=domain_ranks&key={api_key}&export_columns=Db,Dn,Rk,Or,Ot,Oc,Ad,At,Ac&domain=example.com
```

### Organic keywords

```bash
GET https://api.semrush.com/?type=domain_organic&key={api_key}&export_columns=Ph,Po,Pp,Pd,Nq,Cp,Ur,Tr,Tc,Co,Nr&domain=example.com&database=us&display_limit=100
```

### Keyword overview

```bash
GET https://api.semrush.com/?type=phrase_all&key={api_key}&export_columns=Ph,Nq,Cp,Co,Nr&phrase=keyword&database=us
```

### Related keywords

```bash
GET https://api.semrush.com/?type=phrase_related&key={api_key}&export_columns=Ph,Nq,Cp,Co,Nr,Td&phrase=keyword&database=us&display_limit=50
```

### Keyword difficulty

```bash
GET https://api.semrush.com/?type=phrase_kdi&key={api_key}&export_columns=Ph,Kd&phrase=keyword&database=us
```

### Backlinks overview

```bash
GET https://api.semrush.com/?type=backlinks_overview&key={api_key}&target=example.com&target_type=root_domain
```

### Backlinks list

```bash
GET https://api.semrush.com/?type=backlinks&key={api_key}&target=example.com&target_type=root_domain&export_columns=source_url,source_title,target_url,anchor&display_limit=100
```

### Competitors

```bash
GET https://api.semrush.com/?type=domain_organic_organic&key={api_key}&export_columns=Dn,Cr,Np,Or,Ot,Oc,Ad&domain=example.com&database=us&display_limit=20
```

## Response Format

Responses are CSV by default. Add `&export_escape=1` for proper escaping.

## Export Columns

### Domain Report
- `Db` - Database
- `Dn` - Domain
- `Rk` - Rank
- `Or` - Organic keywords
- `Ot` - Organic traffic
- `Oc` - Organic cost

### Keyword Report
- `Ph` - Phrase/keyword
- `Nq` - Search volume
- `Cp` - CPC
- `Co` - Competition
- `Kd` - Keyword difficulty
- `Nr` - Number of results

### Backlinks
- `source_url` - Linking page
- `target_url` - Target page
- `anchor` - Anchor text
- `source_title` - Page title

## Databases

Use country code: `us`, `uk`, `de`, `fr`, `ca`, `au`, etc.

## When to Use

- Keyword research
- Competitive analysis
- Backlink analysis
- Site audits
- Rank tracking
- Content gap analysis

## Rate Limits

- Varies by plan (10-30K units/day)
- Each API call costs units

## Relevant Skills

- seo-audit
- programmatic-seo
- content-strategy
- competitors

### CLI CSV decoding

The [Semrush CLI](../clis/semrush.js) requests `export_escape=1` and decodes the
semicolon-separated report into JSON objects. Quoted headers/cells, escaped
quotes, and line breaks inside cells are preserved as field values.

## File: tools/integrations/sendgrid.md

# SendGrid

Email delivery platform for transactional and marketing emails.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Mail Send API, Marketing API |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | Official libraries for most languages |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API Keys in SendGrid dashboard

## Common Agent Operations

### Send email

```bash
POST https://api.sendgrid.com/v3/mail/send

Authorization: Bearer {api_key}

{
  "personalizations": [{
    "to": [{"email": "user@example.com"}]
  }],
  "from": {"email": "hello@example.com"},
  "subject": "Welcome!",
  "content": [{
    "type": "text/html",
    "value": "<h1>Welcome!</h1>"
  }]
}
```

### Send with template

```bash
POST https://api.sendgrid.com/v3/mail/send

{
  "personalizations": [{
    "to": [{"email": "user@example.com"}],
    "dynamic_template_data": {
      "name": "John",
      "order_id": "12345"
    }
  }],
  "from": {"email": "hello@example.com"},
  "template_id": "d-xxx"
}
```

### Add contact to list

```bash
PUT https://api.sendgrid.com/v3/marketing/contacts

{
  "list_ids": ["list-id"],
  "contacts": [{
    "email": "user@example.com",
    "first_name": "John",
    "last_name": "Doe"
  }]
}
```

### Search contacts

```bash
POST https://api.sendgrid.com/v3/marketing/contacts/search

{
  "query": "email LIKE 'user@%'"
}
```

### Read marketing campaigns (Single Sends)

The CLI's `campaigns list` and `campaigns get <id>` commands read Marketing Single Sends:

```bash
GET https://api.sendgrid.com/v3/marketing/singlesends?page_size=25
GET https://api.sendgrid.com/v3/marketing/singlesends/{single_send_id}
```

List responses contain `result` and `_metadata`; get responses contain the Single Send object. The CLI prints these provider responses without reshaping them. These commands use the current Marketing API, which is also used by the contact commands. Legacy Marketing Campaigns use the separate `/v3/campaigns` API and are not supported by these commands.

### Get email statistics

```bash
GET https://api.sendgrid.com/v3/stats?start_date=2024-01-01&end_date=2024-01-31

Authorization: Bearer {api_key}
```

### Get bounces

```bash
GET https://api.sendgrid.com/v3/suppression/bounces

Authorization: Bearer {api_key}
```

### Get spam reports

```bash
GET https://api.sendgrid.com/v3/suppression/spam_reports

Authorization: Bearer {api_key}
```

### Validate email

```bash
POST https://api.sendgrid.com/v3/validations/email

{
  "email": "user@example.com"
}
```

## Webhook Events

| Event | Description |
|-------|-------------|
| `processed` | Email accepted |
| `delivered` | Email delivered |
| `open` | Email opened |
| `click` | Link clicked |
| `bounce` | Hard/soft bounce |
| `dropped` | Email dropped |
| `spamreport` | Marked as spam |
| `unsubscribe` | Unsubscribed |

## Node.js SDK

```javascript
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey('SG.xxx');

await sgMail.send({
  to: 'user@example.com',
  from: 'hello@example.com',
  subject: 'Welcome!',
  html: '<h1>Welcome!</h1>'
});
```

## When to Use

- Transactional email at scale
- Marketing email campaigns
- Email validation
- Deliverability management

## Rate Limits

- Free: 100 emails/day
- Paid: Varies by plan (up to millions/month)

## Relevant Skills

- emails
- analytics

## File: tools/integrations/sequenzy.md

# Sequenzy

Email marketing platform for lifecycle campaigns, automation sequences, subscriber management, transactional email, and analytics.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for subscribers, tags, events, campaigns, sequences, templates, transactional email, analytics, and webhooks |
| MCP | ✓ | `@sequenzy/mcp` stdio server for agent clients |
| CLI | ✓ | `@sequenzy/cli` for subscriber operations, transactional sends, and stats |
| SDK | - | Use the REST API directly |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer ***`
- **Base URL**: `https://api.sequenzy.com/api/v1`
- **Legacy base URL**: `https://api.sequenzy.com/v1`
- **Environment variable**: `SEQUENZY_API_KEY`

## MCP

### Quick setup

```bash
npx @sequenzy/setup
```

The setup wizard logs in, creates a personal API key, and configures supported MCP clients when possible.

### Manual MCP server config

```json
{
  "mcpServers": {
    "sequenzy": {
      "command": "npx",
      "args": ["-y", "@sequenzy/mcp"],
      "env": {
        "SEQUENZY_API_KEY": "seq_user_your_key_here"
      }
    }
  }
}
```

## CLI

### Install

```bash
# Using npx
npx sequenzy --help

# Or install globally
npm install -g @sequenzy/cli
```

### Login

```bash
sequenzy login
sequenzy whoami
```

### Common commands

```bash
# Subscribers
sequenzy subscribers list
sequenzy subscribers list --tag vip
sequenzy subscribers add user@example.com --tag premium --attr plan=pro
sequenzy subscribers get user@example.com
sequenzy subscribers remove user@example.com

# Transactional email
sequenzy send user@example.com --template welcome --var name=John
sequenzy send user@example.com --subject "Hello" --html "<h1>Hi!</h1>"

# Analytics
sequenzy stats
sequenzy stats --period 30d
sequenzy stats --campaign camp_abc123
sequenzy stats --sequence seq_xyz789
```

## Common Agent Operations

### Get account

```bash
GET https://api.sequenzy.com/api/v1/account

Authorization: Bearer ***
```

### List subscribers

```bash
GET https://api.sequenzy.com/api/v1/subscribers?page=1&limit=20&status=active&query=john&tags=customer,vip

Authorization: Bearer ***
```

### Create or update subscriber

```bash
POST https://api.sequenzy.com/api/v1/subscribers

Authorization: Bearer ***
Content-Type: application/json

{
  "email": "user@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "tags": ["customer", "newsletter"],
  "customAttributes": {
    "plan": "pro"
  }
}
```

### Add tag to subscriber

```bash
POST https://api.sequenzy.com/api/v1/subscribers/tags

Authorization: Bearer ***
Content-Type: application/json

{
  "email": "user@example.com",
  "tag": "vip"
}
```

### Trigger event for subscriber

```bash
POST https://api.sequenzy.com/api/v1/subscribers/events

Authorization: Bearer ***
Content-Type: application/json

{
  "email": "user@example.com",
  "event": "trial_started",
  "properties": {
    "plan": "pro"
  }
}
```

### List campaigns

```bash
GET https://api.sequenzy.com/api/v1/campaigns

Authorization: Bearer ***
```

### Create draft campaign

Create a draft campaign and linked email. A sender profile must already be configured.

```bash
POST https://api.sequenzy.com/api/v1/campaigns

Authorization: Bearer ***
Content-Type: application/json

{
  "name": "April Launch",
  "subject": "A quick update",
  "labels": ["launch"],
  "html": "<p>Hello there!</p>"
}
```

### Send campaign test

```bash
POST https://api.sequenzy.com/api/v1/campaigns/{campaignId}/test

Authorization: Bearer ***
Content-Type: application/json

{
  "to": "reviewer@example.com"
}
```

### Schedule campaign

```bash
POST https://api.sequenzy.com/api/v1/campaigns/{campaignId}/schedule

Authorization: Bearer ***
Content-Type: application/json

{
  "scheduledAt": "2026-05-20T15:00:00Z"
}
```

### List sequences

```bash
GET https://api.sequenzy.com/api/v1/sequences

Authorization: Bearer ***
```

### Enable or disable sequence

```bash
POST https://api.sequenzy.com/api/v1/sequences/{sequenceId}/enable
POST https://api.sequenzy.com/api/v1/sequences/{sequenceId}/disable

Authorization: Bearer ***
```

### Send transactional email

Send via a saved template slug or by passing direct subject/body content.

```bash
POST https://api.sequenzy.com/api/v1/transactional/send

Authorization: Bearer ***
Content-Type: application/json

{
  "to": "user@example.com",
  "slug": "welcome",
  "variables": {
    "name": "John"
  },
  "subscriberExternalId": "user_123"
}
```

### Get metrics

```bash
GET https://api.sequenzy.com/api/v1/metrics
GET https://api.sequenzy.com/api/v1/metrics/campaigns/{campaignId}
GET https://api.sequenzy.com/api/v1/metrics/sequences/{sequenceId}
GET https://api.sequenzy.com/api/v1/metrics/recipients

Authorization: Bearer ***
```

### Webhooks

```bash
GET https://api.sequenzy.com/api/v1/webhooks
POST https://api.sequenzy.com/api/v1/webhooks
PATCH https://api.sequenzy.com/api/v1/webhooks/{id}
DELETE https://api.sequenzy.com/api/v1/webhooks/{id}
POST https://api.sequenzy.com/api/v1/webhooks/{id}/test

Authorization: Bearer ***
```

## Key Concepts

- **Subscribers** - Contacts with email, status, tags, custom attributes, and optional external IDs
- **Tags** - Lightweight labels used for targeting and segmentation
- **Segments** - Dynamic subscriber groups based on attributes or engagement
- **Campaigns** - Draftable and schedulable one-time marketing sends
- **Sequences** - Automated lifecycle flows that can be enabled, disabled, and measured
- **Templates** - Reusable email content for transactional and marketing workflows
- **Transactional emails** - Single-recipient or small batch sends triggered by product events
- **Engagement metrics** - Sent, delivered, bounced, opened, clicked, unsubscribed, and derived rates

## Safety Notes

- Inspect account, sender profile, audience, and target objects before mutating anything.
- Prefer creating drafts and sending tests before scheduling or enabling live delivery.
- Do not schedule a campaign, enable a sequence, or send a live transactional email without explicit approval.
- Use recipient status, bounce, complaint, and unsubscribe data to avoid sending to suppressed contacts.
- Use direct API calls for high-volume or scripted operations; use MCP or CLI for agent-driven interactive workflows.

## When to Use

- Managing subscribers, tags, lists, and segments
- Drafting and scheduling lifecycle campaigns
- Building onboarding, activation, retention, or winback sequences
- Sending product-triggered transactional emails
- Reviewing campaign, sequence, and recipient engagement metrics
- Connecting AI agents to email marketing operations through MCP

## Rate Limits

- Check the latest Sequenzy API documentation for plan-specific limits.
- Use pagination for list endpoints; subscriber lists support `page` and `limit` with a maximum limit of 100.

## Relevant Skills

- emails
- onboarding
- analytics
- launch

## File: tools/integrations/shopify.md

# Shopify

E-commerce platform for online stores and retail.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST Admin API, Storefront API, GraphQL |
| MCP | - | Not available |
| CLI | ✓ | Shopify CLI for themes and apps |
| SDK | ✓ | Official libraries for multiple languages |

## Authentication

- **Type**: Access Token (Custom App or OAuth)
- **Header**: `X-Shopify-Access-Token: {access_token}`
- **Base URL**: `https://{shop}.myshopify.com/admin/api/2024-01/`

## Common Agent Operations

### Get shop info

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/shop.json

X-Shopify-Access-Token: {access_token}
```

### List products

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/products.json?limit=50

X-Shopify-Access-Token: {access_token}
```

### Get product

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/products/{product_id}.json

X-Shopify-Access-Token: {access_token}
```

### Create product

```bash
POST https://{shop}.myshopify.com/admin/api/2024-01/products.json

X-Shopify-Access-Token: {access_token}

{
  "product": {
    "title": "Product Name",
    "body_html": "<p>Description</p>",
    "vendor": "Brand",
    "product_type": "Category",
    "variants": [{
      "price": "99.00",
      "sku": "SKU-001"
    }]
  }
}
```

### List orders

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/orders.json?status=any&limit=50

X-Shopify-Access-Token: {access_token}
```

### Get order

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/orders/{order_id}.json

X-Shopify-Access-Token: {access_token}
```

### List customers

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/customers.json?limit=50

X-Shopify-Access-Token: {access_token}
```

### Search customers

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/customers/search.json?query=email:user@example.com

X-Shopify-Access-Token: {access_token}
```

### Get analytics

```bash
GET https://{shop}.myshopify.com/admin/api/2024-01/reports.json

X-Shopify-Access-Token: {access_token}
```

## GraphQL API

```graphql
{
  products(first: 10) {
    edges {
      node {
        id
        title
        totalInventory
        priceRangeV2 {
          minVariantPrice {
            amount
          }
        }
      }
    }
  }
}
```

## CLI Commands

```bash
# Login
shopify login --store={shop}

# Create theme
shopify theme init

# Push theme
shopify theme push

# Preview theme
shopify theme dev

# Create app
shopify app create node
```

## Webhook Topics

| Topic | When |
|-------|------|
| `orders/create` | New order |
| `orders/paid` | Order paid |
| `orders/fulfilled` | Order shipped |
| `customers/create` | New customer |
| `products/update` | Product changed |
| `checkouts/create` | Checkout started |

## When to Use

- E-commerce store management
- Product catalog operations
- Order processing
- Customer data management
- Inventory tracking

## Rate Limits

- REST: 2 requests/second
- GraphQL: 50 points/second
- Bulk operations available

## Relevant Skills

- analytics
- emails
- referrals

## File: tools/integrations/similarweb.md

# Similarweb

Competitive traffic intelligence platform providing website analytics, traffic sources, keyword data, and competitor insights.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Traffic, Search, Referrals, Competitors, Geography |
| MCP | - | Not available |
| CLI | ✓ | [similarweb.js](../clis/similarweb.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key
- **Query param**: `?api_key={key}`
- **Get key**: Account Settings > API at https://account.similarweb.com

## Common Agent Operations

### Total Visits

```bash
GET https://api.similarweb.com/v1/website/example.com/total-traffic-and-engagement/visits?api_key={key}&start_date=2024-01&end_date=2024-03&country=us&granularity=monthly
```

### Pages Per Visit

```bash
GET https://api.similarweb.com/v1/website/example.com/total-traffic-and-engagement/pages-per-visit?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Average Visit Duration

```bash
GET https://api.similarweb.com/v1/website/example.com/total-traffic-and-engagement/average-visit-duration?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Bounce Rate

```bash
GET https://api.similarweb.com/v1/website/example.com/total-traffic-and-engagement/bounce-rate?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Traffic Sources Breakdown

```bash
GET https://api.similarweb.com/v1/website/example.com/traffic-sources/overview?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Top Referral Sites

```bash
GET https://api.similarweb.com/v4/website/example.com/traffic-sources/referrals?api_key={key}&start_date=2024-01&end_date=2024-03&country=world
```

### Organic Keywords

```bash
GET https://api.similarweb.com/v1/website/example.com/search/organic-search-keywords?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Paid Keywords

```bash
GET https://api.similarweb.com/v1/website/example.com/search/paid-search-keywords?api_key={key}&start_date=2024-01&end_date=2024-03
```

### Similar Sites / Competitors

```bash
GET https://api.similarweb.com/v1/website/example.com/similar-sites/similarsites?api_key={key}
```

### Category Ranking

```bash
GET https://api.similarweb.com/v1/website/example.com/category-rank/category-rank?api_key={key}
```

### Traffic by Country

```bash
GET https://api.similarweb.com/v1/website/example.com/geo/traffic-by-country?api_key={key}&start_date=2024-01&end_date=2024-03
```

## Key Metrics

### Traffic & Engagement
- `visits` - Total visits for the period
- `pages_per_visit` - Average pages viewed per visit
- `average_visit_duration` - Average session duration in seconds
- `bounce_rate` - Percentage of single-page visits

### Traffic Sources
- `search` - Organic + paid search percentage
- `social` - Social media traffic percentage
- `direct` - Direct traffic percentage
- `referrals` - Referral traffic percentage
- `mail` - Email traffic percentage
- `display_ads` - Display advertising percentage

### Search Keywords
- `search_term` - Keyword text
- `share` - Traffic share percentage
- `volume` - Search volume
- `cpc` - Cost per click
- `position` - Average ranking position

### Geography
- `country` - Country code
- `share` - Traffic share from that country

## Parameters

### Common Parameters
- `start_date` - Start month (YYYY-MM format)
- `end_date` - End month (YYYY-MM format)
- `country` - Two-letter country code (e.g., us, gb, de)
- `granularity` - Data granularity: monthly, weekly, daily

### Search Parameters
- `limit` - Number of keywords to return
- `country` - Filter by country

## When to Use

- Analyzing competitor website traffic and engagement metrics
- Benchmarking your site against competitors
- Identifying top traffic sources for any website
- Discovering competitor organic and paid keywords
- Finding similar sites and competitive landscape
- Understanding geographic traffic distribution
- Auditing SEO performance relative to competitors
- Researching market share by traffic volume

## Rate Limits

- Rate limits vary by plan tier
- Standard: 10 requests/second
- Data availability depends on plan (3 months to 36 months historical)
- Some endpoints require Premium or Enterprise plans

## Relevant Skills

- seo-audit
- competitors
- ads
- content-strategy

## CLI referral reports

Referral reports use the endpoint-specific `v4` route. The required country
scope defaults to `world`; specify `--country us` (or another permitted country)
to select a market. Other existing CLI routes retain their version.

```bash
node tools/clis/similarweb.js referrals --domain example.com --start 2026-01 --end 2026-02 --country us
```

API keys are encoded as a single query parameter and masked by parameter name
in previews, even when their value matches part of the requested domain.
Contract: [Referrals — Desktop](https://developers.similarweb.com/reference/referrals-desktop).

## File: tools/integrations/snov.md

# Snov.io

Email finding, verification, and drip campaign platform for outreach.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for email finding, verification, prospects, drip campaigns |
| MCP | - | Not available |
| CLI | [✓](../clis/snov.js) | Zero-dependency Node.js CLI |
| SDK | - | API-only |

## Authentication

- **Type**: OAuth2 client credentials
- **Flow**: POST to `/oauth/access_token` with client_id + client_secret
- **Env vars**: `SNOV_CLIENT_ID`, `SNOV_CLIENT_SECRET`
- **Get keys**: [Snov.io > Integration > API](https://app.snov.io/integration/api)

The CLI handles token acquisition automatically.

## Common Agent Operations

### Search emails by domain

```bash
node tools/clis/snov.js domain search --domain example.com --type all --limit 10
```

### Start and retrieve a v2 domain search

The [current Domain Search API](https://snov.io/api) returns asynchronous tasks. Start one explicitly, then retrieve its result using the returned `meta.task_hash` and the same kind:

```bash
node tools/clis/snov.js domain start --kind company --domain example.com
node tools/clis/snov.js domain result --kind company --task-hash <task_hash>
node tools/clis/snov.js domain start --kind emails --domain example.com
node tools/clis/snov.js domain start --kind generic --domain example.com
node tools/clis/snov.js domain start --kind prospects --domain example.com --page 2 --positions "VP Sales,Marketing Lead"
```

`company` retrieves company information; `emails` finds domain emails; `generic` finds generic contacts; `prospects` finds prospect profiles. Results include the provider's task state and pagination metadata unchanged. An `in progress` result is not completed data: call `domain result` later. The CLI does not poll, retry or follow response links automatically.

For `emails` and `generic`, pass a nonempty `meta.next` from a completed result to another explicit `domain start --kind <kind> --domain <domain> --next <cursor>`. Each result page contains up to 50 emails. For `prospects`, choose `--page` (positive, default provider page 1) to retrieve up to 20 profiles; optional `--positions` accepts one to ten comma-separated titles. The CLI does not perform additional prospect email searches.

Snov charges credits for domain search starts according to its current plan/API rules. Inspect a dry run and avoid repeatedly starting the same search while waiting. Results are read once from fixed Snov endpoints; unverified email results still need verification before use. Legacy `domain search` and `domain count` retain their existing v1 requests and flags.

```bash
node tools/clis/snov.js domain start --kind emails --domain example.com --dry-run
```

### Find a specific person's email

```bash
node tools/clis/snov.js email find --domain example.com --first-name John --last-name Doe
```

### Verify an email

```bash
node tools/clis/snov.js email verify --email john@example.com
```

### Find prospect by email

```bash
node tools/clis/snov.js prospect find --email john@example.com
```

### Add prospect to a list

```bash
node tools/clis/snov.js prospect add --email john@example.com --first-name John --last-name Doe --list-id 12345
```

### Manage prospect lists

```bash
# List all lists
node tools/clis/snov.js lists list

# Get prospects in a list
node tools/clis/snov.js lists prospects --id 12345 --page 1 --per-page 50
```

### Check domain technology stack

```bash
node tools/clis/snov.js technology check --domain example.com
```

### Manage drip campaigns

```bash
# List campaigns
node tools/clis/snov.js drips list

# Get campaign details
node tools/clis/snov.js drips get --id 12345

# Add prospect to drip campaign
node tools/clis/snov.js drips add-prospect --id 12345 --email john@example.com
```

## Rate Limits

- Rate limits vary by plan
- OAuth tokens expire after a set period; CLI handles refresh automatically

## Use Cases

- **Link building**: Find contacts and run automated drip outreach
- **Prospecting**: Build and manage prospect lists
- **Technology research**: Check what tech stack a target domain uses
- **Email verification**: Clean lists before sending

## File: tools/integrations/sparktoro.md

# SparkToro

Audience research platform that reveals what your target audience reads, watches, listens to, follows, and searches for — using clickstream data, Google search data, and public social profiles.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | - | Not yet public (coming soon) |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | - | Not available |

SparkToro is primarily a web-based research tool. No public API, CLI, or SDK is currently available. Use the web interface at https://sparktoro.com for all queries.

## Authentication

- **Type**: Account login at https://sparktoro.com
- **Free tier**: 5 reports/month with limited results
- **Paid plans**: $50–$300/month with expanded results and exports

## Pricing Tiers

| Plan | Price | Reports/Month | Users | Result Depth |
|------|-------|---------------|-------|-------------|
| Free | $0 | 5 | 1 | Top 5–10 results |
| Personal | $50/mo | 50 | 1 | Top 50 results |
| Business | $150/mo | 500 | 10 | Top 150 results, contact data, AI advice |
| Agency | $300/mo | Unlimited | 100 | Top 300 results, full CSV export |

## What SparkToro Reveals

### Audience Behaviors
- **Websites** they visit and engage with
- **Podcasts** they listen to
- **YouTube channels** they watch
- **Subreddits** they participate in
- **Social accounts** they follow
- **Search keywords** they use on Google
- **AI prompt topics** they ask ChatGPT, Claude, Gemini

### Audience Demographics
- Gender, age ranges
- Job titles and roles
- Industries and skills
- Education levels
- Geographic distribution
- Interests and affinities

### Audience Characteristics
- Bio descriptions and self-identifiers
- Language patterns in posts and comments
- Preferred social networks and platforms
- E-commerce platforms they use

## Common Agent Operations

Since SparkToro has no API, these are the research workflows agents should guide users through.

### Audience Profile Research

Query SparkToro with phrases like:
- "People who follow @competitor" — reveals shared audience behaviors
- "People who visit competitor.com" — shows what else they consume
- "People who frequently talk about [topic]" — finds audience affinities
- "People whose bio contains [job title]" — profiles a role-based segment

### Finding Where Your ICP Spends Time

1. Search for your ICP by description, competitor followers, or website visitors
2. Extract: top websites visited, podcasts listened to, YouTube channels watched, subreddits
3. Use this to prioritize: guest podcast appearances, content partnerships, ad placements, community participation

### Discovering Content Topics

1. Search your audience segment
2. Review the "Search Keywords" tab — what they Google
3. Review the "AI Prompt Topics" tab — what they ask AI tools
4. Use these to inform content strategy and SEO keyword targeting

### Building Data-Backed Personas

1. Run 3–5 queries for different segments of your audience
2. Compare demographic breakdowns across segments
3. Note which behaviors and affinities are shared vs. unique per segment
4. Export data and build personas grounded in observed behavior, not assumptions

### Competitive Audience Analysis

1. Search "People who follow @competitor" or "People who visit competitor.com"
2. Compare against your own audience profile
3. Identify: channels they use that you don't, content they consume that you don't produce, influencers they follow that you haven't engaged

## Data Sources

SparkToro aggregates from three sources:
- **Clickstream data** — anonymized browsing behavior
- **Google search results** — search keyword patterns
- **Public social profiles** — bios, follows, engagement

## When to Use

- Identifying where your ICP spends time online (podcasts, YouTube, subreddits, websites)
- Finding influencers and social accounts your audience follows
- Discovering content topics and search keywords your audience cares about
- Building data-backed personas instead of assumption-based ones
- Planning podcast guest appearances, sponsorships, or content partnerships
- Understanding what your competitors' audience looks like
- Validating audience assumptions with behavioral data
- Discovering AI prompt topics your audience uses

## Limitations

- No public API — all research is done through the web interface
- Free tier limited to 5 reports/month with shallow results
- Data skews toward English-language, US-centric audiences
- Clickstream data may not capture all niche audiences
- Cannot track individual users — all data is aggregated and anonymized

## Relevant Skills

- customer-research
- content-strategy
- competitors
- ads
- social
- cold-email

## File: tools/integrations/strapi.md

# Strapi

Open-source headless CMS with self-hosted option, REST and GraphQL APIs, and customizable admin panel. Targets Strapi 5.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST (default), GraphQL (plugin) |
| MCP | - | No official MCP server |
| CLI | ✓ | `strapi` CLI for project setup, content types, plugins |
| SDK | ✓ | `@strapi/sdk-js`, `@strapi/blocks-react-renderer` |

## Authentication

- **Type**: API Token or Users & Permissions JWT
- **Header**: `Authorization: Bearer {api_token}`
- **Tokens**: Create in Settings → API Tokens (full access, read-only, or custom)
- **JWT**: `POST /api/auth/local` with identifier + password returns JWT

## Common Agent Operations

### List documents

```bash
GET http://localhost:1337/api/articles?populate=*

Authorization: Bearer {api_token}
```

### Get single document

```bash
GET http://localhost:1337/api/articles/{documentId}?populate=*

Authorization: Bearer {api_token}
```

### Filter and sort

```bash
# Filter by field
GET http://localhost:1337/api/articles?filters[slug][$eq]=my-post

# Multiple filters
GET http://localhost:1337/api/articles?filters[category][name][$eq]=Marketing&filters[publishedAt][$notNull]=true

# Sort
GET http://localhost:1337/api/articles?sort=publishedAt:desc

# Pagination
GET http://localhost:1337/api/articles?pagination[page]=1&pagination[pageSize]=10
```

### Create document

```bash
POST http://localhost:1337/api/articles
Content-Type: application/json
Authorization: Bearer {api_token}

{
  "data": {
    "title": "New Article",
    "slug": "new-article",
    "body": "Article content here",
    "category": "{category_documentId}"
  }
}
```

### Update document

```bash
PUT http://localhost:1337/api/articles/{documentId}
Content-Type: application/json
Authorization: Bearer {api_token}

{
  "data": {
    "title": "Updated Title"
  }
}
```

### Delete document

```bash
DELETE http://localhost:1337/api/articles/{documentId}

Authorization: Bearer {api_token}
```

### Get draft content

```bash
# Strapi 5 uses status parameter (replaces v4 publicationState)
GET http://localhost:1337/api/articles?status=draft

Authorization: Bearer {api_token}
```

Publishing and unpublishing are managed through the Strapi admin panel or Document Service API (server-side). The public REST API does not expose dedicated publish/unpublish endpoints.

### Populate relations and components

```bash
# Populate all relations
GET http://localhost:1337/api/articles?populate=*

# Populate specific relations
GET http://localhost:1337/api/articles?populate[0]=author&populate[1]=category

# Deep populate
GET http://localhost:1337/api/articles?populate[author][populate]=avatar
```

## CLI Commands

```bash
# Create new Strapi project
npx create-strapi@latest my-project

# Start development server
strapi develop

# Build admin panel
strapi build

# Generate content type
strapi generate content-type

# Generate controller
strapi generate controller

# Add GraphQL plugin
npm install @strapi/plugin-graphql
```

## Key Objects

- **Content Type** — Schema definition (collection type or single type)
- **Document** — Content item identified by `documentId` (Strapi 5 pattern)
- **Component** — Reusable field group (e.g., SEO fields, CTA block)
- **Dynamic Zone** — Flexible content area accepting multiple component types
- **Media** — Files managed through the Media Library
- **Locale** — i18n locale for content translation (plugin-based)

## When to Use

- Self-hosted CMS with full data ownership
- Budget-conscious projects (no per-seat pricing)
- Custom admin panel or plugin requirements
- Teams with DevOps capability
- Projects needing both REST and GraphQL access

## Rate Limits

- Self-hosted: No built-in rate limits (configure via middleware or reverse proxy)
- Strapi Cloud: Varies by plan
- Recommended: Add rate limiting middleware for production APIs

## Relevant Skills

- content-strategy (CMS selection, content modeling)
- programmatic-seo (CMS as data source for generated pages)
- site-architecture (URL structure from CMS slugs)

## File: tools/integrations/stripe.md

# Stripe

Payment processing, subscriptions, and billing for internet businesses.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Comprehensive REST API |
| MCP | ✓ | Available via Stripe MCP server |
| CLI | ✓ | `stripe` CLI for testing and webhooks |
| SDK | ✓ | Official SDKs for most languages |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer sk_live_xxx` or `sk_test_xxx`
- **Keys**: Secret key (server), Publishable key (client)

## Common Agent Operations

### List customers

```bash
GET https://api.stripe.com/v1/customers?limit=10
```

### Get customer by email

```bash
GET https://api.stripe.com/v1/customers?email=user@example.com
```

### Get subscription

```bash
GET https://api.stripe.com/v1/subscriptions/{subscription_id}
```

### List subscriptions for customer

```bash
GET https://api.stripe.com/v1/subscriptions?customer={customer_id}
```

### Create checkout session

```bash
POST https://api.stripe.com/v1/checkout/sessions

customer={customer_id}
&line_items[0][price]={price_id}
&line_items[0][quantity]=1
&mode=subscription
&success_url=https://example.com/success
&cancel_url=https://example.com/cancel
```

### Create customer portal session

```bash
POST https://api.stripe.com/v1/billing_portal/sessions

customer={customer_id}
&return_url=https://example.com/account
```

### List recent invoices

```bash
GET https://api.stripe.com/v1/invoices?customer={customer_id}&limit=10
```

### Get payment intent

```bash
GET https://api.stripe.com/v1/payment_intents/{payment_intent_id}
```

## Webhook Events

Key events to handle:

| Event | When | Action |
|-------|------|--------|
| `checkout.session.completed` | Successful checkout | Provision access |
| `customer.subscription.created` | New subscription | Update user record |
| `customer.subscription.updated` | Plan change | Update entitlements |
| `customer.subscription.deleted` | Cancellation | Revoke access |
| `invoice.payment_failed` | Payment failed | Notify user, retry |
| `invoice.paid` | Invoice paid | Confirm payment |

### Verify webhook signature

```javascript
const event = stripe.webhooks.constructEvent(
  payload,
  sig,
  webhookSecret
);
```

## CLI Commands

```bash
# Listen to webhooks locally
stripe listen --forward-to localhost:3000/webhooks

# Trigger test events
stripe trigger checkout.session.completed

# List recent events
stripe events list --limit 10

# Get resource
stripe customers retrieve cus_xxx
```

## Key Objects

- **Customer** - User billing profile
- **Subscription** - Recurring billing
- **Price** - Pricing configuration
- **Product** - What you sell
- **Invoice** - Billing document
- **PaymentIntent** - One-time payment
- **Checkout Session** - Hosted payment page

## When to Use

- Processing payments
- Managing subscriptions
- Creating checkout flows
- Handling billing portal
- Querying customer data
- Revenue analytics

## Rate Limits

- 100 read requests per second
- 100 write requests per second
- Higher limits available on request

## Relevant Skills

- pricing
- referrals (Stripe-integrated affiliate tools)
- analytics (revenue tracking)

## File: tools/integrations/supermetrics.md

# Supermetrics

Marketing data pipeline that connects 200+ marketing platforms. Pulls data from ad platforms, analytics, social, SEO, email, and more into a single query interface.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Query any connected data source, manage accounts |
| MCP | ✓ | [Claude connector](https://claude.com/connectors/supermetrics) |
| CLI | ✓ | [supermetrics.js](../clis/supermetrics.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: API Key
- **Query param**: `api_key={api_key}` or **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Supermetrics Hub > API settings at https://hub.supermetrics.com

## Common Agent Operations

### Query a Data Source

```bash
POST https://api.supermetrics.com/query/data/json

{
  "ds_id": "GA4",
  "ds_accounts": "123456789",
  "date_range_type": "custom",
  "start_date": "-28 days",
  "end_date": "yesterday",
  "fields": [
    { "id": "sessions" },
    { "id": "pageviews" },
    { "id": "date" }
  ]
}
```

### Query with Filters

```bash
POST https://api.supermetrics.com/query/data/json

{
  "ds_id": "AW",
  "ds_accounts": "123-456-7890",
  "date_range_type": "last_month",
  "fields": [
    { "id": "campaign_name" },
    { "id": "clicks" },
    { "id": "impressions" },
    { "id": "cost" }
  ],
  "max_rows": 100
}
```

### List Available Data Sources

```bash
GET https://api.supermetrics.com/datasource/search
```

### List Connected Accounts

```bash
GET https://api.supermetrics.com/query/accounts?ds_id=GA4
```

### Get a Team

```bash
GET https://api.supermetrics.com/v1/teams/{team_id}
```

### List Users

```bash
GET https://api.supermetrics.com/v1/teams/{team_id}/users
```

## Key Metrics

### Data Source IDs
- `GA4` - Google Analytics 4
- `GA4_PAID` - Google Analytics (paid)
- `AW` - Google Ads
- `FB` - Facebook Ads
- `LI` - LinkedIn Ads
- `TW_ADS` - Twitter Ads
- `IG_IA` - Instagram
- `FB_IA` - Facebook Pages
- `GSC` - Google Search Console
- `SE` - Semrush
- `MC` - Mailchimp
- `HubSpot` - HubSpot

### Date Range Values
- `last_28_days` - CLI shorthand for a custom range from `-28 days` through `yesterday`
- `last_month` - Previous calendar month
- `this_month` - Current month to date
- `custom` - Custom range (requires `start_date` and `end_date`)

## Parameters

### Query
- `ds_id` - Data source identifier (required)
- `ds_accounts` - Account ID for the data source (required)
- `date_range_type` - Date range preset or "custom" (required)
- `fields` - Array of field objects with required `id` property (required)
- `filter` - Filter expression for narrowing results
- `max_rows` - Maximum number of rows to return
- `start_date` - Start date for custom range (YYYY-MM-DD)
- `end_date` - End date for custom range (YYYY-MM-DD)

### Common Fields by Source
- **GA4**: `sessions`, `pageviews`, `users`, `bounce_rate`, `date`, `source`, `medium`, `page_path`
- **Google Ads**: `campaign_name`, `clicks`, `impressions`, `cost`, `conversions`, `ctr`, `cpc`
- **Facebook Ads**: `campaign_name`, `impressions`, `clicks`, `spend`, `reach`, `cpm`, `cpc`
- **LinkedIn Ads**: `campaign_name`, `impressions`, `clicks`, `cost`, `conversions`
- **GSC**: `query`, `clicks`, `impressions`, `ctr`, `position`, `page`

## When to Use

- Pulling cross-platform marketing data into a single report
- Comparing performance across ad platforms (Google, Meta, LinkedIn, TikTok)
- Aggregating analytics data from multiple sources
- Automating marketing reporting workflows
- Building unified dashboards across marketing channels
- Extracting SEO data alongside paid media metrics

## Rate Limits

- Rate limits vary by plan
- Enterprise API: typically 100 requests/minute
- Query results may be paginated for large datasets
- Recommended: use `max_rows` to control response size

## Relevant Skills

- analytics
- ads
- seo-audit
- content-strategy
- social

## CLI Contract Notes

- `teams get --team-id <id>` retrieves one team; `users list --team-id <id>` lists that team's users. These require a key with the corresponding management permissions. The former unscoped `teams list` has no documented public equivalent and now returns migration guidance.
- Query custom ranges require both `--start-date` and `--end-date`. Field names passed to `--fields` are provider field IDs, not display-name overrides. Empty IDs are rejected before a request.
- HTTP failures exit unsuccessfully; `--dry-run` masks the Bearer credential without sending any request.

Primary contracts: [authentication](https://docs.supermetrics.com/apidocs/authentication), [fields](https://docs.supermetrics.com/apidocs/fields), [relative dates](https://docs.supermetrics.com/apidocs/date-strings), [query data](https://docs.supermetrics.com/apidocs/query-data-3), [source search](https://docs.supermetrics.com/apidocs/search-data-sources), [accounts](https://docs.supermetrics.com/apidocs/get-accounts), [team lookup](https://docs.supermetrics.com/apidocs/get-team-details-by-team-id), and [team users](https://docs.supermetrics.com/apidocs/list-all-users-in-a-team).

## File: tools/integrations/theirstack.md

# TheirStack

Job postings and technographics data. Finds companies by what they're hiring for and what technology they use, inferred from job postings across many job boards, with webhooks for new postings. Useful for hiring signals ("hiring a lifecycle marketer") and tech-stack targeting ("uses HubSpot and Webflow").

Facts below were checked against [theirstack.com/en/docs](https://theirstack.com/en/docs/api-reference), its [OpenAPI spec](https://api.theirstack.com/openapi.json), and the [MCP docs](https://theirstack.com/en/docs/mcp) on 2026-10-07.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Job search, company search, technographics, webhooks, credit balance |
| MCP | ✓ | Official hosted server at `https://api.theirstack.com/mcp`. OAuth by default, or an API key in the `Authorization` header |
| CLI | - | Use the API |
| SDK | - | Datasets also available as Parquet or CSV |

## Authentication

- **Type**: Bearer token, `Authorization: Bearer <key>`
- **Env var** (convention): `THEIRSTACK_API_KEY`
- **Get key**: [app.theirstack.com → API Keys](https://app.theirstack.com/settings/api-key)
- **MCP**: use OAuth for interactive sessions, or pass the API key as a header so scheduled agent runs work without a browser:

```bash
claude mcp add TheirStack --transport http https://api.theirstack.com/mcp \
  --header "Authorization: Bearer $THEIRSTACK_API_KEY"
```

## Common Agent Operations

Base URL: `https://api.theirstack.com`

### Companies hiring for a role (hiring signal)

```bash
POST https://api.theirstack.com/v1/jobs/search
Authorization: Bearer $THEIRSTACK_API_KEY

{
  "job_title_or": ["growth marketing", "lifecycle marketing", "CRO"],
  "posted_at_max_age_days": 30,
  "job_country_code_or": ["US"],
  "min_employee_count": 20,
  "max_employee_count": 500,
  "limit": 25
}
```

Use `company_technology_slug_or` / `_and` / `_not` to add a tech-stack filter, and `company_domain_or` to check a named account list.

### Companies by technology

```bash
POST /v1/companies/search        # companies matching technology, firmographic, and hiring filters
POST /v1/companies/technologies  # one company's full inferred tech stack
```

### Webhooks (alerts instead of polling)

`POST /v0/webhooks` on a saved search sends `job.new`, `job.closed`, or `company.new` events when matches appear, for example when a target account posts a relevant role or adopts a technology.

### Credits

`GET /v0/billing/credit-balance`

## Credits

API credits are charged per record returned (or sent by webhook):
- 1 credit per job
- 3 credits per company from company search
- 3 credits per company for its full technographics

Keep `limit` small while testing, and use the count feature before large pulls. App "company credits" for revealing companies in the UI are separate. Source: [credits docs](https://theirstack.com/en/docs/pricing/credits); plans at [theirstack.com/en/pricing](https://theirstack.com/en/pricing).

## Rate Limits

- Paid: 4 requests per second across job search, company search, and technographics
- Free: 4 per second, 10 per minute, 50 per hour, 400 per day
- Responses include IETF `RateLimit` headers. Source: [rate limit docs](https://theirstack.com/en/docs/api-reference/rate-limit)

## Signal Ideas

- **Agency (CRO, landing pages)**: companies hiring a growth, CRO, or demand gen marketer in the last 30 days; companies adopting a new site builder or A/B testing tool
- **Email tooling**: companies hiring lifecycle, email, or RevOps roles; companies whose postings mention a cold email or sales engagement stack
- **Competitor customers**: companies whose postings mention a competitor's product
- Treat tech stack inferred from job postings as a signal, not proof. Small companies post few jobs, so coverage is thinner at the low end.

## Relevant Skills

- prospecting
- cold-email
- competitor-profiling
- marketing-loops (signal sweep loops)

## File: tools/integrations/tiktok-ads.md

# TikTok Ads

Advertising platform for TikTok's short-form video audience.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Marketing API for campaigns, audiences, reporting |
| MCP | - | Not available |
| CLI | - | Not available |
| SDK | ✓ | Python SDK available |

## Authentication

- **Type**: Access Token
- **Header**: `Access-Token: {access_token}`
- **Setup**: Create app in TikTok for Business, get access token

## Common Agent Operations

### Get advertiser info

```bash
GET https://business-api.tiktok.com/open_api/v1.3/advertiser/info/?advertiser_ids=["{advertiser_id}"]

Access-Token: {access_token}
```

### Get campaigns

```bash
GET https://business-api.tiktok.com/open_api/v1.3/campaign/get/?advertiser_id={advertiser_id}&page=1&page_size=20

Access-Token: {access_token}
```

### Get campaign report

```bash
GET https://business-api.tiktok.com/open_api/v1.3/report/integrated/get/?advertiser_id={advertiser_id}&report_type=BASIC&dimensions=["campaign_id"]&metrics=["spend","impressions","clicks","conversion"]&data_level=AUCTION_CAMPAIGN&start_date=2024-01-01&end_date=2024-01-31

Access-Token: {access_token}
```

Send report parameters in the query string. JSON-encode array values such as
`dimensions` and `metrics`, then URL-encode the query values (the example shows
decoded values for readability).

### Create campaign

```bash
POST https://business-api.tiktok.com/open_api/v1.3/campaign/create/

Access-Token: {access_token}

{
  "advertiser_id": "{advertiser_id}",
  "campaign_name": "Campaign Name",
  "objective_type": "CONVERSIONS",
  "budget_mode": "BUDGET_MODE_DAY",
  "budget": 100
}
```

### Update campaign status

```bash
POST https://business-api.tiktok.com/open_api/v1.3/campaign/status/update/

Access-Token: {access_token}

{
  "advertiser_id": "{advertiser_id}",
  "campaign_ids": ["{campaign_id}"],
  "opt_status": "ENABLE"
}
```

### Get ad groups

```bash
GET https://business-api.tiktok.com/open_api/v1.3/adgroup/get/?advertiser_id={advertiser_id}&filtering={"campaign_ids":["{campaign_id}"]}

Access-Token: {access_token}
```

Campaign IDs belong inside the JSON-encoded `filtering` query parameter.
URL-encode that value before sending the request.

### Get audiences

```bash
GET https://business-api.tiktok.com/open_api/v1.3/dmp/custom_audience/list/?advertiser_id={advertiser_id}

Access-Token: {access_token}
```

## Key Metrics

| Metric | Description |
|--------|-------------|
| `spend` | Amount spent |
| `impressions` | Ad impressions |
| `clicks` | Clicks |
| `ctr` | Click-through rate |
| `cpc` | Cost per click |
| `cpm` | Cost per 1000 impressions |
| `conversion` | Conversions |
| `cost_per_conversion` | CPA |
| `video_play_actions` | Video views |
| `video_watched_6s` | 6s views |

## Campaign Objectives

- `REACH` - Brand awareness
- `TRAFFIC` - Website traffic
- `VIDEO_VIEWS` - Video views
- `LEAD_GENERATION` - Lead forms
- `CONVERSIONS` - Website conversions
- `APP_PROMOTION` - App installs

## Targeting Options

### Demographics
- Age ranges
- Gender
- Languages
- Locations

### Interests & Behavior
- Interest categories
- Video interactions
- Creator interactions
- Hashtag interactions

### Custom Audiences
- Customer file uploads
- Website visitors (pixel)
- App activity
- Engagement audiences

## When to Use

- Reaching younger demographics (18-34)
- Video-first advertising
- Viral/creative campaigns
- App promotion

## Rate Limits

- 10 requests/second
- 100,000 requests/day

## Relevant Skills

- ads
- analytics

## File: tools/integrations/tolt.md

# Tolt

Affiliate program management for SaaS, with Stripe and Paddle integration.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for partners, customers, commissions |
| MCP | - | Not available |
| CLI | ✓ | [tolt.js](../clis/tolt.js) |
| SDK | - | JavaScript snippet for tracking |

## Authentication

- **Type**: API Key
- **Header**: `Authorization: Bearer {api_key}`
- **Get key**: Settings > API in Tolt dashboard

## Current Public API

The API base is `https://api.tolt.com/v1`, with `partners`, `customers`, and
`commissions` resources. The CLI keeps `affiliates` as an alias for `partners`
and `referrals` as an alias for `customers`.

### List partners, customers, or commissions

```bash
node tools/clis/tolt.js partners list --program-id prg_example
node tools/clis/tolt.js customers list --program-id prg_example --partner-id part_example
node tools/clis/tolt.js commissions list --program-id prg_example --partner-id part_example
```

These list operations require `program_id`. `--affiliate-id` remains an alias
for the `--partner-id` filter. Use `--limit`, `--starting-after`, or
`--ending-before` to page through results. Cursors are the returned record IDs.

### Create or update a partner

```bash
node tools/clis/tolt.js partners create --program-id prg_example --email jane@example.com --first-name Jane --last-name Doe
node tools/clis/tolt.js partners update --id part_example --payout-method paypal --paypal-email jane@example.com
```

Creation requires email, first name, last name, and program ID. Update uses
`PUT /partners/{id}` and puts the payout email inside `payout_details`.
Use explicit first/last names instead of the old ambiguous `--name` input.

### Retrieve a record

```bash
node tools/clis/tolt.js partners get part_example
node tools/clis/tolt.js customers get --id cust_example
```

Customer retrieval uses the Tolt customer record ID, not an external billing
customer ID. The old `--customer-id` lookup returns a migration error rather
than silently treating a Stripe/customer reference as a Tolt record ID.

### Migration limits

The current public reference does not document payout-history retrieval or
`commission_rate` as a partner update field. Those old commands/options return
an actionable error directing users to the dashboard rather than issuing an
undocumented request. `--dry-run` previews the request without sending it.

Primary contracts: [partners list](https://docs.tolt.com/partners/list),
[create](https://docs.tolt.com/partners/create), [update](https://docs.tolt.com/partners/update),
[customers list](https://docs.tolt.com/customers/list),
[retrieve](https://docs.tolt.com/customers/retrieve), and
[commissions list](https://docs.tolt.com/commissions/list).

## JavaScript Tracking

### Install snippet

```html
<script src="https://cdn.tolt.io/tolt.js" data-tolt="YOUR_PUBLIC_KEY"></script>
```

### Track signup

```javascript
window.tolt.signup(stripeCustomerId);
```

### Identify existing customer

```javascript
window.tolt.identify(stripeCustomerId);
```

## Webhook Events

| Event | When |
|-------|------|
| `affiliate.created` | New affiliate registered |
| `affiliate.approved` | Affiliate approved |
| `referral.created` | New referral tracked |
| `referral.converted` | Referral converted to customer |
| `commission.created` | Commission earned |
| `payout.completed` | Payout sent |

## Key Features

- **Stripe native** - Automatic commission tracking
- **Paddle support** - Works with Paddle billing
- **Affiliate dashboard** - White-labeled portal
- **Payout automation** - PayPal and Wise payouts
- **Custom commission tiers** - Different rates per affiliate

## Key Objects

- **Affiliate** - Partner in your program
- **Referral** - Tracked conversion
- **Commission** - Earned affiliate payment
- **Payout** - Processed payment to affiliate
- **Program** - Campaign configuration

## When to Use

- Setting up SaaS affiliate programs
- Managing affiliate relationships
- Tracking Stripe or Paddle-based referrals
- Processing affiliate payouts
- Building affiliate dashboards

## Rate Limits

- 100 requests per minute
- Higher limits on enterprise plans

## Relevant Skills

- referrals
- pricing

## File: tools/integrations/truelist.md

# Truelist

Email verification and list hygiene. Verifies single addresses synchronously and lists asynchronously as batches, resolves catch-all (accept-all) domains with its Enhanced strategy, and returns an `email_state` plus a more specific `email_sub_state` for each address. Truelist also sells **Outbound**, sending infrastructure for cold email (see below).

API facts below were checked against Truelist's live spec ([truelist.io/spec.yaml](https://truelist.io/spec.yaml), v0.2.2; reference at [truelist.io/docs/api](https://truelist.io/docs/api)) and [MCP docs](https://truelist.io/docs/sdks/mcp) on 2026-10-07. The older [GitHub OpenAPI repo](https://github.com/Truelist-Labs/truelist-openapi) lags the live spec.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API: inline verification, batches, results, account |
| MCP | ✓ | Official hosted server at `https://api.truelist.io/mcp` (OAuth sign-in, 7 tools). A self-hostable [truelist-mcp](https://github.com/Truelist-Labs/truelist-mcp) repo also exists |
| CLI | [✓](../clis/truelist.js) | Zero-dependency Node.js CLI in this repo; Truelist also publishes a Go [truelist-cli](https://github.com/Truelist-Labs/truelist-cli) |
| SDK | ✓ | Official: Node/TypeScript, Python, Ruby, PHP, Go, Java, .NET; plus WordPress and n8n |

## Authentication

- **API and CLI**: Bearer token, `Authorization: Bearer <key>`. Env var `TRUELIST_API_KEY`. Create a key in account settings.
- **MCP**: no API key. The client opens a browser to sign in to Truelist once, and stays authorized until you revoke it. Because sign-in is per user, the hosted MCP suits interactive sessions; scheduled jobs should use the API key with the CLI or API.
- **Base URL**: `https://api.truelist.io`

```bash
# Claude Code
claude mcp add --transport http truelist https://api.truelist.io/mcp
```

## Common Agent Operations

### Verify one or a few addresses (synchronous)

```bash
node tools/clis/truelist.js verify --email jane@acme.com
node tools/clis/truelist.js verify --email "jane@acme.com,bo@beta.io" --strategy enhanced
```

Underlying call: `POST /api/v1/verify_inline?email=<space-separated addresses>&validation_strategy=<strategy>`.

| Strategy | Use when |
|----------|----------|
| `accurate` (default) | Normal verification with retries |
| `fast` | Speed matters more than certainty; skips retry logic |
| `thorough` | Greylisting servers; waits longer (5-minute retry delay) |
| `enhanced` | Catch-all domains; adds post-validation checks to resolve accept-all results. Uses enhanced credits |

The inline endpoint also takes a `checks` parameter (`syntax`, `mx`, `disposable`, `role`, `smtp`) for sub-200ms signup-form checks that skip SMTP; see the API reference.

### Verify a list (asynchronous batch)

```bash
# CSV/text with the email in the first column, or a JSON array of emails (2+ addresses)
node tools/clis/truelist.js batch create --file prospects.csv --name "Q4 SaaS list" --webhook-url https://example.com/truelist-done

# Poll status (batch_state: pending → processing → completed)
node tools/clis/truelist.js batch get --id <batch-uuid>

# Pull results by state once completed (paginated, max 100 per page)
node tools/clis/truelist.js results --batch-id <batch-uuid> --state ok --per-page 100
node tools/clis/truelist.js results --batch-id <batch-uuid> --state invalid

node tools/clis/truelist.js batch list
```

A completed batch includes four CSV download URLs: `safest_bet_csv_url` (only addresses safe to send), `highest_reach_csv_url` (adds accept-all/catch-all addresses), `only_invalid_csv_url`, and `annotated_csv_url` (your original rows plus result columns). Counts aren't updated until the batch completes. Supply `--webhook-url` to get a POST with the batch ID on completion instead of polling.

### Account

```bash
node tools/clis/truelist.js account
```

## Result States

`email_state` (overall verdict):

| State | Meaning | Outbound action |
|-------|---------|-----------------|
| `ok` | Deliverable | Send |
| `email_invalid` | Not deliverable | Remove; it would bounce |
| `accept_all` | Catch-all domain; the mailbox can't be confirmed | Resolve with the `enhanced` strategy first. If still unresolved, send only for high-value accounts, from separate lower-volume inboxes |
| `risky` | May deliver but carries risk (role, disposable, and similar) | Exclude from cold outreach by default |
| `unknown` | Couldn't be determined (timeouts, greylisting) | Re-verify with `thorough`; don't send until resolved |

`email_sub_state` (reason): `email_ok`, `accept_all`, `is_disposable`, `is_role`, `failed_mx_check`, `failed_smtp_check`, `failed_spam_trap`, `failed_no_mailbox`, `failed_greylisted`, `failed_syntax_check`, `unknown_error`.

Read the two together. `ok` + `is_role` is deliverable but a shared inbox (info@, sales@), which cold outreach should skip. `email_invalid` + `failed_no_mailbox` means the address doesn't exist. Any `failed_spam_trap` result should be removed and the source of that list questioned.

Results filtering (`results --state`) accepts `ok`, `risky`, `invalid`, and `unknown`.

## MCP Tools

| Tool | Does | Credits |
|------|------|---------|
| `check_account` | Account, plan, and connected user | No |
| `validate_email` | One address, full validation chain | 1 (recent cached results free) |
| `validate_emails` | Up to 50 addresses; returns partial results with `stopped_reason` if a limit trips | 1 per email |
| `create_batch` | Batch of up to 10,000 addresses | 1 per email (cache hits free) |
| `list_batches` | Batches with progress counters | No |
| `get_batch` | One batch, with the four CSV download URLs when complete | No |
| `list_email_addresses` | Past results filtered by batch or state | No |

## Rate Limits

- 10 API requests per second per endpoint; `429` when exceeded. The email validation rate is separate and depends on plan.
- Source: [API reference](https://truelist.io/docs/api)

## Truelist Outbound (sending infrastructure)

Separate from verification, [Truelist Outbound](https://truelist.io/docs/outbound/overview) provides cold email sending infrastructure that you connect to a sequencer (Instantly, Smartlead, lemlist, or anything that sends over SMTP):
- Domains registered in your name, with SPF, DKIM, and DMARC configured automatically
- Mailboxes with SMTP/IMAP credentials for your sequencer, on a sending IP reserved for your account
- A 21-day sending ramp (10 → 20 → 30 → 40 sends a day per mailbox) enforced on Truelist's mail server, regardless of what the sequencer tries to send. There is no warmup network.
- Every recipient verified at send time; invalid or unverifiable recipients are rejected
- Server-enforced suppressions for hard bounces and complaints, and recurring blocklist monitoring

It doesn't run campaigns or write copy; the sequencer still does that. Compare it with general inbox providers in the `cold-email` skill's deliverability guidance.

## When to Use

- **Before any cold outreach**: verify every list before it reaches a sequencer, and re-verify anything older than 30–60 days before sending. Keep hard bounces under 2% (under 1% is the target).
- **Catch-all heavy lists** (B2B domains often accept all mail): use the `enhanced` strategy rather than dropping or blindly sending to accept-all results.
- **Signup and form validation**: inline verification with fast checks.
- **Recurring list hygiene** for CRM and ESP lists, via native integrations or scheduled batches.

## Native Integrations

Email platforms (Mailchimp, Klaviyo, HubSpot, ActiveCampaign, Brevo, Constant Contact, Kit, Drip), automation (Zapier, Make, n8n), CRM and sales (Salesforce, Go High Level, Clay), and ecommerce (BigCommerce, Shopify). Current list: [truelist.io/integrations](https://truelist.io/integrations).

## Relevant Skills

- prospecting (verify before anything enters an outreach list)
- cold-email (deliverability and list hygiene for sending)
- emails (subscriber list hygiene)
- popups (real-time form validation)

## File: tools/integrations/trustpilot.md

# Trustpilot

Business review management platform for collecting, managing, and showcasing customer reviews.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Business Units, Reviews, Invitations, Tags |
| MCP | - | Not available |
| CLI | ✓ | [trustpilot.js](../clis/trustpilot.js) |
| SDK | ✓ | Node.js (official), community wrappers |

## Authentication

- **Type**: API Key (public endpoints) + OAuth 2.0 (private endpoints)
- **Public Header**: `apikey: {YOUR_API_KEY}`
- **Private Header**: `Authorization: Bearer {access_token}`
- **OAuth Grant**: Client Credentials (`Basic base64(API_KEY:API_SECRET)`)
- **Token Lifetime**: Access tokens expire after 100 hours, refresh tokens after 30 days
- **Get credentials**: https://businessapp.b2b.trustpilot.com/ > Integrations > API

## Common Agent Operations

### Search for a business unit

```bash
GET https://api.trustpilot.com/v1/business-units/search?query=example.com&limit=10

Headers:
  apikey: {API_KEY}
```

### Get business unit details

```bash
GET https://api.trustpilot.com/v1/business-units/{businessUnitId}

Headers:
  apikey: {API_KEY}
```

### Get business profile info

```bash
GET https://api.trustpilot.com/v1/business-units/{businessUnitId}/profileinfo

Headers:
  apikey: {API_KEY}
```

### List public reviews

```bash
GET https://api.trustpilot.com/v1/business-units/{businessUnitId}/reviews?perPage=20&orderBy=createdat.desc

Headers:
  apikey: {API_KEY}
```

### List private reviews (with customer data)

```bash
GET https://api.trustpilot.com/v1/private/business-units/{businessUnitId}/reviews?perPage=20

Headers:
  Authorization: Bearer {access_token}
```

### Reply to a review

```bash
POST https://api.trustpilot.com/v1/private/reviews/{reviewId}/reply

Headers:
  Authorization: Bearer {access_token}

{
  "message": "Thank you for your feedback!"
}
```

### Send email invitation

```bash
POST https://invitations-api.trustpilot.com/v1/private/business-units/{businessUnitId}/email-invitations

Headers:
  Authorization: Bearer {access_token}

{
  "consumerEmail": "customer@example.com",
  "consumerName": "Jane Doe",
  "referenceNumber": "order-123",
  "senderEmail": "sender@example.com",
  "senderName": "Team",
  "replyTo": "reply@example.com",
  "type": "email",
  "serviceReviewInvitation": {
    "templateId": "<template_id>",
    "redirectUri": "https://example.com/thanks"
  }
}
```

### Generate review invitation link

```bash
POST https://invitations-api.trustpilot.com/v1/private/business-units/{businessUnitId}/invitation-links

Headers:
  Authorization: Bearer {access_token}

{
  "email": "customer@example.com",
  "name": "Jane Doe",
  "referenceId": "order-123",
  "redirectUri": "https://example.com/thanks"
}
```

### List invitation templates

```bash
GET https://invitations-api.trustpilot.com/v1/private/business-units/{businessUnitId}/templates

Headers:
  Authorization: Bearer {access_token}
```

### Add tags to a review

```bash
PUT https://api.trustpilot.com/v1/private/reviews/{reviewId}/tags

Headers:
  Authorization: Bearer {access_token}

{
  "tags": [{ "group": "sentiment", "value": "positive" }]
}
```

## Key Metrics

### Business Unit Metrics
- `numberOfReviews` - Total review count
- `trustScore` - Overall trust score (1-5)
- `stars` - Star rating displayed
- `status` - Claim status (claimed, unclaimed)

### Review Metrics
- `stars` - Individual review star rating (1-5)
- `language` - Review language code
- `createdAt` - Review creation timestamp
- `isVerified` - Whether the review is verified
- `status` - Review status (active, reported, flagged)

## Parameters

### Review Filters
- `stars` - Filter by star rating (1-5)
- `language` - Filter by language code (e.g., `en`)
- `orderBy` - Sort order (`createdat.desc`, `createdat.asc`, `stars.desc`, `stars.asc`)
- `perPage` - Results per page (max 100)

### Invitation Parameters
- `consumerEmail` - Recipient email (required)
- `consumerName` - Recipient name (required)
- `referenceNumber` - Order or transaction reference
- `templateId` - Email template ID
- `redirectUri` - URL to redirect after review submission
- `senderEmail` - Custom sender email
- `replyTo` - Custom reply-to address

## When to Use

- Collecting and managing customer reviews at scale
- Automating post-purchase review invitation flows
- Monitoring brand reputation and review sentiment
- Responding to customer feedback programmatically
- Showcasing TrustScore and reviews on marketing pages
- Tagging and categorizing reviews for analysis

## Rate Limits

- Recommended: no more than 833 calls per 5 minutes (10K/hour)
- Throttled at more than 1 request per second
- Rate limit headers returned in responses
- Use webhooks instead of polling where possible

## Relevant Skills

- reputation-management
- customer-feedback
- review-generation
- social-proof
- post-purchase-flow

## CLI invitation requests

Invitation creation, links, and templates use `invitations-api.trustpilot.com`;
OAuth and review operations retain `api.trustpilot.com`. Email invitations put
`templateId` and `redirectUri` inside `serviceReviewInvitation`, rather than at
the top level. Links retain their separate `email`/`name`/`referenceId` payload.

Supply `--business-user-id` for the `x-business-user-id` header when using the
CLI's client credentials grant on behalf of an Admin or Manager. Use
`--sender-name`, `--sender-email`, and `--reply-to` for email sender fields.
No real invitation is sent by `--dry-run`.

Contract: [Trustpilot Invitation API](https://developers.trustpilot.com/invitation-api).

## File: tools/integrations/twilio.md

# Twilio

Programmable communications platform: SMS, MMS, WhatsApp, voice, email (via SendGrid). The default low-level API for custom SMS builds, transactional messaging, and B2B SaaS embedding SMS into products.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API, well-documented, mature |
| MCP | - | Not available natively (community wrappers exist) |
| CLI | ✓ | Official `twilio` CLI |
| SDK | ✓ | Node, Python, Ruby, PHP, Java, Go, C#, .NET |

## Authentication

- **Type**: Basic auth with Account SID + Auth Token (or API Key SID + Secret)
- **Header**: `Authorization: Basic base64(AccountSID:AuthToken)`
- **Get credentials**: https://console.twilio.com → Account Info
- **Recommendation**: Use API Keys (revocable, scoped) for production rather than the master Auth Token

## Common Agent Operations

### Send SMS

```bash
POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json

To=+15551234567
From=+15559876543
Body=Hello from Twilio
```

### Send MMS

```bash
POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json

To=+15551234567
From=+15559876543
Body=Check this out
MediaUrl=https://example.com/image.jpg
```

### List messages

```bash
GET https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json?PageSize=50
```

### Get message status

```bash
GET https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages/{MessageSid}.json
```

Status values: `queued`, `sending`, `sent`, `delivered`, `undelivered`, `failed`.

### List phone numbers

```bash
GET https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/IncomingPhoneNumbers.json
```

### Buy a phone number

```bash
POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/IncomingPhoneNumbers.json

PhoneNumber=+15559876543
```

### Configure webhook for inbound messages

```bash
POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/IncomingPhoneNumbers/{Sid}.json

SmsUrl=https://your-app.com/sms-webhook
SmsMethod=POST
```

Inbound SMS POSTs to the webhook with: `From`, `To`, `Body`, `MessageSid`, `NumMedia`, etc.

### A2P 10DLC registration (US)

```bash
# Create brand
POST https://messaging.twilio.com/v1/a2p/BrandRegistrations

CustomerProfileBundleSid=...
A2PProfileBundleSid=...

# Create campaign
POST https://messaging.twilio.com/v1/Services/{ServiceSid}/Compliance/Usa2p

BrandRegistrationSid=...
Description=...
MessageSamples[]=Sample text 1
MessageFlow=Opt-in flow description
UseCase=MARKETING
```

Most workflows are clearer in the Console UI. Programmatic registration is for high-scale platforms managing many brands.

## API Pattern

REST + form-encoded request bodies (not JSON for most endpoints). Resources nested under Account: `/Accounts/{AccountSid}/...`. Pagination via `Page`, `PageSize`, `NextPageUri`.

## Key Concepts

- **Messaging Service**: virtual sender container; load-balances across multiple numbers, handles A2P registration grouping
- **Sticky Sender**: same recipient always receives from the same number within a service
- **Geo-Match**: route to a number matching the recipient's country/region
- **Status Callback**: webhook fired on every delivery state change
- **Carrier Lookup**: pre-send check for line type (mobile, landline, VoIP) — costs ~$0.005

## Pricing

- US 10DLC SMS: $0.0079/msg
- US toll-free SMS: $0.0079/msg
- US short code SMS: $0.0079/msg + $1,000/mo lease
- MMS: ~$0.02
- Carrier surcharges (~$0.005 US 10DLC)
- A2P 10DLC: ~$15 brand + $10/mo per campaign
- Phone number rental: $1.15/mo (10DLC) to $2/mo (toll-free)

## Rate Limits

- Default: 1 msg/sec on long codes (10DLC trust score raises this to 4–100+)
- Short code: 100+ msg/sec
- Messaging Services throttle automatically
- Carrier filtering applies above contracted throughput

## When to Use

- Building custom SMS flows into a product (B2B SaaS, mobile apps)
- Transactional and auth SMS (OTPs, alerts, notifications)
- Multi-channel orchestration (SMS + voice + WhatsApp)
- High-volume programmable messaging
- When you need full control and minimal abstraction
- Backing store for Customer.io / Segment / other orchestration layers

## When NOT to Use

- DTC ecom marketing flows — use Klaviyo, Postscript, or Attentive (better tooling for cart recovery, segments, A/B tests)
- If you don't want to handle compliance plumbing — Twilio gives you primitives, not policy
- Marketing UI for non-technical users — there isn't one

## Relevant Skills

- sms
- emails (transactional sister product via SendGrid)
- onboarding (post-signup SMS milestones)

## File: tools/integrations/typeform.md

# Typeform

Forms and surveys platform API for creating typeforms, retrieving responses, managing webhooks, themes, images, and workspaces.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Create, Responses, Webhooks APIs |
| MCP | - | Not available |
| CLI | ✓ | [typeform.js](../clis/typeform.js) |
| SDK | ✓ | JavaScript (@typeform/js-api-client), Embed SDK |

## Authentication

- **Type**: Bearer Token (Personal Access Token or OAuth 2.0)
- **Header**: `Authorization: Bearer {token}`
- **Get key**: https://admin.typeform.com/account#/section/tokens

## Common Agent Operations

### List forms

```bash
GET https://api.typeform.com/forms
```

### Get a form

```bash
GET https://api.typeform.com/forms/{form_id}
```

### Create a form

```bash
POST https://api.typeform.com/forms

{
  "title": "Customer Feedback Survey",
  "fields": [
    {
      "type": "short_text",
      "title": "What is your name?"
    },
    {
      "type": "rating",
      "title": "How would you rate our service?",
      "properties": {
        "steps": 5
      }
    }
  ]
}
```

### Update a form

```bash
PATCH https://api.typeform.com/forms/{form_id}

[
  { "op": "replace", "path": "/title", "value": "Updated Survey Title" }
]
```

Use JSON Patch for a title-only change. `PUT` replaces the full form; omitted fields and their results are deleted. See [Typeform's partial-update contract](https://www.typeform.com/developers/create/reference/update-form-patch/).

### Delete a form

```bash
DELETE https://api.typeform.com/forms/{form_id}
```

### Retrieve responses

```bash
GET https://api.typeform.com/forms/{form_id}/responses?page_size=25&since=2024-01-01T00:00:00Z
```

### Delete responses

```bash
DELETE https://api.typeform.com/forms/{form_id}/responses?included_response_ids={id1},{id2}
```

### List webhooks

```bash
GET https://api.typeform.com/forms/{form_id}/webhooks
```

### Create or update webhook

```bash
PUT https://api.typeform.com/forms/{form_id}/webhooks/{tag}

{
  "url": "https://example.com/webhook",
  "enabled": true
}
```

### Delete webhook

```bash
DELETE https://api.typeform.com/forms/{form_id}/webhooks/{tag}
```

### List themes

```bash
GET https://api.typeform.com/themes
```

### List images

```bash
GET https://api.typeform.com/images
```

### List workspaces

```bash
GET https://api.typeform.com/workspaces
```

### Get a workspace

```bash
GET https://api.typeform.com/workspaces/{workspace_id}
```

## Key Metrics

### Response Data
- `response_id` - Unique response identifier
- `landed_at` / `submitted_at` - Timestamps
- `answers` - Array of field answers
- `variables` - Calculated variables
- `hidden` - Hidden field values
- `calculated` - Score calculations

### Form Data
- `id` - Form ID (from URL)
- `title` - Form title
- `fields` - Array of form fields
- `logic` - Logic jumps
- `settings` - Form settings (notifications, meta, etc.)
- `_links` - Display and responses URLs

## Parameters

### Retrieve Responses
- `page_size` - Results per page (default 25, max 1000)
- `since` / `until` - Date range filter (ISO 8601 or Unix timestamp)
- `after` / `before` - Pagination tokens
- `response_type` - Filter: started, partial, completed (default: completed)
- `query` - Text search within responses
- `fields` - Show only specific fields in answers
- `sort` - Sort order: `{fieldID},{asc|desc}`
- `included_response_ids` / `excluded_response_ids` - Filter specific responses
- `answered_fields` - Only responses containing specified fields

### List Forms
- `page` - Page number
- `page_size` - Results per page (default 10, max 200)
- `workspace_id` - Filter by workspace
- `search` - Search by form title

## When to Use

- Collecting lead information and survey data
- Building custom form experiences programmatically
- Automating survey creation for campaigns
- Analyzing form response data at scale
- Setting up real-time response webhooks
- Managing form themes and branding

## Rate Limits

- **Create & Responses APIs**: 2 requests per second per account
- **Webhooks & Embed**: No rate limits (push-based)
- Monitor for HTTP 429 responses

## Relevant Skills

- lead-generation
- customer-research
- cro
- signup
- customer-feedback

## File: tools/integrations/webflow.md

# Webflow

Visual web design and CMS platform for marketing sites.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for sites, CMS, forms |
| MCP | - | Not available |
| CLI | ✓ | Webflow CLI for devlink and apps |
| SDK | ✓ | Official SDK for Node.js |

## Authentication

- **Type**: API Token (Site token or OAuth)
- **Header**: `Authorization: Bearer {api_token}`
- **Get token**: Site Settings > Integrations > API Access

## Common Agent Operations

### List sites

```bash
GET https://api.webflow.com/v2/sites

Authorization: Bearer {api_token}
```

### Get site

```bash
GET https://api.webflow.com/v2/sites/{site_id}

Authorization: Bearer {api_token}
```

### List collections

```bash
GET https://api.webflow.com/v2/sites/{site_id}/collections

Authorization: Bearer {api_token}
```

### List collection items

```bash
GET https://api.webflow.com/v2/collections/{collection_id}/items

Authorization: Bearer {api_token}
```

### Get collection item

```bash
GET https://api.webflow.com/v2/collections/{collection_id}/items/{item_id}

Authorization: Bearer {api_token}
```

### Create collection item

```bash
POST https://api.webflow.com/v2/collections/{collection_id}/items

Authorization: Bearer {api_token}

{
  "fieldData": {
    "name": "Item Name",
    "slug": "item-name",
    "custom-field": "value"
  }
}
```

### Update collection item

```bash
PATCH https://api.webflow.com/v2/collections/{collection_id}/items/{item_id}

Authorization: Bearer {api_token}

{
  "fieldData": {
    "custom-field": "new value"
  }
}
```

### Publish collection items

```bash
POST https://api.webflow.com/v2/collections/{collection_id}/items/publish

Authorization: Bearer {api_token}

{
  "itemIds": ["item_id_1", "item_id_2"]
}
```

### List form submissions

```bash
GET https://api.webflow.com/v2/sites/{site_id}/forms/{form_id}/submissions

Authorization: Bearer {api_token}
```

### Publish site

```bash
POST https://api.webflow.com/v2/sites/{site_id}/publish

Authorization: Bearer {api_token}

{
  "publishToWebflowSubdomain": true,
  "publishToCustomDomains": true
}
```

## Node.js SDK

```javascript
const Webflow = require('webflow-api');

const webflow = new Webflow({ token: 'api_token' });

// List sites
const sites = await webflow.sites.list();

// Get collection items
const items = await webflow.collections.items.listItems(collectionId);

// Create item
const item = await webflow.collections.items.createItem(collectionId, {
  fieldData: {
    name: 'New Item',
    slug: 'new-item'
  }
});
```

## CLI Commands

```bash
# Install
npm install -g @webflow/webflow-cli

# Login
webflow login

# Initialize devlink
webflow devlink init

# Sync components
webflow devlink sync
```

## CMS Structure

- **Collections** - Content types (like blog posts, team members)
- **Items** - Individual entries in a collection
- **Fields** - Data fields on items

## Common Field Types

- `PlainText` - Simple text
- `RichText` - Formatted content
- `Image` - Image upload
- `Link` - URL or page reference
- `Reference` - Link to another collection
- `Multi-Reference` - Multiple collection links
- `Switch` - Boolean toggle
- `Number` - Numeric value
- `Date` - Date/time

## When to Use

- Marketing site CMS management
- Blog/content publishing
- Form submission handling
- Automated content updates
- Programmatic SEO pages

## Rate Limits

- 60 requests/minute (general)
- 10 requests/minute (publishing)

## Relevant Skills

- programmatic-seo
- content-strategy
- cro

## File: tools/integrations/wistia.md

# Wistia

Video hosting, management, and analytics platform built for marketers with detailed engagement tracking.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Data API (v1/modern), Stats API, Upload API |
| MCP | - | Not available |
| CLI | ✓ | [wistia.js](../clis/wistia.js) |
| SDK | ✓ | Ruby (official), community wrappers for other languages |

## Authentication

- **Type**: Bearer Token
- **Header**: `Authorization: Bearer {api_token}`
- **Get key**: Account Settings > API tab at https://account.wistia.com/account/api
- **Note**: Only Account Owners can create/manage tokens. Tokens can only be copied when first created.

## Common Agent Operations

### List all projects

```bash
GET https://api.wistia.com/v1/projects.json?page=1&per_page=25
```

### Create a project

```bash
POST https://api.wistia.com/v1/projects.json

{
  "name": "Marketing Videos Q1"
}
```

### List all media

```bash
GET https://api.wistia.com/v1/medias.json?page=1&per_page=25
```

### Get media details

```bash
GET https://api.wistia.com/v1/medias/{media_hashed_id}.json
```

### Get media stats

```bash
GET https://api.wistia.com/v1/medias/{media_hashed_id}/stats.json
```

### Get account-wide stats

```bash
GET https://api.wistia.com/v1/stats/account.json
```

### Get media engagement data (heatmap)

```bash
GET https://api.wistia.com/v1/stats/medias/{media_id}/engagement.json
```

### Get media stats by date

```bash
GET https://api.wistia.com/v1/stats/medias/{media_id}/by_date.json?start_date=2026-01-01&end_date=2026-01-31
```

### List visitors

```bash
GET https://api.wistia.com/v1/stats/visitors.json?page=1&per_page=25
```

### List viewing events

```bash
GET https://api.wistia.com/v1/stats/events.json?media_id={media_id}
```

### Update media metadata

```bash
PUT https://api.wistia.com/v1/medias/{media_hashed_id}.json

{
  "name": "Updated Video Title",
  "description": "New description"
}
```

### List captions for a video

```bash
GET https://api.wistia.com/v1/medias/{media_hashed_id}/captions.json
```

## API Versions

Wistia has two API versions:
- **v1** (`/v1/`) - Legacy, perpetually supported, no breaking changes
- **modern** (`/modern/`) - Current version, date-based versioning via `X-Wistia-Api-Version` header

The CLI uses v1 for maximum stability.

## Key Metrics

### Media Stats
- `plays` - Total video plays
- `visitors` - Unique visitors
- `pageLoads` - Page load count
- `averagePercentWatched` - Average watch percentage
- `percentOfVisitorsClickingPlay` - Play click rate

### Engagement Data
- Heatmap data showing exactly where viewers watch, rewatch, and drop off
- Per-second engagement breakdown

### Account Stats
- `total_medias` - Total video count
- `total_plays` - Account-wide plays
- `total_hours_watched` - Total hours of video watched

## Parameters

### Media List Parameters
- `page` - Page number (default: 1)
- `per_page` - Results per page (default: 25, max: 100)
- `project_id` - Filter by project
- `name` - Filter by name
- `type` - Filter by type (Video, Audio, Image, etc.)

### Stats Date Parameters
- `start_date` - Start date (YYYY-MM-DD)
- `end_date` - End date (YYYY-MM-DD)

## When to Use

- Hosting marketing and product videos with analytics
- Tracking video engagement and viewer behavior
- A/B testing video thumbnails and CTAs
- Embedding videos with custom player branding
- Analyzing which parts of videos drive engagement
- Lead generation via video email gates

## Rate Limits

- 600 requests per minute per account
- Exceeding returns HTTP 429 with `Retry-After` header
- Asset access (media file downloads) does not count toward limit
- Events data returns records from past 2 years only

## Relevant Skills

- video-marketing
- content-repurposing
- landing-page-optimization
- lead-generation

## File: tools/integrations/wordpress.md

# WordPress

Content management system for blogs and websites.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API (WP REST API) |
| MCP | - | Not available |
| CLI | ✓ | WP-CLI for server-side management |
| SDK | ✓ | Various client libraries |

## Authentication

- **Type**: Application Password, JWT, or OAuth
- **Header**: `Authorization: Basic {base64(username:app_password)}`
- **Setup**: Users > Your Profile > Application Passwords

## Common Agent Operations

### List posts

```bash
GET https://example.com/wp-json/wp/v2/posts?per_page=10

Authorization: Basic {base64(username:app_password)}
```

### Get post

```bash
GET https://example.com/wp-json/wp/v2/posts/{post_id}

Authorization: Basic {base64(username:app_password)}
```

### Create post

```bash
POST https://example.com/wp-json/wp/v2/posts

Authorization: Basic {base64(username:app_password)}

{
  "title": "Post Title",
  "content": "<p>Post content here</p>",
  "status": "draft",
  "categories": [1],
  "tags": [5, 6]
}
```

### Update post

```bash
PUT https://example.com/wp-json/wp/v2/posts/{post_id}

Authorization: Basic {base64(username:app_password)}

{
  "title": "Updated Title",
  "status": "publish"
}
```

### List pages

```bash
GET https://example.com/wp-json/wp/v2/pages?per_page=20

Authorization: Basic {base64(username:app_password)}
```

### List categories

```bash
GET https://example.com/wp-json/wp/v2/categories
```

### Create category

```bash
POST https://example.com/wp-json/wp/v2/categories

{
  "name": "Category Name",
  "slug": "category-name"
}
```

### Upload media

```bash
POST https://example.com/wp-json/wp/v2/media

Authorization: Basic {base64(username:app_password)}
Content-Disposition: attachment; filename="image.jpg"
Content-Type: image/jpeg

[binary image data]
```

### List users

```bash
GET https://example.com/wp-json/wp/v2/users

Authorization: Basic {base64(username:app_password)}
```

## WP-CLI Commands

```bash
# List posts
wp post list --post_type=post --post_status=publish

# Create post
wp post create --post_title="Title" --post_content="Content" --post_status=publish

# Update post
wp post update 123 --post_title="New Title"

# Export database
wp db export backup.sql

# Search/replace in database
wp search-replace 'old-domain.com' 'new-domain.com'

# Install plugin
wp plugin install yoast-seo --activate

# Update plugins
wp plugin update --all
```

## Post Statuses

- `publish` - Live on site
- `draft` - Not published
- `pending` - Awaiting review
- `private` - Private post
- `future` - Scheduled
- `trash` - In trash

## Common Endpoints

| Endpoint | Resource |
|----------|----------|
| `/wp/v2/posts` | Blog posts |
| `/wp/v2/pages` | Pages |
| `/wp/v2/media` | Images/files |
| `/wp/v2/categories` | Categories |
| `/wp/v2/tags` | Tags |
| `/wp/v2/users` | Users |
| `/wp/v2/comments` | Comments |

## When to Use

- Blog content management
- Page updates
- Media management
- Site configuration
- Plugin/theme management

## Rate Limits

- No default limits
- Server/host dependent

## Relevant Skills

- content-strategy
- seo-audit
- programmatic-seo

## File: tools/integrations/zapier.md

# Zapier

Workflow automation platform connecting 8,000+ apps. The Zapier SDK gives AI agents direct access to any app's actions without building OAuth flows or reverse-engineering APIs.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | REST API for Zaps, tasks, and webhooks |
| MCP | ✓ | Available via Zapier MCP server |
| CLI | ✓ | `@zapier/zapier-sdk-cli` for app discovery and type generation |
| SDK | ✓ | `@zapier/zapier-sdk` — TypeScript SDK for 8,000+ app integrations |

## Authentication

### Legacy API (Zaps management)

- **Type**: API Key
- **Header**: `X-API-Key: {api_key}`
- **Get key**: Settings > API in Zapier account

### SDK Authentication

**Browser-based login (development):**
```bash
npx zapier-sdk login
```

**Server-side (production):**
- Client Credentials — store as environment variables
- Direct token — set `ZAPIER_CREDENTIALS` env var

Browser-based login only works locally. Use Client Credentials for any server-side deployment.

## SDK Quick Start

### Install

```bash
npm install @zapier/zapier-sdk
npm install -D @zapier/zapier-sdk-cli @types/node typescript
npm pkg set type=module
```

### Initialize

```typescript
import { createZapierSdk } from "@zapier/zapier-sdk";
const zapier = createZapierSdk();
```

### CLI Commands

| Command | Purpose |
|---------|---------|
| `npx zapier-sdk login` | Authenticate (dev only) |
| `npx zapier-sdk list-apps --search "query"` | Search available apps |
| `npx zapier-sdk list-actions APP_KEY` | List actions for an app |
| `npx zapier-sdk add [app-key]` | Generate TypeScript types |

### SDK Methods

| Method | Purpose |
|--------|---------|
| `zapier.listConnections()` | List authenticated app connections |
| `zapier.findFirstConnection()` | Find a specific connection |
| `zapier.runAction()` | Execute an action on a connected app |
| `zapier.apps.slack()` | App proxy pattern for clean syntax |
| `zapier.fetch()` | Custom authenticated API calls |

### Example: Send a Slack Message

```typescript
import { createZapierSdk } from "@zapier/zapier-sdk";

const zapier = createZapierSdk();
const slack = await zapier.apps.slack();

await slack.sendChannelMessage({
  channel: "#marketing",
  message: "Campaign launched!"
});
```

### Example: Create a HubSpot Contact

```typescript
const hubspot = await zapier.apps.hubspot();

await hubspot.createContact({
  email: "lead@example.com",
  firstName: "Jane",
  lastName: "Doe"
});
```

### Pagination

Use `.items()` for large datasets:

```typescript
const contacts = await hubspot.listContacts({ maxItems: 100 });
for await (const contact of contacts.items()) {
  console.log(contact.email);
}
```

### Governance Note

Direct API calls via `zapier.fetch()` are not subject to org app/action restriction policies. Use pre-built actions where possible if your org has governance requirements.

---

## Zaps API (Legacy)

### List Zaps

```bash
GET https://api.zapier.com/v1/zaps
```

### Get Zap details

```bash
GET https://api.zapier.com/v1/zaps/{zap_id}
```

### Turn Zap on/off

```bash
POST https://api.zapier.com/v1/zaps/{zap_id}/on
POST https://api.zapier.com/v1/zaps/{zap_id}/off
```

### Get task history

```bash
GET https://api.zapier.com/v1/zaps/{zap_id}/tasks
```

### Get profile info

```bash
GET https://api.zapier.com/v1/profiles/me
```

## Webhooks (Triggers)

Catch Hook URLs do not require `ZAPIER_API_KEY`; the unique URL identifies the hook. The local CLI requires that key only for its management API commands, and never attaches it to a webhook request.

```bash
node tools/clis/zapier.js hooks send --url "https://hooks.zapier.com/hooks/catch/{account_id}/{hook_id}/" --data '{"event":"user.created"}'
```

Use `--dry-run` to preview the JSON POST without sending it. Treat the hook URL as a secret. Non-success HTTP responses exit unsuccessfully; an HTTP 200 only confirms reception, not completion of the Zap. [Zapier documents the hook setup and response behavior](https://help.zapier.com/hc/en-us/articles/8496288690317-Trigger-Zap-workflows-from-webhooks).

### Catch Hook (receive data)

Create a "Webhooks by Zapier" trigger to receive data:

```bash
POST https://hooks.zapier.com/hooks/catch/{webhook_id}/

{
  "event": "user.created",
  "user_id": "123",
  "email": "user@example.com"
}
```

### Send data to Zapier

Most common: trigger a Zap from your app:

```bash
POST https://hooks.zapier.com/hooks/catch/{account_id}/{hook_id}/

{
  "name": "John Doe",
  "email": "john@example.com",
  "plan": "pro"
}
```

## Common Marketing Automations

### With SDK (recommended for agents)

```typescript
// Lead capture to CRM
const hubspot = await zapier.apps.hubspot();
await hubspot.createContact({ email, firstName, lastName });

// New customer notification
const slack = await zapier.apps.slack();
await slack.sendChannelMessage({ channel: "#revenue", message: `New customer: ${email}` });

// Add to email sequence
const customerio = await zapier.apps.customerio();
await customerio.createOrUpdatePerson({ email, plan: "pro" });
```

### With Zaps (no-code)

- Typeform → Zapier → HubSpot (lead capture)
- Stripe → Zapier → Slack (new customer alerts)
- Form submission → Zapier → Customer.io (email sequences)
- New review → Zapier → Slack (social proof)
- New referral → Zapier → Spreadsheet + Slack (referral tracking)

## Webhook Payload Structure

When sending to Zapier, structure data as flat JSON:

```json
{
  "customer_name": "John Doe",
  "customer_email": "john@example.com",
  "plan_name": "Pro",
  "plan_price": 99,
  "signup_date": "2024-01-15"
}
```

## Key Concepts

- **Zap** - Automated workflow (no-code)
- **SDK** - Programmatic access to 8,000+ app integrations
- **Trigger** - Event that starts a Zap
- **Action** - Task performed by Zap or SDK
- **Task** - Single action execution
- **Connection** - Authenticated link to an app (shared between Zaps and SDK)

## When to Use

- **SDK**: When an AI agent needs to interact with any app directly — send messages, create records, sync data
- **Zaps**: When you need always-on automation without code
- **Webhooks**: When triggering workflows from your own app
- **API**: When managing Zaps programmatically

## Rate Limits

- API: 100 requests per minute
- SDK: Rate limits per connected app
- Task limits by plan tier

## Relevant Skills

- emails
- analytics
- referrals
- revops

## File: tools/integrations/zoominfo.md

# ZoomInfo

B2B contact database and intent data platform with 100M+ business contacts and company intelligence for sales and marketing teams.

## Capabilities

| Integration | Available | Notes |
|-------------|-----------|-------|
| API | ✓ | Contact Search, Company Search, Enrichment, Intent Data, Scoops |
| MCP | ✓ | Official remote server at `https://mcp.zoominfo.com/mcp` (OAuth); search and lookup are free, enrichment uses data credits |
| CLI | ✓ | [zoominfo.js](../clis/zoominfo.js) |
| SDK | - | REST API only |

## Authentication

- **Type**: JWT Token (Bearer)
- **Flow**: POST `/authenticate` using either username/password or a locally signed PKI assertion; receive the API JWT
- **Header**: `Authorization: Bearer {jwt_token}`
- **Env vars**: `ZOOMINFO_ACCESS_TOKEN`, or `ZOOMINFO_USERNAME` + `ZOOMINFO_PASSWORD`, or `ZOOMINFO_USERNAME` + `ZOOMINFO_CLIENT_ID` + `ZOOMINFO_PRIVATE_KEY`
- **PKI**: Set `ZOOMINFO_PRIVATE_KEY` to the multiline RSA PEM issued for your API client. The CLI signs a five-minute RS256 assertion locally and sends it as `Authorization: Bearer ...` to `/authenticate`. It never sends the key as a password. A configured private key requires its client ID and cannot fall back to password authentication.
- **Get credentials**: Contact ZoomInfo sales or admin portal at https://app.zoominfo.com

## Common Agent Operations

### Authenticate

```bash
POST https://api.zoominfo.com/authenticate

{
  "username": "user@company.com",
  "password": "account-password-here"
}
```

The JSON example above is the password flow. PKI instead sends the signed assertion in the header with no credentials in the body. The assertion uses the claims documented by [ZoomInfo's official authentication client](https://github.com/Zoominfo/api-auth-python-client/blob/master/zi_api_auth_client/zi_api_auth_client.py). API calls then use the returned JWT, not the short-lived client assertion. Dry runs mask authorization and make no authentication request.

### Contact Search

```bash
POST https://api.zoominfo.com/search/contact

{
  "jobTitle": ["VP Marketing"],
  "companyName": ["Acme Corp"],
  "managementLevel": ["VP"],
  "rpp": 25,
  "page": 1
}
```

### Contact Enrichment

```bash
POST https://api.zoominfo.com/enrich/contact

{
  "matchEmail": ["jane@acme.com"]
}
```

### Company Search

```bash
POST https://api.zoominfo.com/search/company

{
  "companyName": ["Acme"],
  "industry": ["Software"],
  "employeeCountMin": 50,
  "revenueMin": 10000000,
  "rpp": 25,
  "page": 1
}
```

### Company Enrichment

```bash
POST https://api.zoominfo.com/enrich/company

{
  "matchCompanyWebsite": ["acme.com"]
}
```

### Intent Data Lookup

```bash
POST https://api.zoominfo.com/lookup/intent

{
  "topicId": ["marketing-automation"],
  "companyId": ["123456"]
}
```

### Scoops Lookup

```bash
POST https://api.zoominfo.com/lookup/scoops

{
  "companyId": ["123456"],
  "rpp": 25,
  "page": 1
}
```

## Key Metrics

### Contact Data
- `firstName`, `lastName` - Name
- `jobTitle` - Job title
- `email` - Verified email
- `phone` - Direct phone
- `linkedinUrl` - LinkedIn profile
- `companyName` - Company name
- `managementLevel` - Seniority level
- `department` - Department

### Company Data
- `companyName` - Company name
- `website` - Website URL
- `employeeCount` - Employee count
- `industry` - Industry
- `revenue` - Annual revenue
- `techStack` - Technologies used
- `fundingAmount` - Total funding
- `companyCity`, `companyState`, `companyCountry` - Location

### Intent Data
- `topicName` - Intent topic
- `signalScore` - Signal strength
- `audienceStrength` - Audience engagement level
- `firstSeenDate`, `lastSeenDate` - Signal timeframe

## Parameters

### Contact Search
- `jobTitle` - Array of job titles
- `companyName` - Array of company names
- `managementLevel` - Array: C-Level, VP, Director, Manager, Staff
- `department` - Array: Marketing, Sales, Engineering, Finance, etc.
- `personLocationCity` - Array of cities
- `personLocationState` - Array of states
- `personLocationCountry` - Array of countries
- `rpp` - Results per page (default: 25, max: 100)
- `page` - Page number (default: 1)

### Contact Enrichment
- `matchEmail` - Array of email addresses
- `personId` - Array of ZoomInfo person IDs
- `matchFirstName` + `matchLastName` + `matchCompanyName` - Alternative lookup

### Company Search
- `companyName` - Array of company names
- `industry` - Array of industries
- `employeeCountMin` / `employeeCountMax` - Employee count range
- `revenueMin` / `revenueMax` - Revenue range
- `companyLocationCity` - Array of cities
- `rpp` - Results per page
- `page` - Page number

### Company Enrichment
- `matchCompanyWebsite` - Array of domains
- `companyId` - Array of ZoomInfo company IDs

### Intent Data
- `topicId` - Array of intent topic IDs
- `companyId` - Array of company IDs

## When to Use

- Identifying in-market accounts with intent signals
- Building targeted contact lists by role, seniority, and company
- Enriching leads with verified contact data and firmographics
- Finding decision-makers at target accounts for ABM
- Tracking company news and leadership changes via scoops
- Prioritizing outreach based on buyer intent signals

## Rate Limits

- Rate limits vary by plan and endpoint
- Standard: ~200 requests/minute
- Bulk endpoints: batched requests recommended
- Authentication tokens expire after ~12 hours

## Relevant Skills

- cold-email
- revops
- sales-enablement
- competitors
